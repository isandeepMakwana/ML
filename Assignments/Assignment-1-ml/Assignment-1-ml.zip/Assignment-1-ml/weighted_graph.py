import numpy

# data = numpy.matrix("10,20,100,40,5;10,20,100,40,5;10,20,100,40,5")
data = numpy.matrix(((10,20,100,40,5),(10,20,100,40,5),(10,20,100,40,5)))
w = numpy.matrix(((.2,.3,.1,.2,.2),(.2,.3,.1,.2,.2),(.2,.3,.1,.2,.2)))
wgt_mean = numpy.average(data, weights=w,axis=1)
print(wgt_mean)

wgt_mean = numpy.average(data, weights=w,axis=0)
print(wgt_mean)