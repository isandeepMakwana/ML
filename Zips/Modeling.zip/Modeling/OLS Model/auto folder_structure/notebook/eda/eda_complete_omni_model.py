#!/usr/bin/env python
# coding: utf-8

# ## Libraries import

# In[159]:


import pandas as pd  # Manipulating the tabular data
import numpy as np  # Manipulating the arrays
import pdb

pd.options.display.max_columns = 100  # Maximum columns that can be displayed in Jupyter notebook
pd.options.display.max_rows = 100  # Maximum rows that can be displayed in Jupyter notebook

# Custom module to format data before saving in excel
import os
import sys
module_path = os.path.abspath(os.path.join('..'))
if module_path not in sys.path:
    sys.path.append(module_path)

from save_excel import SaveExcelTemplated

# Custom module to handle most of the EDA steps
from eda_steps import EDA
from eda_visualization import EDA_visualization


# Handling excel workbooks
from openpyxl import load_workbook


# Loads dialogue box to upload the input files
from tkinter import *
root = Tk()
root.withdraw()
root.call('wm', 'attributes', '.', '-topmost', True)
from tkinter import filedialog
#%gui tk


# ## Variable Creation
# 
# * Creation of Media Hierarchy (updates both Modelling Stack and Data Dictionary
# * Naming convention: M_*
# * Imputes price for Christmas
# * Removes email from media variables

# In[7]:


# Upload modelling stack data ----- file name for reference (hersheys_modeling_stack_07212020_raw)
input_file_name = '/Users/vn0muxz/Documents/Huggies Python Files/folder_structure (added flexibility to choose media metric)/data/input_data/Huggies_modeling_stack_v2_hierarchy.csv'


# In[ ]:


#input_file_name_add_1 - file to be added for this - (Pampers_modeling_stack_Feb_May_2020_202200614)
#input_file_name_add_1 = filedialog.askopenfilename(multiple=True)[0]
# input_file_name_add_2 = filedialog.askopenfilename(multiple=True)[0]


# In[3]:


# Upload data dictionary
data_dict_path = '/Users/vn0muxz/Documents/Huggies Python Files/folder_structure (added flexibility to choose media metric)/data/input_data/WMG WAMM Project Data Dictionary_v5_hierarchy.xlsx'


# In[8]:


input_file_name


# In[5]:


metric_dictionary = {'IMP' : 'Impression',
                    'SPEND' : 'Spend',
                    'VIEW_IMP' : 'Viewable Impression',
                    'CLK' : 'Click'}


# #### Loading the data to pandas dataframe

# In[9]:


# Loading stacked data
df_orig = pd.read_csv(input_file_name, thousands= ",", na_values = " -   ") 
df_orig.columns = [str(col).replace(" ", "") for col in df_orig.columns]
df_orig.fillna(0, inplace= True)


df = df_orig.copy()


# In[11]:


df.shape


# In[12]:


# Loading data dictionary
data_dict = pd.read_excel(data_dict_path) 


# In[14]:




# #### Onsite-Display : Variables Creation

# In[15]:


# Onsite-Display Others i.e. sum of KWT, HPLO, ROS and Seasonal
# Level 5
'''
for metric, metric_label in metric_dictionary.items():
    
    keyword_targetting_var = 'M_ON_DIS_KW_' + metric
    homepage_lockout_var = 'M_ON_DIS_HPLO_' + metric
    run_of_site_var = 'M_ON_DIS_ROS_' + metric
    seasonal_var = 'M_ON_DIS_SEA_' + metric
    
    
    all_other_vars = [keyword_targetting_var, homepage_lockout_var, run_of_site_var, seasonal_var]
    all_other_vars = [var for var in all_other_vars if var in df.columns]
    
    df['M_ON_DIS_OTHERS_' + str(metric)] = df[all_other_vars].sum(axis= 1)
    
    data_dict.loc[data_dict.shape[0]] = ['M_ON_DIS_OTHERS_' + str(metric), 'Media Driver', 5, 'Onsite Display',
                                     'Others', '', metric_label, 'Onsite Display Others']


# In[16]:


# Onsite Display Total
# Level 4

for metric, metric_label in metric_dictionary.items():
    
    beh_targetting_var = 'M_ON_DIS_BT_' + metric
    contexual_targetting_var = 'M_ON_DIS_CT_' + metric
    others_var = 'M_ON_DIS_OTHERS_' + metric
    
    total_onsite_vars = [beh_targetting_var, contexual_targetting_var, others_var]
        
    df['M_ON_DIS_TOTAL_' + str(metric)] = df[total_onsite_vars].sum(axis= 1)
    
    data_dict.loc[data_dict.shape[0]] = ['M_ON_DIS_TOTAL_' + str(metric), 'Media Driver', 4, 'Onsite Display',
                                     'Total', '', metric_label, 'Onsite Display Total']


# #### Offsite Display Variable Creation

# In[20]:


# Offsite-Display Social Media i.e. Facebook, Pinterest and Instagram
# Level 5

for metric, metric_label in metric_dictionary.items():
    
    facebook_var = 'M_OFF_DIS_FB_' + metric
    pinterest_var = 'M_OFF_DIS_PIN_' + metric
    instagram_var = 'M_OFF_DIS_INSTAGRAM_' + metric # Currently not in data. (for future use cases)
    
    social_media_vars = [facebook_var, pinterest_var, instagram_var]
    
    social_media_vars = [var for var in social_media_vars if var in df.columns]
    
    df['M_OFF_DIS_SMEDIA_' + str(metric)] = df[social_media_vars].sum(axis= 1)
    
    data_dict.loc[data_dict.shape[0]] = ['M_OFF_DIS_SMEDIA_' + str(metric), 'Media Driver', 5, 'Offsite Display',
                                     'Social Media', '', metric_label, 'Offsite Display Social Media']


# In[21]:


# Offsite Display Total
# Level 4

for metric, metric_label in metric_dictionary.items():
    social_media_var = 'M_OFF_DIS_SMEDIA_' + metric
    walmart_net_vars = 'M_OFF_DIS_WN_' + metric
    
    total_offsite_vars = [social_media_var, walmart_net_vars]
    total_offsite_vars = [var for var in total_offsite_vars if var in df.columns]
    
    df['M_OFF_DIS_TOTAL_' + str(metric)] = df[total_offsite_vars].sum(axis= 1)
    
    data_dict.loc[data_dict.shape[0]] = ['M_OFF_DIS_TOTAL_' + str(metric), 'Media Driver', 4, 'Offsite Display',
                                     'Total', '', metric_label, 'Offsite Display Total']


# In[22]:


# Total Display
# Level 3

for metric, metric_label in metric_dictionary.items():
    total_onsite = 'M_ON_DIS_TOTAL_' + metric
    total_offsite = 'M_OFF_DIS_TOTAL_' + metric
    
    total_display_vars = [total_onsite, total_offsite]
    
    df['M_TOTAL_DISPLAY_' + str(metric)] = df[total_display_vars].sum(axis= 1)
    
    data_dict.loc[data_dict.shape[0]] = ['M_TOTAL_DISPLAY_' + str(metric), 'Media Driver', 3, 'Total Display',
                                     'Total Display', '', metric_label, 'Total Display']


# In[23]:


# Total Media
# Level 2

for metric, metric_label in metric_dictionary.items():
    total_display = 'M_TOTAL_DISPLAY_' + metric
    total_sponsored = 'M_SP_' + metric
    
    total_media_vars = [total_display, total_sponsored]
    
    df['M_TOTAL_MEDIA_' + str(metric)] = df[total_media_vars].sum(axis= 1)
    
    data_dict.loc[data_dict.shape[0]] = ['M_TOTAL_MEDIA_' + str(metric), 'Media Driver', 2, 'Total Media',
                                     'Total Media', '', metric_label, 'Total Media']


# In[24]:


# Price
df['PRICE'] = df['O_SALE'] / df['O_UNIT']




data_dict.tail(3)


# In[27]:


# Dropping Media Email Columns

all_cols = [col for col in df.columns if 'M_OFF_DIS_EMAIL' not in str(col)]
df = df[all_cols]


# In[29]:


# New customer online = email + omni

df['O_NEW_CUSTOMER_ONLINE'] = df['O_NEW_CUSTOMER_EMAIL'] + df['O_NEW_CUSTOMER_OMNI_EMAIL']
data_dict.loc[data_dict.shape[0]] = ['O_NEW_CUSTOMER_ONLINE', 'Outcome Customer Count', '', '',
                                    '', '', 'Count', 'New Customer Count Online']


# In[30]:



# Price Online
df['PRICE_ONLINE'] = df['O_SALE_ONLINE'] / df['O_UNIT_ONLINE']

data_dict.loc[data_dict.shape[0]] = ["PRICE_ONLINE", 'Pricing', "", "",
                                         "", "", "", "Average Unit Price Online"]


# #### Saving the updated modelling stack data and data dictionary

# In[31]:


input_file_name, data_dict_path


# In[32]:


input_file_name_new = input_file_name.replace("_raw.csv", "_hierarchy_all_periods.csv")
data_dict_path_new = data_dict_path.replace(".xlsx", "_hierarchy.xlsx")


# In[33]:


input_file_name_new, data_dict_path_new


# In[34]:


# appends _hierarchy with variable name
df.to_csv(input_file_name_new, index= False)


# In[35]:


# Filtering the data on the required dates
df['index'] = pd.to_datetime(df['index'])
df = df[(df['index'] >= '2018-01-01') & (df['index'] <= '2020-06-30')].reset_index(drop= True)


# In[36]:


input_file_name_new = input_file_name.replace(".csv", "_hierarchy.csv")
df.to_csv(input_file_name_new, index= False)


# In[37]:


book = load_workbook(data_dict_path)
writer = pd.ExcelWriter(data_dict_path_new, engine='openpyxl') 

writer.book = book
writer.sheets = dict((ws.title, ws) for ws in book.worksheets)

data_dict.to_excel(writer, sheet_name= "Data Dictionary", index= False)

writer.save()


# In[ ]:


'''


# ### Variable Selection

# In[38]:


# Selection of outcome variables
sales_vars = [col for col in df.columns if str(col).startswith('O_SALE')]  # Sales Variables
units_vars = [col for col in df.columns if str(col).startswith('O_UNIT')]  # Units Variables
customer_vars = [col for col in df.columns if str(col).startswith(('O_NEW_CUSTOMER', 'O_EXISTING_CUSTOMER', 
                                                                   'O_TOTAL_CUSTOMER'))] # Customer Variables

all_outcome_vars = sales_vars + units_vars + customer_vars # All outcome variables


# Price Variables
all_price_vars = ['PRICE','PRICE_ONLINE']


# Selection of media variables
all_media_vars = [col for col in df.columns if str(col).startswith('M_')]  # Media variables


# Selection of dummy variables
all_dummy_vars = [col for col in df.columns if str(col).startswith('D_')]  # Dummy variables

# Total Impressions 
total_impression = ['M_ON_DIS_TOTAL_IMP', 'M_OFF_DIS_TOTAL_IMP', 'M_TOTAL_DISPLAY_IMP', 'M_SP_IMP']

# Selection of tactics
tactics = ['M_OFF_DIS_FB_IMP','M_OFF_DIS_WN_IMP','M_ON_DIS_BT_IMP','M_ON_DIS_CT_IMP','M_ON_DIS_HPLO_IMP','M_ON_DIS_KW_IMP',
           'M_ON_DIS_ROS_IMP','M_ON_DIS_SEA_IMP','M_OFF_DIS_PIN_IMP','M_SP_AB_IMP','M_SP_KWB_IMP','M_SP_SBA_IMP','M_ON_DIS_OTHERS_IMP',
           'M_OFF_DIS_WN_DISPLAY_IMP','M_OFF_DIS_WN_PREROLL_IMP']


# In[ ]:





# In[ ]:





# ## Outlier Detection, Sparsity Check & Descriptive Analysis
# * Outlier Detection
#     * Default values of Z-Scores to detect outliers: -3 (lower limit) and +3 (upper limit)
#     * User can pass parameters to change the default values
# * Sparsity Check
#     * Since missing data (i.e. null values) is already handled in the ETL process, we are considering zero values as missing values
#     * Variables having less than 30 % non-zero data points are consider sparse
#     * Analysis of percentage contribution of different product types & tactics (done at each level of media hierarchy)
#     * Other metrics like CPI and CPC
# * Descriptive Statistics
#     * Analysis of mean, mode, median, standard deviation
#     * Analysis also included for non-zero values
# * Media On-Off Days Analysis

# ####  Outlier Detection, Sparsity Check and Descriptive Analysis of Outcome Variables

# #### Preparation of Outlier Analysis Table

# In[39]:

'''
# EDA class contains all the necessary steps for EDA
eda_outcome_vars = EDA(df, data_dict)


# In[40]:


# Method to perform outlier analysis 
df_outlier_analysis_outcome = eda_outcome_vars.evaluate_outliers(all_outcome_vars, lower_z_score= -3, upper_z_score= 3)


# In[41]:


# Display top n rows of the output
df_outlier_analysis_outcome.head(3)


# In[42]:


df_outlier_analysis_price = eda_outcome_vars.evaluate_outliers(all_price_vars, lower_z_score= -3, upper_z_score= 3)
df_outlier_analysis_price.head()


# #### Update the Custom Start Date & End Date for CPM/CPI Analysis
# The resultant output would show Impressions, Spends, CPM, CPC for the selected time period

# In[113]:


custom_start_dt = '2018-01-01'
custom_end_dt = '2020-06-30'


# #### Preparation of Sparsity 

# In[114]:


# Method to perform sparsity checks
sparsity_check_dict_outcome = eda_outcome_vars.analyse_sparsity(all_outcome_vars,custom_start_dt=custom_start_dt,
                                                            custom_end_dt=custom_end_dt)


# In[115]:


sparsity_check_dict_price = eda_outcome_vars.analyse_sparsity(all_price_vars,custom_start_dt=custom_start_dt,
                                                            custom_end_dt=custom_end_dt)


# #### Descriptive Statistics

# In[116]:


# Method to perform descriptive statistics
df_descriptive_stats_outcome = eda_outcome_vars.evaluate_descriptive_stats(all_outcome_vars)


# In[117]:


# Display top n rows of the output
df_descriptive_stats_outcome.head(2)


# In[118]:


df_descriptive_stats_price = eda_outcome_vars.evaluate_descriptive_stats(all_price_vars)
df_descriptive_stats_price.head(2)


# #### Combine all results

# In[119]:


# Combining the results of EDA and using custom module to format the data
excel_obj = SaveExcelTemplated("../../data/output_data/eda_results/eda_excel/eda_analysis_outcome_alltime.xlsx")  # Path to save output data
excel_obj.add_worksheet(df_outlier_analysis_outcome, 'Outlier Analysis')

excel_obj.add_worksheet(df_outlier_analysis_price, 'Outlier Analysis Price') # Price addition


for key, value in sparsity_check_dict_outcome.items():
    excel_obj.add_worksheet(value, key, 
                            percent_col_names = [col for col in value.columns if '%age' in col])

for key, value in sparsity_check_dict_price.items(): # Addition of Price
    excel_obj.add_worksheet(value, key, 
                            percent_col_names = [col for col in value.columns if '%age' in col])

excel_obj.add_worksheet(df_descriptive_stats_outcome, 'Descriptive Stats') 
excel_obj.add_worksheet(df_descriptive_stats_price, 'Descriptive Stats Price') 


# In[120]:


# Saving the results
excel_obj.save_worksheet()


# ## Media Variables

# #### Preparation of Outlier Analysis Table

# In[121]:


# EDA class contains all the necessary steps for EDA
eda_media_vars = EDA(df, data_dict)


# In[122]:


# Method to perform outlier analysis 
df_outlier_analysis_media = eda_outcome_vars.evaluate_outliers(all_media_vars, lower_z_score= -3, upper_z_score= 3)


# In[123]:


# Display top n rows of the output
df_outlier_analysis_media.head(3)


# In[ ]:





# #### Preparation of Sparsity 

# In[124]:


# Method to perform sparsity checks
sparsity_check_dict_media = eda_media_vars.analyse_sparsity(all_media_vars, custom_start_dt=custom_start_dt,
                                                            custom_end_dt=custom_end_dt,
                                                            media= True)


# In[125]:


sparsity_check_dict_media["Onsite Impression"].head(2)


# In[126]:


sparsity_check_dict_media["Sponsored Impression"].head(2)


# In[127]:


sparsity_check_dict_media["Onsite Viewable Impression"].head(2)


# In[128]:


sparsity_check_dict_media["Onsite Click"].head(2)


# #### Descriptive Statistics

# In[129]:


# Method to perform descriptive statistics
df_descriptive_stats_media = eda_media_vars.evaluate_descriptive_stats(all_media_vars)


# In[130]:


# Display top n rows of the output
df_descriptive_stats_media.head(2)


# #### On-Off Days Analysis

# In[131]:


dict_on_off_media = eda_media_vars.get_on_off_days()


# In[132]:


dict_on_off_media["On-Off Total"].head(2)


# In[133]:


dict_on_off_media["Onsite - On Off Granular"].head(2)


# #### Combine all results
# Rename the file name in the path to save the files for custom time period

# In[134]:


# Combining the results of EDA and using custom module to format the data
excel_obj = SaveExcelTemplated("../../data/output_data/eda_results/eda_excel/eda_analysis_media_alltime.xlsx")  # Path to save output data
excel_obj.add_worksheet(df_outlier_analysis_media, 'Outlier Analysis')

for key, value in sparsity_check_dict_media.items():
    excel_obj.add_worksheet(value, key,
                            percent_col_names = [col for col in value.columns if '%age' in col],
                            decimal_col_names = [col for col in value.columns if 'Cost per' in col] + ['CPM'])

excel_obj.add_worksheet(df_descriptive_stats_media, 'Descriptive Stats')

for key, value in dict_on_off_media.items():
    excel_obj.add_worksheet(value, key, percent_col_names = [col for col in value.columns if 'percen' in col])


# In[135]:


# Saving the results
excel_obj.save_worksheet()


# In[ ]:





# ## Tabular Analysis
# * Year on year change analysis
# * User can choose the dates for which comparison needs to be done (useful for other brands/future data)

# In[136]:


# EDA class contains all the necessary steps for EDA
eda = EDA(df, data_dict)


# In[137]:


dict_outcome_vars = eda.calculate_tabular_analysis(all_outcome_vars, start_date_1= '2018-01-01', start_date_2= '2019-01-01',
                                                   end_date_1= '2018-12-31', end_date_2= '2019-12-31',
                                                   var_type= 'Outcome')


# In[138]:


dict_outcome_vars['Outcome Variables'].head(4)


# In[139]:


dict_pricing_vars = eda.calculate_tabular_analysis(all_price_vars, 
                                                   start_date_1= '2018-01-01', start_date_2= '2019-01-01',
                                                   end_date_1= '2018-12-31', end_date_2= '2019-12-31', 
                                                   var_type= 'Pricing')


# In[140]:


dict_pricing_vars['Pricing Variables'].head()


# In[141]:


dict_media_vars = eda.calculate_tabular_analysis(all_media_vars, 
                                                 start_date_1= '2018-01-01', start_date_2= '2019-01-01',
                                                 end_date_1= '2018-12-31', end_date_2= '2019-12-31', 
                                                 var_type= 'Media')


# ### Combine the results of YOY analysis.
# Rename the file nqame on the path for custom time periods

# In[142]:


# Combining the results of EDA and using custom module to format the data
excel_obj = SaveExcelTemplated("../../data/output_data/eda_results/eda_excel/eda_tabular_analysis_7_27.xlsx")  # Path to save output data

for key, value in dict_outcome_vars.items():
    excel_obj.add_worksheet(value, key, ['YOY %-age change'])
    
for key, value in dict_pricing_vars.items():
    excel_obj.add_worksheet(value, key, ['YOY %-age change'])
    
for key, value in dict_media_vars.items():
    if value.shape[0] == 0:
        continue
    excel_obj.add_worksheet(value, key, ['YOY %-age change'])

excel_obj.save_worksheet()


# In[ ]:



'''

# ## Visualization
# * Line Trends - Single Variable
# * Line Trends - Multiple Variables
# * Combo Charts
# * Bivariate Analysis - Correlation and Scatter Plots

# #### Trends for Single Variable

# In[154]:


eda_obj = EDA_visualization(df, data_dict)
eda_obj.create_date_vars('index')


# In[145]:


# Choose color from yellow, blue, nair, charcoal, light blue, gray, shade blue, brown, green, orange
# Flexibility to add title and yaxis label
# save= True/False (flexibility to save the figure)
# show_ylabel= True/False (flexibility to view labels of yaxis)
'''
fig = eda_obj.get_line_plot(var_name= 'O_UNIT', color= 'blue', plot_title= 'Trend of Volume Sales Units',
                            ylabel= 'Volume Sales Units', save= True, show_ylabel= False)
fig.show()


# In[ ]:


fig = eda_obj.get_line_plot(var_name= 'O_NEW_CUSTOMER', color= 'blue', plot_title= 'Trend of New Customer Count',
                            ylabel= 'New Customer Count', save= True, show_ylabel= False)
fig.show()


# In[146]:


fig = eda_obj.get_line_plot(var_name= 'O_SALE', color= 'blue', plot_title= 'Trend of Sales Revenue',
                            ylabel= 'Sales Revenue', save= True, show_ylabel= False)
fig.show()


# In[ ]:





# In[147]:


fig = eda_obj.get_line_plot(var_name= 'PRICE', color= 'blue', plot_title= 'Trend of Price',
                            ylabel= 'Price', show_ylabel= True, save= True)
fig.show()


# In[ ]:

'''



# ####  Plotting all the impression variables

# In[155]:


all_impression_vars = [var for var in all_media_vars if ('IMP' in var) & ('VIEW_IMP' not in var)]


# In[161]:


all_impression_vars


# In[162]:
'''

eda_obj.plot_line_plot(all_impression_vars, color= 'blue', save= True, show= False)


# In[ ]:


#Cumulative chart for Total Media Impressions
eda_obj.plot_cumulative_plot('M_TOTAL_MEDIA_IMP', save= True)


# In[ ]:


#Cumulative chart for Total Media Spends
eda_obj.plot_cumulative_plot('M_TOTAL_MEDIA_SPEND', save= True)


# In[ ]:


#Area Chart for Non-cumulative Total Media Impressions
key_var_dict = {'M_TOTAL_MEDIA_IMP' : ['blue', 'Total Media Impressions']}

other_vars_dict = {}

eda_obj.get_combo_plot(key_var_dict= key_var_dict, other_vars_dict= other_vars_dict, ylabel1= 'Total Media Impressions',
                       title= "Non-Cumulative Media Impressions", save= True,show_ylabel=True)


# In[ ]:


#Area Chart for Non-cumulative Total Media Impressions
key_var_dict = {'M_TOTAL_MEDIA_SPEND' : ['blue', 'Total Media Spends']}

other_vars_dict = {}

eda_obj.get_combo_plot(key_var_dict= key_var_dict, other_vars_dict= other_vars_dict, ylabel1= 'Total Media Spends',
                       title= "Non-Cumulative Media Spends", save= True,show_ylabel=True)


# #### Trends for multiple variables

# In[ ]:


# Pass dictionary of variables (along with color and labels)
for imp in total_impression:
    desc = data_dict[data_dict['Variable Name'] == imp]['Variable Description'].values[0]
    ylabel2 = data_dict[data_dict['Variable Name'] == imp]['Product Type'].values[0]
    
    other_vars_dict = {'O_UNIT' : ['blue', 'Volume Sales Units'],
                      imp : ['yellow', desc]}
                                              
    eda_obj.get_combo_plot(other_vars_dict= other_vars_dict, ylabel1= 'Volume Sales Units', ylabel2= ylabel2,
                       title = "Volume Sales Units & " + ylabel2 + " Impressions (Overall)", save= True,
                      show_ylabel= True)


# In[ ]:


# Pass dictionary of variables (along with color and labels)
for imp in total_impression:
    desc = data_dict[data_dict['Variable Name'] == imp]['Variable Description'].values[0]
    ylabel2 = data_dict[data_dict['Variable Name'] == imp]['Product Type'].values[0]
    other_vars_dict = {'O_NEW_CUSTOMER' : ['blue', 'New Customer Count'],
                      imp : ['yellow', desc]}
                                              
    eda_obj.get_combo_plot(other_vars_dict= other_vars_dict, ylabel1= 'New Customer Count', ylabel2= ylabel2,
                       title = "New Customer Count & " + ylabel2 + " Impressions (Overall)", save= True,
                      show_ylabel= True)


# In[ ]:


# Pass dictionary of variables (along with color and labels)
for imp in tactics:
    desc = data_dict[data_dict['Variable Name'] == imp]['Variable Description'].values[0]
    ylabel2 = data_dict[data_dict['Variable Name'] == imp]['Product Type'].values[0]
    other_vars_dict = {'O_NEW_CUSTOMER' : ['blue', 'New Customer Count'],
                      imp : ['yellow', desc]}
                                              
    eda_obj.get_combo_plot(other_vars_dict= other_vars_dict, ylabel1= 'New Customer Count', ylabel2= ylabel2,
                       title = "New Customer Count & " + desc , save= True,
                      show_ylabel= True)


# In[ ]:


other_vars_dict = {'O_NEW_CUSTOMER' : ['blue', 'New Customer Count'],
                   'M_SP_CLK' : ['yellow', 'Sponsored Product']}


# In[ ]:


eda_obj.get_combo_plot(other_vars_dict= other_vars_dict, ylabel1= 'New Customer Count', ylabel2= 'Sponsored Product',
                       title = "New Customer Count & Sponsored Product Clicks (Overall)" , save= False,
                      show_ylabel= True)


# In[ ]:


other_vars_dict = {'O_NEW_CUSTOMER' : ['blue', 'New Customer Count'],
                   'M_SP_AB_CLK' : ['yellow', 'Sponsored Product AutoBid']}


# In[ ]:


eda_obj.get_combo_plot(other_vars_dict= other_vars_dict, ylabel1= 'New Customer Count', ylabel2= 'Sponsored Product',
                       title = "New Customer Count & Sponsored Product AutoBid" , save= False,
                      show_ylabel= True)


# In[ ]:


other_vars_dict = {'O_NEW_CUSTOMER' : ['blue', 'New Customer Count'],
                   'M_SP_KWB_CLK' : ['yellow', 'Sponsored Product Keyword Bidding']}


# In[ ]:


eda_obj.get_combo_plot(other_vars_dict= other_vars_dict, ylabel1= 'New Customer Count', ylabel2= 'Sponsored Product',
                       title = "New Customer Count & Sponsored Product Keyword Bidding" , save= False,
                      show_ylabel= True)


# In[ ]:


other_vars_dict = {'O_NEW_CUSTOMER' : ['blue', 'New Customer Count'],
                   'M_SP_SBA_CLK' : ['yellow', 'Sponsored Product Search Brand Amplifier']}


# In[ ]:


eda_obj.get_combo_plot(other_vars_dict= other_vars_dict, ylabel1= 'New Customer Count', ylabel2= 'Sponsored Product',
                       title = "New Customer Count & Sponsored Product Search Brand Amplifier" , save= False,
                      show_ylabel= True)


# In[ ]:


# Pass dictionary of variables (along with color and labels)
for imp in tactics:
    desc = data_dict[data_dict['Variable Name'] == imp]['Variable Description'].values[0]
    ylabel2 = data_dict[data_dict['Variable Name'] == imp]['Product Type'].values[0]
    other_vars_dict = {'O_UNIT' : ['blue', 'Volume Sales Units'],
                      imp : ['yellow', desc]}
                                              
    eda_obj.get_combo_plot(other_vars_dict= other_vars_dict, ylabel1= 'Volume Sales Units', ylabel2= ylabel2,
                       title = "Volume Sales Units & " + desc , save= True,
                      show_ylabel= True)


# In[ ]:


other_vars_dict = {'O_UNIT' : ['blue', 'Volume Sales Units'],
                   'M_SP_CLK' : ['yellow', 'Sponsored Product']}


# In[ ]:


eda_obj.get_combo_plot(other_vars_dict= other_vars_dict, ylabel1= 'Volume Sales Units', ylabel2= 'Sponsored Product',
                       title = "Volume Sales Units & Sponsored Product Clicks (Overall)" , save= False,
                      show_ylabel= True)


# In[ ]:


other_vars_dict = {'O_UNIT' : ['blue', 'Volume Sales Units'],
                   'M_SP_AB_CLK' : ['yellow', 'Sponsored Product AutoBid']}


# In[ ]:


eda_obj.get_combo_plot(other_vars_dict= other_vars_dict, ylabel1= 'Volume Sales Units', ylabel2= 'Sponsored Product',
                       title = "Volume Sales Units & Sponsored Product AutoBid" , save= False,
                      show_ylabel= True)


# In[ ]:


other_vars_dict = {'O_UNIT' : ['blue', 'Volume Sales Units'],
                   'M_SP_KWB_CLK' : ['yellow', 'Sponsored Product Keyword Bidding']}


# In[ ]:


eda_obj.get_combo_plot(other_vars_dict= other_vars_dict, ylabel1= 'Volume Sales Units', ylabel2= 'Sponsored Product',
                       title = "Volume Sales Units & Sponsored Product Keyword Bidding" , save= False,
                      show_ylabel= True)


# In[ ]:


other_vars_dict = {'O_UNIT' : ['blue', 'Volume Sales Units'],
                   'M_SP_SBA_CLK' : ['yellow', 'Sponsored Product Search Brand Amplifier']}


# In[ ]:


eda_obj.get_combo_plot(other_vars_dict= other_vars_dict, ylabel1= 'Volume Sales Units', ylabel2= 'Sponsored Product',
                       title = "Volume Sales Units & Sponsored Product Search Brand Amplifier" , save= False,
                      show_ylabel= True)


# #### Combo Charts

# In[ ]:


# Custom color and label for each of the variable
# Key Variable would be displayed as highlighted area on the graph

key_var_dict = {'O_UNIT' : ['light blue', 'Volume Sales Units']}

other_vars_dict = {'M_SP_IMP' : ['gray', 'Sponsored Product'],
                  'M_ON_DIS_TOTAL_IMP' : ['blue', 'Onsite Display'],
                  'M_OFF_DIS_TOTAL_IMP' : ['yellow', 'Offsite Display']}


# In[ ]:


eda_obj.get_combo_plot(key_var_dict= key_var_dict, other_vars_dict= other_vars_dict, ylabel1= 'Volume Sales Units',
                       ylabel2= 'Media',
                       title= "Volume Sales Units vs Media", save= True,show_ylabel=False)


# In[ ]:


key_var_dict = {'O_NEW_CUSTOMER' : ['light blue', 'New Customer Count']}
eda_obj.get_combo_plot(key_var_dict= key_var_dict, other_vars_dict= other_vars_dict, ylabel1= 'New Customer Count',
                       ylabel2= 'Media',
                       title= "New Customer Count vs Media", save= True,show_ylabel=False)


# In[ ]:


key_var_dict = {'O_SALE' : ['light blue', 'Volume Sales Revenue']}

eda_obj.get_combo_plot(key_var_dict= key_var_dict, other_vars_dict= other_vars_dict, ylabel1= 'Sales Revenue',
                       ylabel2= 'Media',
                       title= "Sales Revenue vs Media", save= True)


# In[ ]:


eda_obj.get_combo_plot(key_var_dict= key_var_dict, other_vars_dict= other_vars_dict, hide_area= True,
                       show_ylabel= True,
                       title= "Analysis of Media Impressions (Overall Level)", save= True)


# In[ ]:


other_vars_dict_spends = {'M_SP_SPEND' : ['gray', 'Sponsored Product'],
                  'M_ON_DIS_TOTAL_SPEND' : ['blue', 'Onsite Display'],
                  'M_OFF_DIS_TOTAL_SPEND' : ['yellow', 'Offsite Display']}

eda_obj.get_combo_plot(key_var_dict= key_var_dict, other_vars_dict= other_vars_dict_spends, hide_area= True,
                       show_ylabel= True,
                       title= "Analysis of Media Spends (Overall Level)", save= True)


# In[ ]:





# #### Granular Combo Charts

# In[ ]:


key_var_dict = {'O_UNIT' : ['light blue', 'Volume Sales Units']}

other_vars_dict = {'M_SP_AB_IMP' : ['gray', 'Sponsored Product AutoBid'],
                    'M_SP_KWB_IMP' : ['blue', 'Sponsored Product Keyword Bidding'],
                    'M_SP_SBA_IMP' : ['nair', 'Sponsored Product Search Brand Amplifier'],
                    'M_ON_DIS_BT_IMP' : ['yellow', 'Onsite Display Behavioral'],
                    'M_ON_DIS_CT_IMP' : ['orange', 'Onsite Display Contextual'],
                    'M_ON_DIS_OTHERS_IMP' : ['shade blue', 'Onsite Display Others'],
                    'M_OFF_DIS_WN_IMP' : ['green', 'Offsite Display Walmart Network'],
                    'M_OFF_DIS_FB_IMP' : ['brown', 'Offsite Display Facebook'],
                    'M_OFF_DIS_PIN_IMP' : ['blue', 'Offsite Display Pinterest']
                  }


# In[ ]:


eda_obj.get_combo_plot(key_var_dict= key_var_dict, other_vars_dict= other_vars_dict, ylabel1= 'Volume Sales Units',
                       ylabel2= 'Media',show_ylabel=False,
                       title= "Volume Sales Units vs Granular Media", save= True)


# In[ ]:


key_var_dict = {'O_NEW_CUSTOMER' : ['light blue', 'New Customer Count']}


other_vars_dict = {'M_SP_AB_IMP' : ['gray', 'Sponsored Product AutoBid'],
                    'M_SP_KWB_IMP' : ['blue', 'Sponsored Product Keyword Bidding'],
                    'M_SP_SBA_IMP' : ['nair', 'Sponsored Product Search Brand Amplifier'],
                    'M_ON_DIS_BT_IMP' : ['yellow', 'Onsite Display Behavioral'],
                    'M_ON_DIS_CT_IMP' : ['orange', 'Onsite Display Contextual'],
                    'M_ON_DIS_OTHERS_IMP' : ['shade blue', 'Onsite Display Others'],
                    'M_OFF_DIS_WN_IMP' : ['green', 'Offsite Display Walmart Network'],
                    'M_OFF_DIS_FB_IMP' : ['brown', 'Offsite Display Facebook'],
                    'M_OFF_DIS_PIN_IMP' : ['blue', 'Offsite Display Pinterest']
                  }

eda_obj.get_combo_plot(key_var_dict= key_var_dict, other_vars_dict= other_vars_dict, ylabel1= 'New Customer Count', 
                       ylabel2= 'Media', show_ylabel = False,
                       title= "New Customer Count vs Granular Media", save= True,)


# In[ ]:


key_var_dict = {'O_SALE' : ['light blue', 'Sales Revenue']}
eda_obj.get_combo_plot(key_var_dict= key_var_dict, other_vars_dict= other_vars_dict, ylabel1= 'Sales Revenue',
                       ylabel2= 'Media',
                       title= "Analysis of Sales Revenue with Media Impressions Granular", save= True)


# In[ ]:


eda_obj.get_combo_plot(key_var_dict= key_var_dict, other_vars_dict= other_vars_dict, 
                       show_ylabel= True,
                       hide_area= True,
                       title= "Analysis of Media Impressions (Granular Level)", 
                       save= True)


# In[ ]:


other_vars_dict_spend = {'M_SP_AB_SPEND' : ['gray', 'Sponsored Product AutoBid'],
                    'M_SP_KWB_SPEND' : ['blue', 'Sponsored Product Keyword Bidding'],
                    'M_SP_SBA_SPEND' : ['nair', 'Sponsored Product Search Brand Amplifier'],
                    'M_ON_DIS_BT_SPEND' : ['yellow', 'Onsite Display Behavioral'],
                    'M_ON_DIS_CT_SPEND' : ['orange', 'Onsite Display Contextual'],
                    'M_ON_DIS_OTHERS_SPEND' : ['shade blue', 'Onsite Display Others'],
                    'M_OFF_DIS_WN_IMP' : ['green', 'Offsite Display Walmart Network'],
                    'M_OFF_DIS_FB_IMP' : ['brown', 'Offsite Display Facebook'],
                    'M_OFF_DIS_PIN_IMP' : ['blue', 'Offsite Display Pinterest']
                  }


eda_obj.get_combo_plot(key_var_dict= key_var_dict, other_vars_dict= other_vars_dict_spend, 
                       show_ylabel= True,
                       hide_area= True,
                       title= "Analysis of Media Spends (Granular Level)", 
                       save= True)

'''

# #### Correlation

# In[ ]:


all_output_files = []


# In[ ]:


# Total Impressions/Viewable Impressions/ Clicks
#Update all the variables here for the total metric for which the user wants to generate the corrrelation
#For eg, to get correlation of only Sponsored Product click update below "M_SP_CLK" instead of "M_SP_IMP" and keep rest at impressions

total_impression = ['M_ON_DIS_TOTAL_IMP', 'M_OFF_DIS_TOTAL_IMP', 'M_TOTAL_DISPLAY_IMP', 'M_SP_IMP']

# Selection of tactics at granular levels
#For eg, to get correlation of only Pinterest, update below "M_OFF_DIS_PIN_CLK" instead of "M_OFF_DIS_PIN_IMP" and keep rest at impressions

tactics = ['M_ON_DIS_CT_IMP',
 'M_ON_DIS_BT_CON_IMP',
 'M_ON_DIS_BT_CUS_IMP',
 'M_ON_DIS_BT_PRO_IMP',
 'M_ON_DIS_BT_OTHER_IMP',
 'M_ON_DIS_KW_OTHER_IMP',
 'M_ON_DIS_KW_LO_IMP',
 'M_ON_DIS_HPLO_IMP',
 'M_ON_DIS_ROS_IMP',
 'M_ON_DIS_SEA_IMP',
 'M_ON_DIS_BT_IMP',
 'M_ON_DIS_KW_IMP',
 'M_OFF_DIS_WN_DISPLAY_IMP',
 'M_OFF_DIS_WN_PREROLL_IMP',
 'M_OFF_DIS_WN_IMP',
 'M_OFF_DIS_PIN_IMP',
 'M_OFF_DIS_FB_IMP',
 'M_SP_IMP',
 'M_SP_AB_IMP',
 'M_SP_KWB_IMP',
 'M_SP_SBA_IMP',
 'M_ON_DIS_OTHERS_IMP',
 'M_ON_DIS_TOTAL_IMP',
 'M_OFF_DIS_SMEDIA_IMP',
 'M_OFF_DIS_TOTAL_IMP',
 'M_TOTAL_DISPLAY_IMP',
 'M_TOTAL_MEDIA_IMP']


# In[ ]:
'''

all_output_files.append(eda_obj.plot_heatplot(all_dummy_vars, title= "Dummy Variables Correlation",
                                              save= True))


# In[ ]:


all_output_files.append(eda_obj.plot_heatplot(all_dummy_vars, 
                                              title= "Dummy and Volume Sales Units Correlation",
                                              comparison_col= 'O_UNIT', save= True, slicing= True, length= 20))


# In[ ]:


all_output_files.append(eda_obj.plot_heatplot(all_dummy_vars, title= "Dummy and New Customer Count Correlation",
                                              comparison_col= 'O_NEW_CUSTOMER', save= True, slicing= True, length= 20))


# In[ ]:


all_output_files.append(eda_obj.plot_heatplot(all_dummy_vars, title= "Dummy and Price Correlation",
                                              comparison_col= 'PRICE', save= True, slicing= True, length= 20))


# In[ ]:


all_output_files.append(eda_obj.plot_heatplot(total_impression, title= "Impressions Correlations",
                                              save= True, slicing= False, length= 6, 
                                              breadth= 10))


# In[ ]:


all_output_files.append(eda_obj.plot_heatplot(total_impression, 
                                              title= "Impressions and New Customer Correlation",
                                              comparison_col= 'O_NEW_CUSTOMER', save= True, slicing= True, length= 6, 
                                              breadth= 10))


# In[ ]:


all_output_files.append(eda_obj.plot_heatplot(total_impression, 
                                              title= "Impressions and Volume Sales Units Correlation",
                                              comparison_col= 'O_UNIT', save= True, slicing= True, length= 6, 
                                              breadth= 10))


# In[ ]:


all_output_files.append(eda_obj.plot_heatplot(total_impression, 
                                              title= "Impressions and Price Correlation",
                                              comparison_col= 'PRICE', save= True, slicing= True, length= 6, 
                                              breadth= 10))


# In[ ]:


all_output_files.append(eda_obj.plot_heatplot(total_impression + ['PRICE', 'O_UNIT','O_NEW_CUSTOMER'], 
                                              title= "Total Impressions Correlation (Outcome Vars)", 
                                              save= True, slicing= False, length= 6, 
                                              breadth= 10))


# In[ ]:


all_output_files.append(eda_obj.plot_heatplot(tactics, title= "Impressions Tactics Correlation",
                                              save= True, length= 20, breadth= 20))


# In[ ]:


all_output_files.append(eda_obj.plot_heatplot(tactics + ['O_UNIT', 'PRICE','O_NEW_CUSTOMER'], 
                                              title= "Tactics Impressions Correlation (Price & Outcome)",
                                              save= True, length= 20, breadth= 20))


# In[ ]:


all_output_files.append(eda_obj.plot_heatplot(tactics, title= "Tactics Impressions and New Customer Count Correlation",
                                              save= True, slicing= True, length= 20, 
                                              comparison_col = 'O_NEW_CUSTOMER',
                                              breadth= 20))


# In[ ]:


'''
all_output_files.append(eda_obj.plot_heatplot(tactics, title= "Tactics Impressions and Volume Sales Units Correlation",
                                              save= True, slicing= True, length= 20, 
                                              comparison_col = 'O_UNIT',
                                              breadth= 50, nonzero = True))


# In[ ]:

'''
all_output_files.append(eda_obj.plot_heatplot(tactics, title= "Tactics Impressions and Price Correlation",
                                              save= True, slicing= True, length= 20, 
                                              comparison_col = 'PRICE',
                                              breadth= 20))


# #### Saving correlation matrices

# In[ ]:


excel_obj = SaveExcelTemplated("../../data/output_data/eda_results/eda_excel/bivariate_visualization_23.07_p1.xlsx")  
for dict_df in all_output_files:
    for key, value in dict_df.items():
        excel_obj.add_worksheet(value, key, percent_col_names= value.columns.values)


# In[ ]:


excel_obj.save_worksheet()


# #### Scatter Plots

# In[ ]:


eda_obj.total_var_scatterplot(comparison_col = "O_UNIT", key_cols= total_impression, 
                              title= 'Scatter Impressions and Volume Sales Units', save= True, height= 7,
                             ylabel= 'Volume Sales Units')


# In[ ]:


eda_obj.total_var_scatterplot(comparison_col = "O_NEW_CUSTOMER", key_cols= tactics, 
                              title= 'Scatter Tactics Impressions and New Customer Count', save= True, height= 7,
                             ylabel= 'New Customer Count')


# In[ ]:


#Media Flight Chart
#Specify the variables in the media_vars_plot for which you want to create the Media Flight Chart
#Specify Start and End date in on_air_start & on_air_end for the Media flight time period
media_vars_plot = ['M_SP_IMP', 'M_ON_DIS_BT_IMP', 'M_ON_DIS_CT_IMP', 'M_ON_DIS_HPLO_IMP',
                  'M_ON_DIS_KW_IMP','M_ON_DIS_SEA_IMP', 'M_OFF_DIS_FB_IMP',
                  'M_OFF_DIS_PIN_IMP','M_ON_DIS_ROS_IMP','M_OFF_DIS_WN_DISPLAY_IMP','M_OFF_DIS_WN_PREROLL_IMP']
eda_obj.plot_media_on_off_analysis(show_yaxis= True,
                                         on_air_start = '2018-01-01', 
                                         on_air_end= '2020-05-31', 
                                         on_air_vars= media_vars_plot,save=True)


# In[ ]:

'''


