# -*- coding: utf-8 -*-
"""
Created on Mon Apr  6 17:46:31 2020

@author: rajat.bansal
"""
import pandas as pd
import matplotlib.pyplot as plt  # Python visualization library
import seaborn as sns
import numpy as np
import os


plt.style.use('seaborn-white')

import plotly.graph_objects as go


class EDA_visualization:
    """Class to visualize variables

    Args:
        
    """
    
    color_dict = {'blue' : '#0071CE',
                  'yellow' : '#FFC220',
                  'nair' : '#041E42',
                  'charcoal' : '#414042',
                  'gray' : '#9D9FA2',
                  'light blue' : '#BDD7EE',
                  'orange' : '#F58345',
                  'red' : '#FF0000',
                  'green' : '#70AD47',
                  'brown' : '#7F6000',
                  'shade blue' : '#008EA8'}
                  
    def __init__(self, df, data_dict):
        """Class to perform most of the EDA Visulaization

        Args:
            df (pandas dataframe): Pandas dataframe on which EDA is to be done
            data_dictionary (pandas dataframe): Data Dictionary for description of variables
        """
        self.df = df
        self.data_dict = data_dict
        
        
    def create_date_vars(self, date_var):
        """Converts the datatype to appropriate date format
        
        Args:
            date_var (string): Date column name
            
        Returns: None"""
        
        self.df[date_var] = pd.to_datetime(self.df[date_var])    
        

    def get_line_plot(self, var_name, color= 'blue', plot_title= None, ylabel= None, save= False, show_ylabel= True):
        
        """Plots line plot
        
        Args:
            var_name (string): column name
            color (string, default= blue): color for line plot
            plot_title (string): Title of the plot
            ylabel(string): Label for y-axis
            save(boolean): whether to save the plot in the folder structure
            show_ylabel(boolean): hide labels on y-axis
            
        Returns: Plot the line plot"""
                
        if not ylabel : ylabel = self.data_dict[self.data_dict['Variable Name'] == var_name]['Variable Description'].values[0]
        if not plot_title : plot_title = "Trend : " + ylabel
        
        plot_line = go.Scatter(x= self.df['index'], y= self.df[var_name], 
                               line= dict(color= EDA_visualization.color_dict[color]))
        fig = go.Figure(data= plot_line)
        
        fig.update_layout(
                dict(xaxis= dict(showgrid= False, 
                                  ticks= 'outside',mirror= False, showline= True, linecolor= 'black',
                                  linewidth= 1, tickangle= 30),
                    yaxis= dict(title= ylabel if show_ylabel else '', showticklabels= show_ylabel,
                                 showgrid= False, mirror= True, ticks= 'outside' if show_ylabel else '' , showline= False,
                                 linecolor= 'black', linewidth= 1, tickformat= ', g'),
                    font= dict(size= 11, color= 'black'),
                    ),
                                
                autosize= True,
                width= 1000,
                height= 500,
                paper_bgcolor= 'rgba(0,0,0,0)',
                plot_bgcolor= 'rgba(0,0,0,0)',
                title={
                        'text': plot_title,
                        'y':0.85,
                        'x':0.48,
                        'xanchor': 'center',
                        'yanchor': 'top'}
                )
                    
        if save:
            path_new = os.path.abspath("../../data/output_data/eda_results/eda_graphs/line_charts/" + plot_title + ".png")
            try:
                fig.write_image(path_new, width= 1100, height= 500, scale= 5)
            except:
                path_new = "\\\\?\\" + path_new 
                fig.write_image(path_new, width= 1100, height= 500, scale= 5)
            
        return fig
    
    def plot_line_plot(self, var_list, color= 'yellow', save= False, show= True, show_ylabel= True):
        """Plots line plot
        
        Args:
            var_list (list): List of column name
            color (string, default= yellow): color for line plot
            save(boolean): whether to save the plot in the folder structure
            show(boolean): whether to plot the graph on IDE
            show_ylabel(boolean): hide labels on y-axis
            
        Returns: Plot the line plot"""
        for var_name in var_list:
            print(var_name)
            
            label = self.data_dict[self.data_dict['Variable Name'] == var_name]['Variable Description'].values[0]
            
            fig = self.get_line_plot(var_name, color= color, show_ylabel= show_ylabel)
            if show : fig.show()
            if save:
                path_new = os.path.abspath("../../data/output_data/eda_results/eda_graphs/line_charts/" + label + ".png")
                try:
                    fig.write_image(path_new, width= 1100, height= 500, scale= 5)
                except:
                    path_new = "\\\\?\\" + path_new 
                    fig.write_image(path_new, width= 1100, height= 500, scale= 5)
                


    
    def get_combo_plot(self, key_var_dict= {}, ylabel1= None, ylabel2= None, 
                       other_vars_dict= {}, title= None, save= False, show_ylabel= True,
                       hide_area= False):
        
        """Plots combo plots
        
        Args:
            key_var_dict (dictionary, ignore if area not required): dictionary of key-variable (along with label and color)
            ylabel1 (string): label for right y-axis
            ylabel2 (string): label for left y-axis
            other_vars_dict (dictionary): dictionary of variables with label and color
            save(boolean): whether to save the plot in the folder structure
            title(string): graph title
            show_ylabel(boolean): hide labels on y-axis
            
        Returns: Plot the combo plot"""
        
        plot_data = []
        for item, value in key_var_dict.items():
            area = go.Scatter(x= self.df['index'], y= self.df[item],
                              fill= 'tozeroy', mode= 'none', fillcolor= EDA_visualization.color_dict[value[0]], 
                              yaxis= 'y1', name= value[1])
            if not hide_area:
                plot_data.append(area)
         
        counter = 0
        for item, value in other_vars_dict.items(): 
            counter += 1
            plot_line= go.Scatter(x= self.df['index'], y= self.df[item],
                              line= dict(color= EDA_visualization.color_dict[value[0]]), yaxis='y2', name= value[1])
            
            if len(key_var_dict) == 0 and counter == 1:
                plot_line= go.Scatter(x= self.df['index'], y= self.df[item],
                              line= dict(color= EDA_visualization.color_dict[value[0]]), yaxis='y1', name= value[1])
            
            if hide_area:
                plot_line= go.Scatter(x= self.df['index'], y= self.df[item],
                              line= dict(color= EDA_visualization.color_dict[value[0]]), yaxis='y1', name= value[1])
            
            
            plot_data.append(plot_line)

        fig = go.Figure(plot_data)

        fig.update_layout(
            dict(xaxis = dict(showgrid=False, ticks='outside', mirror= True, showline= False, linecolor= 'black',
                              linewidth= 1, tickangle= 30),
                        yaxis = dict(title= ylabel1 if show_ylabel else '', showgrid=False, mirror= True, ticks= '', showline= False,
                                     linecolor= 'black', linewidth= 1, tickformat= ', g', showticklabels= show_ylabel,
                                     rangemode= 'tozero'),
                        yaxis2= dict(title= ylabel2 if show_ylabel else '', overlaying= 'y', side= 'right', tickformat= ', g',
                                     showticklabels= show_ylabel, tickmode= 'auto', rangemode='tozero'),
                        font= dict(size=10),
                        ),
            autosize= True,
            width= 1100,
            height= 500,
            paper_bgcolor= 'rgba(0,0,0,0)',
            plot_bgcolor= 'rgba(0,0,0,0)',
            title={
                'text': title,
                'y':0.8,
                'x':0.46,
                'xanchor': 'center',
                'yanchor': 'top'},
            legend_orientation = 'h',
            legend=dict(x=0.17,y=-.15)
        )
                        
        if save:
            if key_var_dict == {}:
                path_new = os.path.abspath("../../data/output_data/eda_results/eda_graphs/bivariate_charts/trend/" 
                                           + title + ".png")
                try:
                    fig.write_image(path_new, width= 1100, height= 500, scale= 5)
                except:
                    path_new = "\\\\?\\" + path_new 
                    fig.write_image(path_new, width= 1100, height= 500, scale= 5)
            else:
                path_new = os.path.abspath("../../data/output_data/eda_results/eda_graphs/combo_charts/" + title + ".png")
                try:
                    fig.write_image(path_new, width= 1100, height= 500, scale= 5)
                except:
                    path_new = "\\\\?\\" + path_new 
                    fig.write_image(path_new, width= 1100, height= 500, scale= 5)
        fig.show()
        

    
    def plot_heatplot(self, key_columns, title, comparison_col= "", var_type= None, length= 30, breadth= 50,
                      size= 20, save= True, slicing= False, color= "Blues", nonzero = False):

        """Plots scatter plots
        
        Args:
            key_columns (list): list of key variables
            title(string): graph title
            comparison_col(string): additional column to be compared
            var_type(string): defines the type of variable (can be ignored)
            length(int): length of graph
            breadth(int): breadth of graph
            size(int): plot size
            save(boolean): whether to save the plot in the folder structure
            slicing(boolean): slices the correlation plot for better visualization
            color(string): color pallete (some available are Blues_d, RdBu, deep, muted, bright, pastel, dark, colorblind)
            nonzero: ignores zeros during correlation
        Returns: Plot the combo plot"""
        
        df_plot = self.df.drop(columns = ['index'])
        
        if nonzero == False:
            df_plot = df_plot[[col for col in df_plot.columns if col in [comparison_col] + key_columns]].fillna(0)
        else:
            df_plot = df_plot[[col for col in df_plot.columns if col in [comparison_col] + key_columns]].replace(0, np.nan)

            
        df_corr = df_plot.corr()
        df_corr = df_corr.fillna(0)
        if slicing:
            df_corr = df_corr.loc[:,comparison_col].to_frame().sort_values(by = comparison_col, ascending=False)
        all_data_dict = {}
        
        all_data_dict[title[0:30]] = df_corr.reset_index()
        
        fig = plt.figure(figsize=(breadth, length))
        ax = fig.add_subplot(111)
        cmap1 = sns.color_palette(color)
        ax = sns.heatmap(df_corr, annot=True, annot_kws={"size": size}, vmin=-1, vmax=1, linewidths=0.5, cmap=cmap1)
        ticks = np.arange(0.5,len(key_columns) + 1, 1)
        ax.set_xticks(ticks)
        ax.set_yticks(ticks)
        
        
        mapping_dict = {}
        for col in df_corr.index.values:
            value = self.data_dict[self.data_dict['Variable Name'] == col]['Variable Description'].values[0]
            value = value.replace(" Impression", "").replace("Product ", "")
            value = value.replace("Dummy ", "")
            mapping_dict[col] = value
    
        ax.set_xticklabels(df_corr.columns.map(mapping_dict), fontsize=22)
        ax.set_yticklabels(df_corr.index.map(mapping_dict), fontsize=22)
        
        plt.title(title, fontsize=30,y=1.1)
        if save:
            path_new = os.path.abspath("../../data/output_data/eda_results/eda_graphs/bivariate_charts/correlation/" +
                                       title + '.png')
            try:
                plt.savefig(path_new, pad_inches=0.1, bbox_inches='tight')
            except:
                path_new = "\\\\?\\" + path_new 
                plt.savefig(path_new, pad_inches=0.1, bbox_inches='tight')
        plt.show()
        
        return all_data_dict
                        

    def total_var_scatterplot(self, comparison_col, key_cols, title= None, ylabel= None, 
                              save= False, height = 9, size = 150):
        df_plot = self.df.drop(columns = ['index'])
        
        for col in key_cols:       
            sns.pairplot(df_plot, y_vars = comparison_col, x_vars= col,
                         height=height, aspect=10.7/7.27, plot_kws={"s": size})
            
            value = self.data_dict[self.data_dict['Variable Name'] == col]['Variable Description'].values[0]
            value = value.replace(" Impression", "").replace("Product ", "")
            value = value.replace("Dummy ", "")
            plt.xlabel(value)
            plt.ylabel(ylabel)
            plt.title(title + " (" + value + ")")
    
        
            if save:
                path_new = os.path.abspath("../../data/output_data/eda_results/eda_graphs/bivariate_charts/scatter/" 
                                           + title + " (" + value + ").png")
                try:
                    plt.savefig(path_new, pad_inches=0.1,  bbox_inches='tight')
                except:
                    path_new = "\\\\?\\" + path_new 
                    plt.savefig(path_new, pad_inches=0.1,  bbox_inches='tight')
                
                
    def plot_cumulative_plot(self, media_col, show_yaxis= True, color= 'blue', save= True):
        
        media_label = self.data_dict[self.data_dict['Variable Name'] == media_col]['Variable Description'].values[0]
        
        area = go.Scatter(x= self.df['index'], 
                          y= self.df[media_col].cumsum()/self.df[media_col].sum(),
                          fill= 'tozeroy', mode= 'none', fillcolor= EDA_visualization.color_dict[color], 
                          yaxis= 'y1', name= media_label)
        plot_data = [area]
        fig = go.Figure(plot_data)

        title = 'Cumulative ' + media_label
        fig.update_layout(
            dict(xaxis = dict(showgrid=False, ticks='outside', mirror= True, showline= False, linecolor= 'black',
                              linewidth= 1, tickangle= 30),
                        yaxis = dict(title= media_label if show_yaxis else '', 
                                     showgrid=False, mirror= True, ticks= '', showline= False,
                                     linecolor= 'black', linewidth= 1, tickformat= ',.0%', 
                                     showticklabels= show_yaxis,
                                     rangemode= 'tozero'),
                        font= dict(size=10),
                        ),
            autosize= True,
            width= 1100,
            height= 500,
            paper_bgcolor= 'rgba(0,0,0,0)',
            plot_bgcolor= 'rgba(0,0,0,0)',
            title={
                'text': title,
                'y':0.8,
                'x':0.46,
                'xanchor': 'center',
                'yanchor': 'top'},
            legend_orientation = 'h',
            legend=dict(x=0.17,y=-.15)
        )

        if save:
            path_new = os.path.abspath("../../data/output_data/eda_results/eda_graphs/line_charts/" + title + ".png")
            try:
                fig.write_image(path_new, width= 1100, height= 500, scale= 5)
            except:
                path_new = "\\\\?\\" + path_new 
                fig.write_image(path_new, width= 1100, height= 500, scale= 5)
        
        fig.show()
    




    def plot_media_on_off_analysis(self,on_air_start, on_air_end, 
                                   on_air_vars, show_yaxis= True, save_path= None):
        
        df_air_days = self.df[(self.df['index'] >= on_air_start) & (self.df['index'] <= on_air_end)].copy()
        df_air_days = df_air_days[on_air_vars]
        
        mapping_dict = {}
        for col in on_air_vars:
            value = self.data_dict[self.data_dict['Variable Name'] == col]['Variable Description'].values[0]
            mapping_dict[col] = value
        
        df_air_analysis = pd.DataFrame(on_air_vars, columns= ['Variable'])
        df_air_analysis['Variable'] = df_air_analysis['Variable'].map(mapping_dict)
        df_air_analysis['Total Days'] = df_air_days.shape[0]
        df_air_analysis['On Air Days'] = (df_air_days > 0).sum().values
        df_air_analysis['Off Air Days'] = df_air_analysis['Total Days'] - df_air_analysis['On Air Days'] 
        df_air_analysis = df_air_analysis.sort_values(by= 'On Air Days', ascending= False).reset_index(drop= True)
        
        df_air_analysis['On Air Days'] = 100 * df_air_analysis['On Air Days']/df_air_analysis['Total Days']
        df_air_analysis['Off Air Days'] = 100 * df_air_analysis['Off Air Days']/df_air_analysis['Total Days']
        
        fig = go.Figure(data=[
            go.Bar(name='On Air Days', y= df_air_analysis.Variable, 
                   x= df_air_analysis['On Air Days'].values,
                   marker_color= '#4372c4',
                   textposition= 'inside',
                   text= df_air_analysis['On Air Days'].apply(lambda x : round(x,0)).astype(int).astype(str) + "%",
                   orientation='h'),
            
            go.Bar(name='Off Air Days', y= df_air_analysis.Variable,
                   x= df_air_analysis['Off Air Days'].values,
                   marker_color= '#dae4f4',
                   orientation='h')
            
        ])

        fig.update_layout(dict(xaxis = dict(showgrid= False, ticks= 'outside', mirror= False, showline= False,
                                            linecolor= '#CED0D2', linewidth=1, tickangle= 0),
                                            
                               yaxis = dict(showgrid= False, mirror= True, ticks= '', showline= False, 
                                            showticklabels= show_yaxis,
                                            linecolor= 'black', linewidth= 1, tickformat= ',.1f', rangemode= 'tozero'),
                                            
                               yaxis2 = dict(overlaying= 'y', side= 'right', tickformat= ',.1f',
                                             showticklabels= show_yaxis,
                                             tickmode= 'auto', rangemode= 'tozero'), 
                                             
                               font=dict(size= 14),),
                                             
                            autosize= True,
                            width= 1000,
                            height= 500,
                            paper_bgcolor= 'rgba(0,0,0,0)',
                            plot_bgcolor= 'rgba(0,0,0,0)',
                            title={
                                'text': "Media Flight",
                                'y': 0.95,
                                'x': 0.5,
                                'xanchor': 'center',
                                'yanchor': 'top',
                                'font': dict(size= 20)},
                                legend_orientation= 'h',
                                legend=dict(x= 0.05, y= -0.25, font= dict(size= 14)))        

        fig.update_layout(barmode='stack')
        
        if not save_path:
            fig.show();
        
        if save_path:
            fig.write_image(os.path.join(save_path, "Media Flight.png"),
                      scale= 5)
