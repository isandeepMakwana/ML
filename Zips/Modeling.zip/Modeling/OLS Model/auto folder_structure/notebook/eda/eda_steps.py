# -*- coding: utf-8 -*-
"""
Created on Tue Mar 31 17:16:27 2020

@author: rajat.bansal
"""
from sklearn.preprocessing import StandardScaler # Calculation of Z-Scores
import pandas as pd
import numpy as np
import warnings
warnings.filterwarnings('ignore')


def calculate_percentage_share(df, data_dict, total_var, all_vars, metric, spend_vars, key,custom_start_dt,custom_end_dt):
    
    df = df[((df['index'] <= custom_end_dt) & (df['index'] >= custom_start_dt))]
    df = df.drop(columns = ['index'])
    
    total_sum = df[total_var].sum()
    
    df_perct_analysis = df[all_vars]
    df_perct_analysis = df_perct_analysis.melt().groupby('variable')['value'].sum().reset_index()
    
    spend_vars = [var for var in df.columns if var in spend_vars]
    df_spend_analysis = df[spend_vars]
    df_spend_analysis = df_spend_analysis.melt().groupby('variable')['value'].sum().reset_index()
    
    df_spend_analysis.variable = df_spend_analysis.variable.apply(lambda x: str(x).replace('SPEND', key))
    
    df_spend_analysis.rename(columns = {'value':'Total Spends', 'variable':'Variable Name'}, inplace=True)
    
    df_perct_analysis.rename(columns = {'value':metric,'variable':'Variable Name'}, inplace=True)
    
    df_perct_analysis[metric + ' Share (%age)'] = df_perct_analysis[metric]/total_sum
    
    df_perct_analysis = df_perct_analysis.merge(df_spend_analysis, how= 'left')
    df_perct_analysis['Cost per ' + metric]  = df_perct_analysis['Total Spends'] / df_perct_analysis[metric]
    
    df_perct_analysis = df_perct_analysis.sort_values(by= metric + ' Share (%age)', ascending= False)
    
    df_perct_analysis = df_perct_analysis.merge(data_dict[['Variable Name', 'Variable Type', 'Product Type', 'Media Hierarchy', 
                                                             'Tactic', 'Sub-Tactic']], on = 'Variable Name', how = 'left')
    
    df_perct_analysis = df_perct_analysis.sort_values(by= ['Media Hierarchy', 'Product Type', metric + ' Share (%age)' ],
                                                           ascending= [True, False, False])
    if metric != 'Spend':
        if metric == 'Impression':
            df_perct_analysis['Cost per ' + metric] = 1000 * df_perct_analysis['Cost per ' + metric]
            df_perct_analysis = df_perct_analysis.rename(columns = {'Cost per ' + metric : 'CPM'})
            df_perct_analysis = df_perct_analysis[['Variable Name', 'Product Type', 'Tactic',  'Sub-Tactic', metric, 
                                               'Total Spends', 'CPM', metric + ' Share (%age)']]
        else:
            df_perct_analysis = df_perct_analysis[['Variable Name', 'Product Type', 'Tactic',  'Sub-Tactic', metric, 
                                                   'Total Spends', 'Cost per ' + metric, metric + ' Share (%age)']]
    else:
        
        df_perct_analysis = df_perct_analysis[['Variable Name', 'Product Type', 'Tactic',  'Sub-Tactic', metric, 
                                                metric + ' Share (%age)']]
    return df_perct_analysis
            
            
class EDA:
    """Class to perform most of the EDA Steps

    Args:
        df (pandas dataframe): Pandas dataframe on which EDA is to be done
        data_dictionary (pandas dataframe): Data Dictionary for description of variables
    """
    
    def __init__(self, df, data_dictionary):
        self.df = df
        self.data_dictionary = data_dictionary
        
    def evaluate_outliers(self, all_vars, lower_z_score= -3, upper_z_score= 3):
        """Analysis of Outliers

        Args:
            all_vars (list): List of variables required for analysis
            lower_z_score (int/float): Lower value of Z-Score
            upper_z_score (int/float): Upper value of Z-Score
    
        Returns:
            pandas dataframe: Analytical output of Oulier Detection for all the variables
        """
        
        # Calculation of Z_Score
        scaler = StandardScaler()
        df_scaled = self.df[all_vars].copy()
        df_scaled[all_vars] = scaler.fit_transform(df_scaled)
        dict_outlier_analysis = {'Variable': [], 
                         'Total #Outliers': [], 'Total #Low Outliers': [], 'Total #High Outliers': [],
                         'Minimum Capped Value': [], 'Maximum Capped Value': [], 'Mean': []}
        for i, var in enumerate(all_vars):
            dict_outlier_analysis['Variable'].append(var)
            dict_outlier_analysis['Total #Low Outliers'].append((df_scaled[var] <= lower_z_score).sum())
            dict_outlier_analysis['Total #High Outliers'].append((df_scaled[var] >= upper_z_score).sum())
            dict_outlier_analysis['Total #Outliers'].append((df_scaled[var] <= lower_z_score).sum() + 
                                                            (df_scaled[var] >= upper_z_score).sum())
            
            dict_outlier_analysis['Mean'].append(round(self.df[var].mean(),2))
            
            dummy_array = np.zeros((1, df_scaled.shape[1]))
            dummy_array[0, i] = lower_z_score
            min_capped_value = round(scaler.inverse_transform(dummy_array)[0,i], 2)
            dict_outlier_analysis['Minimum Capped Value'].append(min_capped_value)
            
            dummy_array = np.zeros((1, df_scaled.shape[1]))
            dummy_array[0, i] = upper_z_score
            max_capped_value = round(scaler.inverse_transform(dummy_array)[0,i], 2)
            dict_outlier_analysis['Maximum Capped Value'].append(max_capped_value)
        
        df_outlier_analysis = pd.DataFrame(dict_outlier_analysis)
        
        df_outlier_analysis = df_outlier_analysis.merge(self.data_dictionary, 
                                                        left_on= 'Variable', right_on= 'Variable Name', how= 'left')
        
        df_outlier_analysis = df_outlier_analysis[['Variable', 'Variable Type', 'Variable Description',
                                                   'Total #Outliers', 'Total #Low Outliers', 'Total #High Outliers',
                                                   'Minimum Capped Value', 'Maximum Capped Value', 'Mean']]
        
        return df_outlier_analysis
    
    ###############################################################################################
    
    def analyse_sparsity(self, all_vars, custom_start_dt,custom_end_dt,media= False):
        """Analysis of Sparsity
        
        Args:
            all_vars (list): List of variables required for analysis
            media (boolean, default = False): Set it to True for analysis of Media Variables
            
        Returns:
            dictionary: Dictionary of all the dataframes having sparsity checks
        """
        
        df_sparsity_analsysis = self.df[['index'] + all_vars].copy()
        
        df_sparsity_treatment = pd.DataFrame(df_sparsity_analsysis.isnull().sum(), 
                                             columns=['no_of_missing_values']).reset_index()
        
        df_sparsity_treatment.rename(columns = {'index':'variable'}, inplace=True)
        df_sparsity_treatment['missing_value_%age'] = df_sparsity_treatment['no_of_missing_values']/df_sparsity_analsysis.shape[0]
        
        # Variables having more than 50% missing values
        df_missing_value = df_sparsity_treatment[df_sparsity_treatment['missing_value_%age']>0.5]
    
        missing_value_list = list(df_sparsity_treatment[df_sparsity_treatment['missing_value_%age']>0.5]['variable'])
        print("No. of variables having more than 50% missing values: ", len(missing_value_list))
    
        all_dataframes = {} # Dictionary to save all dataframes
        if len(missing_value_list)>0:
            df_missing_value.rename(columns = {'variable':'Variable Name','missing_value_%age':'%age of missing values'}, inplace=True)
            df_missing_value = df_missing_value.merge(self.data_dictionary[['Variable Name','Variable Type','Variable Description']],
                                        on = 'Variable Name',how = 'left')
            df_missing_value = df_missing_value[['Variable Name','Variable Type','Variable Description','%age of missing values']]        

            all_dataframes['>50% Missing Data'] = df_missing_value
        else:
            print("There are no such variables having more than 50% missing values !!")
        
    
        df2 = df_sparsity_analsysis.drop(columns = ['index'])
        #df2 = df_sparsity_analsysis
        non_zero_col_list = []
        non_zero_val_list = []
        for col in df2.columns:
            a = df2[df2[col]>0][col].count()/df2.shape[0]
            if a<0.30:
                non_zero_col_list.append(col)
                non_zero_val_list.append(a)
        list_of_tuples = list(zip(non_zero_col_list, non_zero_val_list))
                
        print("No. of variables having less than 30% non-zero data points: ", len(non_zero_col_list))
        
        if len(non_zero_col_list)>0:
            df_non_zero = pd.DataFrame(list_of_tuples, columns=['Variable Name','%age of non-zero data points'])
            df_non_zero = df_non_zero.merge(self.data_dictionary[['Variable Name','Variable Type','Variable Description']],
                                        on = 'Variable Name',how = 'left')
            df_non_zero = df_non_zero[['Variable Name','Variable Type','Variable Description','%age of non-zero data points']]
            all_dataframes['<30% data percent'] = df_non_zero
        else:
            print("There are no variables having less than 30% non-zero data points !!")
        
        if media:
            # Media requires drill down at Onsite, Sponsored and Offsite Display
            metric_dictionary = {'IMP' : 'Impression',
                                 'SPEND' : 'Spend',
                                 'VIEW_IMP' : 'Viewable Impression',
                                 'CLK' : 'Click'}
            
            # Analysis of Level 2, 3 and 4
            for key, value in metric_dictionary.items():
                required_vars = self.data_dictionary[(self.data_dictionary['Metric'] == value) & 
                                                     (self.data_dictionary['Media Hierarchy'].isin([2, 3, 4])) &
                                                      (self.data_dictionary['Metric'] == value)]['Variable Name'].values
                                                     
                spend_vars = self.data_dictionary[(self.data_dictionary['Metric'] == 'Spend') & 
                                                  (self.data_dictionary['Media Hierarchy'].isin([2, 3, 4])) &
                                                  (self.data_dictionary['Metric'] == 'Spend')]['Variable Name'].values
                
                required_vars = [var for var in all_vars if var in required_vars]
                
                total_var = self.data_dictionary[(self.data_dictionary['Metric'] == value) & 
                                                     (self.data_dictionary['Media Hierarchy'].isin([2])) &
                                                      (self.data_dictionary['Metric'] == value)]['Variable Name'].values[0]
                
                #print(df_sparsity_analsysis.dtypes)
                
                df_final = calculate_percentage_share(df= df_sparsity_analsysis, 
                                               data_dict= self.data_dictionary, 
                                               total_var= total_var, all_vars= required_vars, metric= value,
                                               spend_vars = spend_vars,
                                               key= key,custom_start_dt=custom_start_dt,custom_end_dt=custom_end_dt)
    
                all_dataframes['Overall ' + value] = df_final 
             
                
            # Analysis of Granular levels 
            for product_type in ['Onsite Display', 'Sponsored Product', 'Offsite Display']:
                for key, value in metric_dictionary.items():
                    if product_type == 'Offsite Display':
                        valid_product_type = ['Offsite Display', 'Pinterest', 'Instagram', 'Facebook']
                    else:
                        valid_product_type = [product_type]
                    
                    if product_type == 'Sponsored Product':
                        valid_levels = [4, 3]
                        total_level = [3]
                    else:
                        valid_levels = [6, 5, 4]
                        total_level = [4]
                        
                    required_vars = self.data_dictionary[(self.data_dictionary['Metric'] == value) & 
                                                         (self.data_dictionary['Product Type'].isin(valid_product_type)) &
                                                         (self.data_dictionary['Media Hierarchy'].isin(valid_levels)) &
                                                          (self.data_dictionary['Metric'] == value)]['Variable Name'].values
                                                         
                    spend_vars = self.data_dictionary[(self.data_dictionary['Metric'] == 'Spend') & 
                                                         (self.data_dictionary['Product Type'].isin(valid_product_type)) &
                                                         (self.data_dictionary['Media Hierarchy'].isin(valid_levels)) &
                                                          (self.data_dictionary['Metric'] == 'Spend')]['Variable Name'].values
                    
                    required_vars = [var for var in all_vars if var in required_vars]
                    
                    total_var = self.data_dictionary[(self.data_dictionary['Metric'] == value) & 
                                                     (self.data_dictionary['Product Type'].isin(valid_product_type)) &
                                                     (self.data_dictionary['Media Hierarchy'].isin(total_level)) &
                                                     (self.data_dictionary['Metric'] == value)]['Variable Name'].values[0]
                                        
                    if len(required_vars) > 0:
                        
                        df_final = calculate_percentage_share(df= df_sparsity_analsysis, 
                                                       data_dict= self.data_dictionary, 
                                                       total_var= total_var, all_vars= required_vars, metric= value,
                                                       spend_vars= spend_vars,
                                                       key= key,custom_start_dt=custom_start_dt,custom_end_dt=custom_end_dt)
            
                        all_dataframes[product_type.split(" ")[0] + " " + value] = df_final 


        return all_dataframes
    
    ###############################################################################################
    
    def evaluate_descriptive_stats(self, all_vars):
        """Univariate analysis: Analysis of descriptive stats like Mean, Mode etc.

        Args:
            all_vars (list): List of variables required for analysis
    
        Returns:
            pandas dataframe: Analytical output with descriptive statistics for all the variables
        """
        df_numeric = self.df[all_vars]
        df_numeric_describe = df_numeric.describe().T.reset_index()
        df_numeric_describe = df_numeric_describe.rename(columns= {'index': 'Variable',
                                                                 'mean': 'Mean',
                                                                 'count': 'Count',
                                                                 'std': 'Standard Deviation',
                                                                 'min': 'Minimum',
                                                                 'max': 'Maximum',
                                                                 '25%': 'Quartile_1',
                                                                 '75%': 'Quartile_3',
                                                                 '50%': 'Median'})
        
        
        #Total sum
        df_numeric_describe['Sum'] = df_numeric.sum().values
        
        # Missing values
        df_numeric_describe['#Zeroes'] = (df_numeric == 0).sum().values
        df_numeric_describe['#Non-Zeroes'] = (df_numeric != 0).sum().values              
        
        # Median and mode                     
        df_numeric_describe["Mode"] = df_numeric.mode().iloc[0].values
        df_numeric_describe["Variance"] = df_numeric.var().values
        df_numeric_describe["Skewness"] = df_numeric.skew().values
        df_numeric_describe["Kurtosis"] = df_numeric.kurtosis().values
        
        df_numeric_describe['IQR'] = df_numeric_describe['Quartile_3'] - df_numeric_describe['Quartile_1']
        
        round_off_vars = ['Mean', 'Median', 'Mode','Sum',
                          'Variance', 'Standard Deviation',
                          'Minimum', 'Maximum',
                          'Quartile_1', 'Quartile_3', 'IQR']
        #print(round_off_vars)
        df_numeric_describe[round_off_vars] = df_numeric_describe[round_off_vars].astype(np.int64)
        #print(df_numeric_describe[round_off_vars])
        df_numeric_describe = df_numeric_describe.merge(self.data_dictionary, 
                                                        left_on= 'Variable', right_on= 'Variable Name', how= 'left')
        
        new_cols = ['Non-Zero Mean', 'Non-Zero Median', 'Non-Zero Standard Deviation']
        for col in new_cols:
            df_numeric_describe[col] = 0
            
        for i, var in enumerate(df_numeric_describe.Variable.values):
            series = df_numeric[var]
            series = series[series!=0]
            
            df_numeric_describe.loc[i, 'Non-Zero Mean'] = series.mean()
            df_numeric_describe.loc[i, 'Non-Zero Median'] = series.median()
            df_numeric_describe.loc[i, 'Non-Zero Standard Deviation'] = series.std()
        
        
        df_numeric_describe = df_numeric_describe[['Variable', 'Variable Type', 'Variable Description','Sum',
                                                   'Mean', 'Median', 'Mode',
                                                   'Variance', 'Standard Deviation', 
                                                   'Non-Zero Mean', 'Non-Zero Median', 'Non-Zero Standard Deviation',
                                                   'Skewness', 'Kurtosis',
                                                   'Minimum', 'Maximum', 'Count', '#Non-Zeroes', '#Zeroes',
                                                   'Quartile_1', 'Quartile_3', 'IQR']]
        
        
        
        return df_numeric_describe

    ###############################################################################################
    
    def get_on_off_days(self):
        """Analysis of On & Off days for media variables
    
        Returns:
            Dictionary: Dictionary of dataframes at different hierarchy of media vairables
        """
        df_final = (self.df == 0).sum().reset_index()
        df_final.columns = ['Variable', 'Off-Days']
        df_final['On-Days'] = (self.df != 0).sum().values
        df_final['Total Days'] = df_final['On-Days'] + df_final['Off-Days']
        df_final['Off-Days percentage'] = df_final['Off-Days']/df_final['Total Days']
        df_final['On-Days percentage'] = df_final['On-Days']/df_final['Total Days']
        
        
        metric_dict = {'IMP': 'Impression',
                       'SPEND': 'Spend',
                       'VIEW_IMP': 'Viewable Impression',
                       'CLK': 'Click'}
        
        total_cols = []
        for key, value in metric_dict.items():
            total_cols.append('M_ON_DIS_TOTAL_' + key)
            total_cols.append('M_OFF_DIS_TOTAL_' + key)
            total_cols.append('M_SP_' + key)
            total_cols.append('M_TOTAL_DISPLAY_' + key)
            total_cols.append('M_TOTAL_MEDIA_' + key)

        df_final_total = df_final[df_final.Variable.isin(total_cols)]
        
        df_final_total = df_final_total.merge(self.data_dictionary, 
                                                        left_on= 'Variable', right_on= 'Variable Name', how= 'left')
        df_final = df_final.merge(self.data_dictionary, 
                                                        left_on= 'Variable', right_on= 'Variable Name', how= 'left')
        
        df_final_total = df_final_total.sort_values(by= ['Metric', 'Product Type'])
        
        df_final_total = df_final_total[['Metric', 'Product Type', 'Variable', 'Tactic', 'On-Days', 'Off-Days',
                                         'Total Days', 'Off-Days percentage', 'On-Days percentage']]
        
        output_data_dict = {'On-Off Total' : df_final_total}
                
        for media_type in ['Onsite', 'Offsite', 'Sponsored']:
            if media_type == 'Onsite':
                level_required = [5]
                vars_required = [col for col in self.df.columns if str(col).startswith('M_ON_DIS')]
            elif media_type == 'Offsite':
                level_required = [5]
                vars_required = [col for col in self.df.columns if str(col).startswith('M_OFF_DIS')]
            else:
                level_required = [4]
                vars_required = [col for col in self.df.columns if str(col).startswith('M_SP_')]
            
            df_final_total = df_final[(df_final['Media Hierarchy'].isin(level_required)) & 
                                      df_final['Variable'].isin(vars_required)]
            
            df_final_total = df_final_total.sort_values(by= ['Metric', 'Product Type'])
            df_final_total = df_final_total[['Metric', 'Product Type', 'Variable', 'Tactic', 'On-Days', 'Off-Days',
                                             'Total Days', 'Off-Days percentage', 'On-Days percentage']]
            
            output_data_dict[media_type + ' - On Off Granular'] = df_final_total
                
        return output_data_dict
        
        
    def calculate_tabular_analysis(self, all_vars, start_date_1, start_date_2,
                                   end_date_1, end_date_2, var_type = 'Outcome'):
        """Tabular analysis: Year on year change

        Args:
            all_vars (list): List of variables required for analysis
            start_date_1, end_date_1 (dates): Period 1
            start_date_2, end_date_2 (dates): Period 2
            var_type (optional, default= 'Outcome', str): Analysis required for Media or Outcome Variables.
    
        Returns:
            dictionary: Analytical output with tabular analysis, having multiple dataframes
        """
        all_data_outputs = {}
        
        
        df_tabular = self.df.copy()
        df_tabular['D_DATE'] = pd.to_datetime(df_tabular['index'])
        # df_tabular['D_YEAR'] = df_tabular['D_DATE'].dt.year
        # df_tabular = df_tabular[df_tabular.D_YEAR.isin([year_1, year_2])]
        
        df_tabular = df_tabular[(df_tabular['D_DATE'] >= start_date_1) &
                                (df_tabular['D_DATE'] <= end_date_2)]
        
        df_tabular['Period'] = np.where((df_tabular['D_DATE'] >= start_date_1) &
                                        (df_tabular['D_DATE'] <= end_date_1),
                                        'Period 1',
                                        'Period 2')
        
        
        
        if var_type == 'Pricing':
            df_tabular = df_tabular.groupby('Period')[all_vars].mean().T.reset_index()
            year_1_col = 'Period 1 ({} - {})'.format(start_date_1, end_date_1) 
            year_2_col = 'Period 2 ({} - {})'.format(start_date_2, end_date_2) 
            change_col = 'YOY Change'
        else:
            df_tabular = df_tabular.groupby('Period')[all_vars].sum().T.reset_index()
            year_1_col = "Period 1 ({} - {}) (in thousands)".format(start_date_1, end_date_1) 
            year_2_col = "Period 2 ({} - {}) (in thousands)".format(start_date_2, end_date_2) 
            change_col = 'YOY Change (in thousands)'
            
        df_tabular.columns = ['Variable', year_1_col, year_2_col]
        
        df_tabular[change_col] = df_tabular[year_2_col] - df_tabular[year_1_col]
        df_tabular['YOY %-age change'] = df_tabular[change_col]/df_tabular[year_1_col]
        
        df_tabular['YOY %-age change'] = df_tabular['YOY %-age change'].replace(np.inf, 0)
        df_tabular['YOY %-age change'] = df_tabular['YOY %-age change'].fillna(0)
        
        thousand_cols = [year_1_col, year_2_col, change_col]
        
        if var_type != 'Pricing':
            df_tabular[thousand_cols] = df_tabular[thousand_cols]/1000
        
        df_tabular = df_tabular.merge(self.data_dictionary, 
                                      left_on= 'Variable', right_on= 'Variable Name', how= 'left')
        
        
        if var_type in ['Outcome', 'Pricing']:
            df_tabular = df_tabular[['Variable', 'Variable Description', year_1_col, year_2_col, 
                                     change_col, 'YOY %-age change']]
            all_data_outputs[var_type + ' Variables'] = df_tabular
        
        
        if var_type == 'Media':
            for product_type in ['Onsite Display', 'Sponsored Product', 'Offsite Display']:
                for metric in ['Impression', 'Click', 'Viewable Impression', 'Spend']:
                    product_type_list = [product_type]
                    
                    if product_type == 'Offsite Display':
                        product_type_list = ['Offsite Display', 'Email', 'Facebook', 'Pinterest']
                        
                    required_variables = self.data_dictionary[(self.data_dictionary['Product Type'].isin(product_type_list)) & 
                                                              (self.data_dictionary['Metric'] == metric)]['Variable Name'].values
                                                              
                    required_variables = [var for var in all_vars if var in required_variables]
                    
                    df_tabular_final = df_tabular[df_tabular.Variable.isin(required_variables)]
                    
                    df_tabular_final['sorting_var'] = np.where(df_tabular_final['Tactic'] == 'Total', 0, 3)
                    df_tabular_final['sorting_var'] = np.where(df_tabular_final['Tactic'].isnull(), 1, 
                                    df_tabular_final['sorting_var'])
                    df_tabular_final['sorting_var'] = np.where(df_tabular_final['Tactic'] == 'Others', 2, 
                                    df_tabular_final['sorting_var'])
                    
                    df_tabular_final = df_tabular_final.sort_values(by = 'sorting_var')
                    
                    dict_label = product_type.split(" ")[0] + " " + metric.split(" ")[0]
                    
                    if df_tabular_final.shape[0] > 0:
                        all_data_outputs[dict_label] = df_tabular_final[['Variable', 'Product Type', 'Tactic',
                                        year_1_col, year_2_col, change_col, 'YOY %-age change']]
                        
            for product_type in df_tabular['Product Type'].unique():
                df_tabular_final = df_tabular[df_tabular['Product Type'] == product_type]
                
                df_tabular_final['sorting_var'] = np.where(df_tabular_final['Tactic'] == 'Total', 0, 3)
                df_tabular_final['sorting_var'] = np.where(df_tabular_final['Tactic'].isnull(), 1, 
                                df_tabular_final['sorting_var'])
                df_tabular_final['sorting_var'] = np.where(df_tabular_final['Tactic'] == 'Others', 2, 
                                df_tabular_final['sorting_var'])
                    
                df_tabular_final = df_tabular_final.sort_values(by = ['Metric', 'sorting_var'])
                
                df_tabular_final = df_tabular_final[['Product Type', 'Variable', 'Variable Description',
                                               year_1_col, year_2_col, change_col, 'YOY %-age change']]
                
                all_data_outputs['Media - ' + str(product_type)] = df_tabular_final
            
            
                            
        return all_data_outputs
            
        
        