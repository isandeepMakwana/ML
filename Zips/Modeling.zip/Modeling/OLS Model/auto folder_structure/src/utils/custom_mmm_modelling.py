# -*- coding: utf-8 -*-
"""
Created on Wed Apr 29 14:14:09 2020
Updated on Fri Sep 08 2021 by rohan garg
@author: rajat.bansal
"""
import pandas as pd
from sklearn.preprocessing import StandardScaler, MinMaxScaler
import statsmodels.api as sm
from scipy.stats.mstats import zscore
from statsmodels.stats.outliers_influence import variance_inflation_factor
from save_excel import SaveExcelTemplated
import numpy as np
from sklearn.metrics import r2_score
from IPython.display import display
import plotly.graph_objects as go
from custom_variable_transformation import VariableTransformation
from custom_transformation_functions import ccurve_transformation
from custom_transformation_functions import lag_transformation, halflife_transformation, adstock_transformation
from custom_transformation_functions import scurve_transformation
from custom_modelling_plots import ModellingPlots
from custom_waterfall_chart import plot_waterfall
import os
import seaborn as sns
import matplotlib.pyplot as plt
from datetime import datetime
import re
import time
import matplotlib
matplotlib.rcParams.update({'font.size': 13})

import warnings
warnings.filterwarnings('ignore')

def filter_media_type(df, media_type):
    if media_type == 'Sponsored':
        identifier = df.Variable.str.startswith('M_SP')
    elif media_type == 'Onsite':
        identifier = df.Variable.str.startswith('M_ON')
    else:
        identifier = ~((df.Variable.str.startswith('M_ON')) | (df.Variable.str.startswith('M_SP')))
    return identifier


def get_particular_media_transf(media_metric, media_type, file_path_pattern, media_dictionary):
    
    media_1_df = pd.read_excel(file_path_pattern.format(media_dictionary[media_metric].lower()),
                              sheet_name= 'Media Transformations - 1')
    media_1_df_filtered = media_1_df[filter_media_type(media_1_df, media_type)]
    
    media_2_df = pd.read_excel(file_path_pattern.format(media_dictionary[media_metric].lower()),
                              sheet_name= 'Media Transformations - 2')
    media_2_df_filtered = media_2_df[filter_media_type(media_1_df, media_type)]
    
    media_3_df = pd.read_excel(file_path_pattern.format(media_dictionary[media_metric].lower()),
                              sheet_name= 'Media Transformations - 3')
    media_3_df_filtered = media_3_df[filter_media_type(media_1_df, media_type)]
    
    return (media_1_df_filtered, media_2_df_filtered, media_3_df_filtered)

def load_media_transf(sponsored_media, online_media, offline_media, file_path_pattern, media_dictionary):
    
    sponsored_media = get_particular_media_transf(sponsored_media, 'Sponsored', file_path_pattern, media_dictionary)
    online_media = get_particular_media_transf(online_media, 'Onsite', file_path_pattern, media_dictionary)
    offline_media = get_particular_media_transf(offline_media, 'Offline', file_path_pattern, media_dictionary)
    
    media_1_df = pd.concat([sponsored_media[0], online_media[0], offline_media[0]], axis= 0)
    media_2_df = pd.concat([sponsored_media[1], online_media[1], offline_media[1]], axis= 0)
    media_3_df = pd.concat([sponsored_media[2], online_media[2], offline_media[2]], axis= 0)
    
    return (media_1_df, media_2_df, media_3_df)

class MMM_Modelling:
    
    def __init__(self, df, target_var, output_path, data_dict, media_hier, save_result = True,
                 apply_adstock = False, comment= None):
        self.df = df
        self.df_orig = df.copy()
        self.target_var = target_var
        self.data_dict = data_dict
        self.media_hier = media_hier
        self.apply_adstock = apply_adstock
        
        self.var_satur_points = {}
        self.var_thres_points = {}
        
        self.threshold_calculator = {}
        self.saturation_calculator = {}
        
        # These dictionaries would have all the details around model summary, model predictions etc.
        self.model_dump = {}
        
        if save_result:
            subdirs = [os.path.join(output_path, o) for o in os.listdir(output_path) if os.path.isdir(os.path.join(output_path,o))]
        else:
            subdirs = []
            
        todays_date = datetime.today().strftime("%Y-%m-%d")
        
        todays_folders = [folder for folder in subdirs if todays_date in folder]
        
        if len(todays_folders) == 0:
            folder_name = output_path + todays_date + "_model_outputs_v1"
        else:
            max_version = [int(folder_name.split("_")[-1].replace("v", "")) for folder_name in todays_folders]
            max_version = list(set(max_version))[-1] + 1
            folder_name = output_path + todays_date + "_model_outputs_v" + str(max_version)

        folder_name = os.path.abspath(folder_name)
        
        try:
            os.mkdir(folder_name)
        except:
            pass
        
        try:
            self.output_path = "\\\\?\\" + folder_name 
#             print(os.path.join(self.output_path, "01_modelling_details.txt"))
            self.text_file = open(os.path.join(self.output_path, "01_modelling_details.txt"), "w")
        except:
            self.output_path = folder_name 
#             print(os.path.join(self.output_path, "01_modelling_details.txt"))
            self.text_file = open(os.path.join(self.output_path, "01_modelling_details.txt"), "w")
            
        self.text_file.write("--------------------------------------------------------- \n")
        self.text_file.write("Comment: ")
        self.text_file.write(comment)
        self.text_file.write("\n")
        self.text_file.write("\n")
        
        self.text_file.write("Target Variable: %s \n" % self.target_var)
        self.text_file.write("--------------------------------------------------------- \n")
        
        
        self.model_label_mapping = {'Model Label': [],
                                    'Media Variables': [],
                                    'Model Type': []}
        
        self.model_stats_for_ranking = {'Model Label': [],
                                        'Modelling MAPE': [],
                                        'Validation MAPE': [],
                                        'Maximum ROAS': [],
                                        'Incremental Volume': [],
                                        'Model R-Square': [],
                                        'Validation R-Square': [],
                                        'Positive Media Coefficients': [],
                                        'Significant Media Variables': []}
        
        self.ROAS_label = 'Volume RoAS'
        self.ROAS_value_label = 'Value RoAS ($)'
        if 'CUSTOMER' in self.target_var:
            self.ROAS_label = 'NCoAS'
            self.ROAS_value_label = 'Value NCoAS ($)'
            
        
        self.model_log = SaveExcelTemplated(os.path.join(self.output_path, 'iteration_log.xlsx'))
        self.n_model_iteration = 0
            
        
    def set_custom_vars(self, var_list):
        self.custom_vars = var_list
      
    def get_orig_var(self, var):
        transf = {}
        pattern = re.match(r"(.*?)_[0-9.]*_[0-9.]*_[0-9+-e.]*_[0-9+-e.]*_[0-9.]", var)
        if pattern:
            transf['Original Variable'] = pattern.group(1)
            transf['Lag'] = int(float(var.split("_")[-5]))
            transf['Halflife'] = float(var.split("_")[-4])
            transf['Inflection'] = float(var.split("_")[-3])
            transf['Scale'] = float(var.split("_")[-2])
            transf['Log'] = int(float(var.split("_")[-1]))
            
            return transf
        else:
            transf['Original Variable'] = var
            transf['Lag'] = 0
            transf['Halflife'] = 0
            transf['Inflection'] = 0
            transf['Scale'] = 0
            transf['Log'] = 0
        return transf
        
        
    def create_missing_media_transformations(self, media_vars, trans_start_date= None, trans_end_date= None, reset=False):
        ''' 
        Creates the mising media transformation 
        
        Params
            media_vars : List of all media variables 
        '''
        # Creates the missing media transformations
        if reset:
            self.df=self.df_orig.copy()
        if trans_start_date is None:
            trans_start_date = self.modelling_start
            
        if trans_end_date is None:
            trans_end_date = self.modelling_end
            
        for var in media_vars:
            try:
                lag = int(float(var.split("_")[-5]))
            except:
                break
            halflife = float(var.split("_")[-4])
            sscurve_inflection = float(var.split("_")[-3])
            sscurve_scale = float(var.split("_")[-2])
            ccurve = float(var.split("_")[-1])
            
            orig_media_var = var.split("_")[:-5]
            orig_media_var = '_'.join([str(elem) for elem in orig_media_var])
            
            var_trans_obj = VariableTransformation(self.df, None, 
                                                   apply_adstock = self.apply_adstock)
    
    
            # Saving the numbers on the required period defined by trans_start_date and trans_end_date
            df_filtered = self.df[(self.df.index >= trans_start_date) & (self.df.index <= trans_end_date)].copy()
            transformed_var = df_filtered[orig_media_var]
            
            # Saving the means on the filtered dataset
            var_mean = transformed_var.mean()
            
            if self.apply_adstock:
                transformed_var = adstock_transformation(transformed_var, float(lag), float(halflife))
                
            else:
                if lag != 0: 
                    transformed_var = lag_transformation(transformed_var, int(lag))
                    var_mean = transformed_var.mean()
                if halflife != 0:
                    transformed_var = halflife_transformation(transformed_var, halflife)
                
            if (sscurve_scale != 0) and (sscurve_inflection != 0):
                transformed_var_scaled = transformed_var/var_mean
                saturation_term = sscurve_scale * (sscurve_inflection - transformed_var_scaled)
                scurve_var = 1/(1+np.exp(saturation_term))-1/(1+np.exp(sscurve_scale * sscurve_inflection))
                scurve_var_mean = scurve_var.mean()
                
            # Running actual transformations
            transformed_var = self.df[orig_media_var].copy()
            if self.apply_adstock:
                transformed_var = adstock_transformation(transformed_var, float(lag), float(halflife))
                
            else:
                if lag != 0: 
                    transformed_var = lag_transformation(transformed_var, int(lag))
                if halflife != 0:
                    transformed_var = halflife_transformation(transformed_var, halflife)

            if (sscurve_scale != 0) and (sscurve_inflection != 0):
                transformed_var_scaled = transformed_var/var_mean
                saturation_term = sscurve_scale * (sscurve_inflection - transformed_var_scaled)
                scurve_var = 1/(1+np.exp(saturation_term))-1/(1+np.exp(sscurve_scale * sscurve_inflection))
                transformed_var = scurve_var * var_mean / scurve_var_mean
            if (ccurve > 0.0):
                transformed_var = ccurve_transformation(transformed_var, ccurve)
            
            self.df[var] = transformed_var
                   
        self.df_train = self.df[(self.df.index >= self.modelling_start) & (self.df.index <= self.modelling_end)]
        self.df_test = self.df[(self.df.index >= self.validation_start) & (self.df.index <= self.validiation_end)]
        

    def create_train_test_split(self, modelling_start, modelling_end,
                                validation_start, validiation_end,
                                standardization= False,
                                normalization= False,
                                mean_division= False,
                                standardization_vars= None):
        
        self.modelling_start = modelling_start
        self.modelling_end = modelling_end
        self.validation_start = validation_start
        self.validiation_end = validiation_end
        
        ''' Function to create train and test split
        
        Params:
            modelling_start (date): Start date of modelling period
            modelling_end (date): End date of modelling period
            validation_start (date): Start date of validation period
            validiation_end (date): End date of validation period
            
            standardization (boolean): Toggle for Standardization
            normalization(boolean): Toggle for Normalization
            mean_division(boolean): Toggle for Mean Division (by 20% non-zero mean)
            
            standardization_vars(list): Variables to be standardized
        
        '''
        self.text_file.write("Modelling Period: %s to %s \n" % (modelling_start, modelling_end))
        self.text_file.write("Validation Period: %s to %s \n" % (validation_start, validiation_end))
        self.text_file.close()
        
        self.df_train = self.df[(self.df.index >= modelling_start) & (self.df.index <= modelling_end)]
        self.df_test = self.df[(self.df.index >= validation_start) & (self.df.index <= validiation_end)]
        
        if mean_division:
            for var in standardization_vars:
                non_zero_mean = 0.20 * (self.df_train[var][self.df_train[var] != 0]).mean()
                self.df_train[var] = self.df_train[var]/non_zero_mean
                self.df_test[var] = self.df_test[var]/non_zero_mean
        
        if normalization:
            scaler = MinMaxScaler()
            scaler.fit(self.df_train[standardization_vars])
            self.df_train[standardization_vars] = scaler.transform(self.df_train[standardization_vars])
            self.df_test[standardization_vars] = scaler.transform(self.df_test[standardization_vars])
            
        if standardization:
            scaler = StandardScaler()
            scaler.fit(self.df_train[standardization_vars])
            self.df_train[standardization_vars] = scaler.transform(self.df_train[standardization_vars])
            self.df_test[standardization_vars] = scaler.transform(self.df_test[standardization_vars])
     
     
    def visualize_model_custom_period(self, X_vars, start_date, end_date, intercept= True):
        '''
        Function to visualize coefficient, elasticity for a custom defined period
        X_vars: Independent variables
        start_date (Date): Start date of modelling
        end_date (Date): End date of modelling
        
        '''
            
        # Training the model on the training set to get coefficients
        model = self.fit_linear_model(dep= self.df_train[[self.target_var]], 
                                      indep= self.df_train[X_vars], intercept= intercept)
        
        # Model Summary       
        model_summary = model.summary()
        model_summary = model_summary.tables[1].as_html()
        model_summary = pd.read_html(model_summary, header= 0, index_col= 0)[0]
           
        # Defining custom period to calculate elasticity
        df_train_custom = self.df[(self.df.index >= start_date) & (self.df.index <= end_date)]    
        
        coeff_summary = self.create_coeff_table(indep= df_train_custom[X_vars], 
                                                dep= df_train_custom[[self.target_var]], 
                                                model_summary= model_summary,
                                                model= model).reset_index()
        
        coeff_summary = coeff_summary.fillna(0).replace(np.inf, 0) 
        coeff_summary['Variables'] = coeff_summary['Variables'].replace('const', 'INTERCEPT_TERM')
        
        # Incremental Impact of the Variable
        var_sum = []
        var_sum_trans = []
        for var in coeff_summary.Variables.values:
            if var.startswith('M_'):
                var_raw = self.get_orig_var(var)['Original Variable']
                var_sum.append(df_train_custom[var_raw].sum())
                var_sum_trans.append(df_train_custom[var].sum())
            else:
                var_sum.append(0)
                var_sum_trans.append(0)
        coeff_summary['Variable Raw Sum'] = var_sum
        coeff_summary['Variable Transformed Sum'] = var_sum_trans
        coeff_summary['Incremental Impact'] = coeff_summary['Variable Transformed Sum'] * coeff_summary['Coefficient']
        coeff_summary['Custom Elasticity'] = coeff_summary['Incremental Impact']/coeff_summary['Variable Raw Sum']
        coeff_summary['Custom Elasticity'] = coeff_summary['Custom Elasticity'].fillna(0)
        
        coeff_summary['Incremental Impact'] = coeff_summary['Incremental Impact'].apply(lambda x : round(x,0)).astype(int)
        coeff_summary['Variable Raw Sum'] = coeff_summary['Variable Raw Sum'].astype(int)
        
        display(coeff_summary[['Variables', 'Coefficient', 'Elasticity', 'Custom Elasticity',
                               'Incremental Impact']])
        
        coeff_summary = coeff_summary[coeff_summary.Variables.str.startswith('M_')]
        
        coeff_summary.Variables = coeff_summary.Variables.apply(self.get_var_description)
        coeff_summary = coeff_summary.sort_values(by= 'Elasticity', ascending= False).reset_index(drop= True)
        
        
        for plot_col in ['Elasticity', 'Custom Elasticity']:
            
            coeff_summary_plot = coeff_summary.copy()
            coeff_summary_plot = coeff_summary_plot.sort_values(by= plot_col, ascending= False).reset_index(drop= True)
            coeff_summary_plot = coeff_summary_plot[coeff_summary_plot[plot_col] != 0]
            plt.figure(figsize=(10,5))
            splot = sns.barplot(x= plot_col, y= "Variables", data= coeff_summary_plot, color= '#0071CE')
            
            for p in splot.patches:
                splot.annotate(format(p.get_width(), '.5f'), 
                               (p.get_width(), p.get_y() + p.get_height()/1.3), 
                               ha = 'center', va = 'center', xytext = (25, 10), textcoords = 'offset points')
                        
            plt.ylabel('')
            plt.xlabel('')
            plt.xticks([])
            plt.xticks(rotation= 90)
            
            splot.spines['right'].set_visible(False)
            splot.spines['top'].set_visible(False)
            splot.spines['left'].set_visible(False)
            
            plt.title(plot_col)
            plt.show()
        
        
    def create_model_results(self, X_vars, intercept= True, model_type= None):
        '''
        Function to create all the model results.
        This function calls all the other functions to calculate coefficients, ROAS, MAPE caluclation and
        stores the results in dictionary self.model_dump[model_type]
        
        Params:
            X_vars: Media + other independent variables
            model_type: to store the results in model_dump dictionary with the key of model_type
        '''
        
        model = self.fit_linear_model(dep= self.df_train[[self.target_var]], 
                                      indep= self.df_train[X_vars], intercept= intercept)
        
        # Trained Model
        self.model_dump[model_type] = {}
        self.model_dump[model_type]['Model'] = model
        
        model_summary = model.summary()
        model_summary = model_summary.tables[1].as_html()
        model_summary = pd.read_html(model_summary, header= 0, index_col= 0)[0]
                
        coeff_summary = self.create_coeff_table(indep= self.df_train[X_vars], 
                                                dep= self.df_train[[self.target_var]], 
                                                model_summary= model_summary,
                                                model= model).reset_index()
        
        coeff_summary = coeff_summary.fillna(0).replace(np.inf, 0) 
        coeff_summary['Variables'] = coeff_summary['Variables'].replace('const', 'INTERCEPT_TERM')
        
        # Coefficient Summary (i.e. Coefficient, VIF, Elasticity etc)
        self.model_dump[model_type]['Coefficient Summary'] = coeff_summary
        
        
        # Modelling stats (i.e. MAPE, R-Square etc)
        modelling_stats = self.overall_model_stats(model, X_vars, intercept= intercept, 
                                                   model_type= model_type).reset_index()
        
        modelling_stats = modelling_stats.rename(columns = {'index' : 'Metric'})
        
        
        # ROAS Stats (ROAS calculations)
        self.calculate_ROAS_stats(X_vars, model_type= model_type)
        
        
    def analyst_review_coef(self, df):
        
        c1 = 'background-color:#f88379'
        c2 = ''

        mask_coef = df['Coefficient'] < self.coef_threshold
        mask_rel_imp = df['Relative Importance'] < self.relative_imp_threshold
        
        mask_sig = df['Significance'] < self.significance_threshold
        mask_pval = df['p-value'] > self.p_value_threshold
        mask_elas= df['Elasticity'] < self.elasticity_threshold
        mask_vif = df['VIF'] > self.vif_threshold
        
        df_style = pd.DataFrame(c2, index= df.index, columns= df.columns)
        df_style.loc[mask_sig,'Significance'] = c1
        df_style.loc[mask_pval,'p-value'] = c1
        df_style.loc[mask_elas,'Elasticity'] = c1
        df_style.loc[mask_vif,'VIF'] = c1
        df_style.loc[mask_coef,'Coefficient'] = c1
        df_style.loc[mask_rel_imp,'Relative Importance'] = c1

        return df_style
    
    def analyst_review_model(self, df):
        
        c1 = 'background-color:#f88379'
        c2 = ''
        
        df_style =pd.DataFrame(c2, index=df.index, columns=df.columns)
        if (df.loc['MAPE', 'Model Fit'] > self.mape_threshold):
            df_style.loc['MAPE', 'Model Fit'] = c1
            
        if(df.loc['R Square', 'Model Fit'] < self.r_sq_threshold):
            df_style.loc['R Square', 'Model Fit'] = c1
            
        if(df.loc['Adjusted R Sqaure', 'Model Fit'] < self.r_sq_adj_threshold):
            df_style.loc['Adjusted R Sqaure', 'Model Fit'] = c1
        return df_style
    
        
    def overall_model_stats(self, model, X_vars, intercept= True, model_type= None):
        '''
        Function to get all the stats relevant to the overall model (i.e. MAPE, R-Square etc)
        '''
        
        if intercept: 
            X_train = sm.add_constant(self.df_train[X_vars], has_constant='add')
            X_test = sm.add_constant(self.df_test[X_vars], has_constant='add')
        else:
            X_train = self.df_train[X_vars].copy()
            X_test = self.df_test[X_vars].copy()
            
        model_act_pred = pd.DataFrame(model.predict(X_train), columns=['Predicted'])
        model_act_pred['Actuals'] = self.df_train[self.target_var]
        
        self.model_dump[model_type]['Modelling Comparison'] = model_act_pred
    
        ####### MAPE Calculation (Modelling) #######
        perc_error = abs((model_act_pred.Predicted/model_act_pred.Actuals)-1)
        mape = perc_error.mean() * 100
    
        ###### Model fit Calculation (Modelling) ########
        model_stats =  [mape,model.rsquared * 100, model.rsquared_adj * 100,
                        model.aic, model.bic, model.llf]
        model_stats = pd.DataFrame(model_stats,
                                     index=['MAPE','R Square','Adjusted R Sqaure','AIC','BIC', 'Log Likelihood'], 
                                     columns=['Model Fit'])
        
        self.model_dump[model_type]['Modelling Metrics'] = model_stats
        
        model_act_pred = pd.DataFrame(model.predict(X_test), columns=['Predicted'])
        model_act_pred['Actuals'] = self.df_test[self.target_var]
        
        self.model_dump[model_type]['Validation Comparison'] = model_act_pred
        
        perc_error = abs((model_act_pred.Predicted/model_act_pred.Actuals)-1)
        mape = perc_error.mean() * 100
        r_sq = r2_score(model_act_pred.Actuals, model_act_pred.Predicted) * 100
        
        model_stats['Validation Metrics'] = [mape, r_sq, '', '', '', ''] 
        
        self.model_dump[model_type]['Modelling Stats'] = model_stats
        
        return model_stats


    def fit_linear_model(self, dep, indep, intercept= True):   
        if intercept:
            x = sm.add_constant(indep, has_constant='add').copy()
            model = sm.OLS(dep,x)
            model = model.fit()
            return model
        else:
            model = sm.OLS(dep,indep)
            model = model.fit()
            return model
        
    def calculate_price_average(self, df):
        # Overall models #0222_2020 YW changed for new NC value data
        if 'ONLINE' not in self.target_var:
            if 'CUSTOMER' in self.target_var:
                #total_num = df['O_SALE_NEW_CUSTOMER'].sum() 
                average_price=df['PRICE_NEW_CUSTOMER_OMNI'].mean()
            else:
                total_num = df['O_SALE'].sum() 
                total_den = df[self.target_var].sum()
                average_price = total_num/total_den
            
        # Online models
        if 'ONLINE' in self.target_var:
            if 'CUSTOMER' in self.target_var:
                #total_num = (df['O_SALE_NEW_CUSTOMER_EMAIL'] + df['O_SALE_NEW_CUSTOMER_OMNI_EMAIL']).sum()
                average_price=df['PRICE_NEW_CUSTOMER_DOTCOM']
            else:
                total_num = df['O_SALE_ONLINE'].sum() 
                total_den = df[self.target_var].sum()
                average_price = total_num/total_den
        
        return average_price
        
    def get_spend_vars(self, media_vars):
        
        media_spend_mapping = {}
        spend_vars = []
        orig_vars =[]
        orig_trans_mapping={}
        for col in media_vars:
            orig_var = self.get_orig_var(col)['Original Variable']
            spend_var = orig_var.replace('VIEW_IMP', 'SPEND')
            spend_var = spend_var.replace('CLK', 'SPEND')
            spend_var = spend_var.replace('IMP', 'SPEND')
            spend_vars.append(spend_var)
            media_spend_mapping[spend_var] = col
            
            orig_vars.append(orig_var)
            orig_trans_mapping[orig_var]=col
            
        return media_spend_mapping, spend_vars,orig_vars,orig_trans_mapping
            
    
    def calculate_ROAS_stats(self, X_vars, model_type= None):
        ''' Function to calculate ROAS Stats of a model '''
            
        media_vars = [col for col in X_vars if col.startswith('M_')]
        media_spend_mapping, spend_vars, orig_vars,orig_trans_mapping = self.get_spend_vars(media_vars= media_vars)
        
        average_price = self.calculate_price_average(self.df)
        
        # ROAS Stats to be displayed for entire period. Henceforth, used df instead of df_train
        df_vol_cont = pd.DataFrame()
        for col in media_vars:
            coef_table = self.model_dump[model_type]['Coefficient Summary']
            df_vol_cont[col] = self.df[col] * coef_table[coef_table.Variables == col]['Coefficient'].values[0]
        
        self.model_dump[model_type]['Volume Contribution'] = df_vol_cont
        
        # ROAS Stats to be displayed for all the variables
        df_vol_cont_all = pd.DataFrame()
        for col in X_vars:
            coef_table = self.model_dump[model_type]['Coefficient Summary']
            df_vol_cont_all[col] = self.df[col] * coef_table[coef_table.Variables == col]['Coefficient'].values[0]
            
        df_vol_cont_all[self.target_var] = self.df[self.target_var].values
        
        self.model_dump[model_type]['Volume Contribution All'] = df_vol_cont_all
        
        volume_cont_with_orig = pd.merge(self.df[X_vars], df_vol_cont, how='left', left_index=True, right_index=True)
        
        volume_cont_with_orig = pd.merge(self.df[[self.target_var]], volume_cont_with_orig, 
                                         how='left', left_index=True, right_index=True)
        
        self.model_dump[model_type]['Volume Contribution Original'] = volume_cont_with_orig
        
        df_spends = self.df[spend_vars]
        
        self.model_dump[model_type]['Spends'] = df_spends
                
        # Preparation of ROAS table
        df_ROAS_final = df_vol_cont.transpose()
        df_ROAS_final['Total Contribution'] = df_ROAS_final.sum(axis=1)
        
        # Yearly calculations
        df_ROAS_final_yearly = df_vol_cont.copy()
        df_ROAS_final_yearly['Year'] = df_ROAS_final_yearly.index.year
        df_ROAS_final_yearly = df_ROAS_final_yearly.melt(id_vars= ['Year'],
                                                       value_vars= [col for col in df_ROAS_final_yearly.columns if col != 'Year'])
        df_ROAS_final_yearly = df_ROAS_final_yearly.groupby(['Year', 'variable']).sum().reset_index()
        
        df_spends_yearly = df_spends.copy()
        df_spends_yearly['Year'] = df_spends_yearly.index.year
        df_spends_yearly = df_spends_yearly.melt(id_vars= ['Year'],
                                                 value_vars= [col for col in df_spends_yearly.columns if col != 'Year'])
        df_spends_yearly = df_spends_yearly.groupby(['Year', 'variable']).sum().reset_index()
        df_spends_yearly['variable'] = df_spends_yearly.variable.map(media_spend_mapping)
        
        df_ROAS_final_yearly.columns = ['Year', 'Variable', 'Contribution']
        df_spends_yearly.columns = ['Year', 'Variable', 'Spend ($)']
                
        df_yearly_final = df_ROAS_final_yearly.merge(df_spends_yearly)
        
        self.model_dump[model_type]['ROAS Yearly'] = df_yearly_final
        
    
        df_ROAS_final = df_ROAS_final[['Total Contribution']]
    
        spends_df = pd.DataFrame(df_spends.transpose().sum(axis=1),columns=['Total Spend ($)'])
        spends_df['Variables'] = spends_df.index.map(media_spend_mapping)
        spends_df.index = spends_df['Variables']
        spends_df = spends_df.drop(['Variables'],axis=1)
    
        
        df_ROAS_final = pd.merge(spends_df, df_ROAS_final,how='left', left_index= True, right_index= True)
        
        df_ROAS_final[self.ROAS_label] = 100 * df_ROAS_final['Total Contribution']/df_ROAS_final['Total Spend ($)']
        df_ROAS_final[self.ROAS_value_label] = average_price * df_ROAS_final[self.ROAS_label]
        df_ROAS_final = df_ROAS_final.sort_values([self.ROAS_label], ascending = (False)).reset_index()
        
        self.model_dump[model_type]['ROAS'] = df_ROAS_final
        return df_ROAS_final
        
        
    def prepare_ranking_df(self, X_vars, intercept= True):
        '''
        Function to prepare the ranking dataframe i.e. derive model metrics to be used for ranking
        Params:
            X_vars: List of all the independent variables (media + other variables)
        '''
        
        model = self.fit_linear_model(dep= self.df_train[[self.target_var]], 
                                      indep= self.df_train[X_vars], intercept= intercept)
        
        media_vars = [var for var in X_vars if var.startswith('M_')]
        
        # Number of positive media coefficients
        positive_media_coeff = (model.params[media_vars] > 0).sum()
        sig_media_vars = (model.pvalues[media_vars] < 0.30).sum()
                
        
        if intercept: 
            X_train = sm.add_constant(self.df_train[X_vars], has_constant='add').copy()
            X_test = sm.add_constant(self.df_test[X_vars], has_constant='add').copy()
            
        else:
            X_train = self.df_train[X_vars].copy()
            X_test = self.df_test[X_vars].copy()
            
        # Mape calculation
        perc_error = abs((model.predict(X_train)/self.df_train[self.target_var])-1)
        modelling_mape = perc_error.mean() * 100
        
        perc_error = abs((model.predict(X_test)/self.df_test[self.target_var])-1)
        validation_mape = perc_error.mean() * 100
        
        modelling_r_sq = model.rsquared * 100
        validation_r_sq = r2_score(self.df_test[self.target_var], model.predict(X_test)) * 100
        
        
        # ROAS Calculation
        media_spend_mapping, spend_vars, orig_vars, orig_trans_mapping = self.get_spend_vars(media_vars= media_vars)
        
        df_vol_cont = pd.DataFrame()
        for col in media_vars:
            df_vol_cont[col] = self.df_train[col] * model.params[col] 
            
        
        
        df_vol_cont = df_vol_cont.transpose()
        df_vol_cont['Total Contribution'] = df_vol_cont.sum(axis=1)
    
        df_vol_cont = df_vol_cont[['Total Contribution']]
        
        df_spends = self.df_train[spend_vars]
        spend_df = pd.DataFrame(df_spends.transpose().sum(axis= 1), columns= ['Total Spend ($)'])
        spend_df['Variables'] = spend_df.index.map(media_spend_mapping)
        spend_df.index = spend_df['Variables']
        spend_df = spend_df.drop(['Variables'],axis=1)
        

        df_ROAS = pd.merge(spend_df, df_vol_cont, how='left', left_index= True, right_index= True)
        df_ROAS[self.ROAS_label] = 100 * df_ROAS['Total Contribution']/df_ROAS['Total Spend ($)']
        
        max_ROAS = df_ROAS[self.ROAS_label].max()
        incremental_vol = 100 * df_ROAS['Total Contribution'].sum() / self.df_train[self.target_var].sum()

        self.model_stats_for_ranking['Modelling MAPE'].append(modelling_mape)
        self.model_stats_for_ranking['Validation MAPE'].append(validation_mape)
        self.model_stats_for_ranking['Maximum ROAS'].append(max_ROAS)
        self.model_stats_for_ranking['Incremental Volume'].append(incremental_vol)
        self.model_stats_for_ranking['Model R-Square'].append(modelling_r_sq)
        self.model_stats_for_ranking['Validation R-Square'].append(validation_r_sq)
        self.model_stats_for_ranking['Positive Media Coefficients'].append(positive_media_coeff)
        self.model_stats_for_ranking['Significant Media Variables'].append(sig_media_vars)

        
    def create_coeff_table(self, dep, indep, model_summary, model):
        
        m_sumry = model_summary
        
        #Calculation of Elasticity
        s1 = pd.DataFrame(indep.sum(),columns=['x_sum'])
        s1['Variables'] = s1.index
        beta = pd.DataFrame(m_sumry['coef'])
        beta['Variables'] = beta.index
        
        s=pd.merge(s1,beta,on = ['Variables'],how='left')
        s['y_sum'] = dep.sum()[0]
        
        s['Elasticity'] = (s.coef*s.x_sum)/s.y_sum
        
        #Calculation of Coefficient and Signficance 
        m = m_sumry
        m = m.iloc[:,[0,3]]
        m1 = pd.DataFrame(m,columns=['coef','P>|t|']).rename(columns={'P>|t|':'p-value'})
        m1['Significance'] = m1['p-value'].apply(lambda x: (1-x)*100)
        m1['Variables'] = m1.index
        
        m2 = pd.merge(m1,s,on='Variables',how='left')
        m2 = m2.drop(['x_sum','y_sum','coef_y'],axis=1)
        m2 = m2.rename(columns={'coef_x' : 'Coefficient' })
        
        
        for coef, variable in zip(model.params, model.params.index):
            m2.loc[m2.Variables == variable, 'Coefficient'] = coef
        
        #Calculation of Stand Co-efficients and Rel Importance
        z_ip = pd.DataFrame(zscore(indep),columns=indep.columns).fillna(0)
        z_dp = pd.DataFrame(zscore(dep)).fillna(0)
    
        std_coeff_df = self.fit_linear_model(z_dp,z_ip,"Yes").summary()
        std_coeff_df_html = std_coeff_df.tables[1].as_html()
        std_coeff = pd.read_html(std_coeff_df_html,header=0,index_col=0)[0]
        std_coeff = std_coeff.rename(columns={'coef': 'Standardized Coefficient'})
        std_coeff = std_coeff[["Standardized Coefficient"]]
        std_coeff["Variables"] = std_coeff.index
        std_coeff['Standardized Coefficient'] = np.where(std_coeff['Variables']=='const', 0,
                                                         std_coeff['Standardized Coefficient'])
        std_coeff['Sqr_Std_coeff'] = std_coeff['Standardized Coefficient']**2
        std_coeff['Relative Importance'] = std_coeff['Sqr_Std_coeff']/std_coeff['Sqr_Std_coeff'].sum()
        
        m2 = pd.merge(m2,std_coeff,on='Variables',how='left')
        
        #Calculation of VIF
        if (m2.shape[0]!=indep.shape[1]):
            xip = sm.add_constant(indep)
            vif = pd.DataFrame([variance_inflation_factor(xip.values, i) for i in range(xip.shape[1])],index = xip.columns,columns=["VIF"])
            vif["Variables"]=vif.index
        else:
            vif = pd.DataFrame([variance_inflation_factor(indep.values, i) for i in range(indep.shape[1])],index = indep.columns,columns=["VIF"])
            vif["Variables"]=vif.index
        
        #Getting the final Co-efficient table
        Coeff_table_final = pd.merge(m2,vif,on='Variables',how='left')
        Coeff_table_final.index = Coeff_table_final['Variables']
        
        Coeff_table_final['VIF'] = np.where(Coeff_table_final['Variables']=='const', 0, Coeff_table_final['VIF'])
        
        Coeff_table_final=Coeff_table_final.drop(['Variables','Sqr_Std_coeff'],axis=1)
    
        return(Coeff_table_final)
        
    def bidirectional_selection(self, X_vars, significance_out= 95, significance_in = 95):
        
        process_dict = {'Variable': [],
                        'P-Value': [],
                        'Step': []}
        
        initial_features = X_vars.copy()
        price_var = [var for var in initial_features if 'PRICE' in var][0]
        
        best_features = []
        p_value_limit_in = (100.00 - significance_in)/100.00
        p_value_limit_out = (100.00 - significance_out)/100.00
        
        while len(initial_features) > 0:
            
            remaining_features = list(set(initial_features)-set(best_features))
            new_pval = pd.Series(index=remaining_features)
            for new_column in remaining_features:
                model = sm.OLS(self.df_train[self.target_var], sm.add_constant(self.df_train[best_features+[new_column]])).fit()
                new_pval[new_column] = model.pvalues[new_column]
            min_p_value = new_pval.min()
            if min_p_value < p_value_limit_in:
                best_features.append(new_pval.idxmin())
                
                process_dict['Variable'].append(new_pval.idxmin())
                process_dict['P-Value'].append(min_p_value)
                process_dict['Step'].append('Variable Added')
                
                while(len(best_features)>0):
                    best_features_with_constant = sm.add_constant(self.df_train[best_features])
                    p_values = sm.OLS(self.df_train[self.target_var], best_features_with_constant).fit().pvalues[1:]
                    max_p_value = p_values.max()
                    if(max_p_value >= p_value_limit_out):
                        excluded_feature = p_values.idxmax()
                        best_features.remove(excluded_feature)
                        
                        process_dict['Variable'].append(excluded_feature)
                        process_dict['P-Value'].append(max_p_value)
                        process_dict['Step'].append('Variable Excluded')
                        
                    else:
                        break 
            else:
                break
            
   
        if price_var not in best_features:
            best_features = best_features + [price_var]
            
        self.best_features_bidirectional = best_features
        
    
    def forward_selection(self, X_vars, significance_in= 95):
        
        process_dict = {'Variable': [],
                        'P-Value': [],
                        'Step': []}
        
        initial_features = X_vars.copy()
        price_var = [var for var in initial_features if 'PRICE' in var][0]
        best_features = []
        
        p_value_limit = (100.00 - significance_in)/100.00
        while len(initial_features) > 0:
            
            remaining_features = list(set(initial_features)-set(best_features))
            new_pval = pd.Series(index= remaining_features)
            
            for new_column in remaining_features:
                model = sm.OLS(self.df_train[self.target_var], 
                               sm.add_constant(self.df_train[best_features + [new_column]])).fit()
                new_pval[new_column] = model.pvalues[new_column]
            min_p_value = new_pval.min()
            if(min_p_value < p_value_limit):
                best_features.append(new_pval.idxmin())
                process_dict['Variable'].append(new_pval.idxmin())
                process_dict['P-Value'].append(min_p_value)
                process_dict['Step'].append('Variable added with minimum P-Value')
            else:
                process_dict['Variable'].append('')
                process_dict['P-Value'].append('')
                process_dict['Step'].append('All remaining variables rejected')
                break
        if price_var not in best_features:
            best_features = best_features + [price_var]
            
        self.best_features_forward = best_features

        
    
    def backward_elimination(self, X_vars, significance_out= 95):
        
        process_dict = {'Variable': [],
                        'P-Value': [],
                        'Step': []}
        
        features = X_vars.copy()
        price_var = [var for var in features if 'PRICE' in var][0]
        
        p_value_limit = (100.00 - significance_out)/100.00
        while len(features) > 0:
            
            features_with_constant = sm.add_constant(self.df_train[features])
            p_values = sm.OLS(self.df_train[self.target_var], features_with_constant).fit().pvalues[1:]
            max_p_value = p_values.max()
            if(max_p_value >= p_value_limit):
                excluded_feature = p_values.idxmax()
                features.remove(excluded_feature)
                process_dict['Variable'].append(excluded_feature)
                process_dict['P-Value'].append(max_p_value)
                process_dict['Step'].append('Variable excluded with maximum P-Value')
            else:
                process_dict['Variable'].append('')
                process_dict['P-Value'].append('')
                process_dict['Step'].append('All other variables selected')
                break 
                
        if price_var not in features:
            features = features + [price_var]
            
        self.best_features_backward = features
       
        
    def stepwise_variable_selection(self, X_vars, significance_in= 95, significance_out= 95):
        '''
        Selection of dummy variables by applying forward, backward and bi-directional selection.
        Params:
            X_vars (list): List of independent variables (excluding media variables)
            signficance_in: Significance level for forward selection
            significance_out: Siginificance level for backward elimination
            
        Class parameters best_features_backward, best_features_forward would have the required values of selection
        
        '''
        self.forward_selection(X_vars, significance_in= significance_in)
        self.backward_elimination(X_vars, significance_out= significance_out)
        self.bidirectional_selection(X_vars, significance_in= significance_in, 
                                     significance_out= significance_out)
        
    
        
        
    def run_linear_regression(self, media_variables, 
                              custom_vars= False,
                              forward_sel_vars= True, backward_sel_vars= True, 
                              bidirectional_sel_vars= False, intercept= True):
        ''' Function to run linear model for given media variables
        Other variables can be selected by stepwise regression or can be customized
        Only either of stepwise or custom model can be run 
        
        Params:
            media_variables (list): Media variables to be used as independent variables
            custom_vars (boolean): If set to true, then model would run on the basis of custom variables
                                    Remember to run function self.set_custom_vars before turing this toggle on
            forward_sel_vars, backward_sel_vars, bidirectional_sel_vars: toggle for selection variables
            intercept: if intercept terms is to be used in the model
        '''
        
        # Preparation of modelling stats dictionary. This dictionary would be used to rank the various model outputs
        
        if custom_vars:
            self.prepare_ranking_df(X_vars= media_variables + self.custom_vars, 
                                     intercept= intercept)
            
            model_label = 1 + len(self.model_label_mapping['Model Label'])
            self.model_label_mapping['Model Label'].append(model_label)
            self.model_label_mapping['Media Variables'].append(media_variables)
            self.model_label_mapping['Model Type'].append('Custom')
            self.model_stats_for_ranking['Model Label'].append(model_label)
            return 
        
        if forward_sel_vars: 
            
            self.prepare_ranking_df(X_vars= media_variables + self.best_features_forward, 
                                     intercept= intercept)
            
            model_label = 1 + len(self.model_label_mapping['Model Label'])
            self.model_label_mapping['Model Label'].append(model_label)
            self.model_label_mapping['Media Variables'].append(media_variables)
            self.model_label_mapping['Model Type'].append('Forward')
            self.model_stats_for_ranking['Model Label'].append(model_label)
        
        if backward_sel_vars: 
            self.prepare_ranking_df(X_vars= media_variables + self.best_features_backward, 
                                     intercept= intercept)
            
            model_label = 1 + len(self.model_label_mapping['Model Label'])
            self.model_label_mapping['Model Label'].append(model_label)
            self.model_label_mapping['Media Variables'].append(media_variables)
            self.model_label_mapping['Model Type'].append('Backward')
            self.model_stats_for_ranking['Model Label'].append(model_label)
            
        
        if bidirectional_sel_vars: 
            self.prepare_ranking_df(X_vars= media_variables + self.best_features_bidirectional, 
                                     intercept= intercept)
            
            model_label = 1 + len(self.model_label_mapping['Model Label'])
            self.model_label_mapping['Model Label'].append(model_label)
            self.model_label_mapping['Media Variables'].append(media_variables)
            self.model_label_mapping['Model Type'].append('Bidirectional')
            self.model_stats_for_ranking['Model Label'].append(model_label)
                
        
    
    def rank_models(self, mape= False, r_sq= True, max_ROAS_limit= 1000, max_vol_inc_limit= 0.9):
        
        ranking_df = pd.DataFrame(self.model_stats_for_ranking).copy()
        
        ranking_df = ranking_df[ranking_df['Maximum ROAS'] <= max_ROAS_limit].reset_index(drop= True)
        ranking_df = ranking_df[ranking_df['Incremental Volume'] <= max_vol_inc_limit].reset_index(drop= True)
        ranking_df = ranking_df[ranking_df['Positive Media Coefficients'] == ranking_df['Positive Media Coefficients'].max()]
        ranking_df = ranking_df[ranking_df['Significant Media Variables'] == ranking_df['Significant Media Variables'].max()]
        
        
        all_ranking_cols = []
        for col in ranking_df.columns:
            
            if ((mape) & (col in ['Modelling MAPE', 'Validation MAPE'])):
                ranking_df['Rank : ' + col] = ranking_df[col].rank(ascending= True, method= 'dense')
                all_ranking_cols.append('Rank : ' + col)
            elif ((r_sq) & (col in ['Model R-Square', 'Validation R-Square', 'Positive Media Coefficients'])):
                ranking_df['Rank : ' + col] = ranking_df[col].rank(ascending= False, method= 'dense')
                all_ranking_cols.append('Rank : ' + col)
            else:
                continue
        
        ranking_df['Ranks Sum'] = ranking_df[all_ranking_cols].sum(axis= 1)
        ranking_df['Final Rank'] = ranking_df['Ranks Sum'].rank(ascending= True, method= 'dense')
        
        ranking_df = ranking_df.sort_values(by= 'Final Rank').reset_index(drop= True)
        
        ranking_df_1 = ranking_df[ranking_df['Final Rank'] == 1].head(1)
        ranking_df_2 = ranking_df[ranking_df['Final Rank'] == 2].head(1)
        ranking_df_3 = ranking_df[ranking_df['Final Rank'] == 3].head(1)
        ranking_df = pd.concat([ranking_df_1, ranking_df_2, ranking_df_3], axis= 0)
        
        excel_obj = SaveExcelTemplated(os.path.join(self.output_path, "ranking_stepwise_regression.xlsx"))
        
        excel_obj.add_worksheet(ranking_df, 'Rankings', 
                                decimal_5_col_names = ['Modelling MAPE', 'Validation MAPE', 'Maximum ROAS', 
                                                       'Incremental Volume', 'Model R-Square', 
                                                       'Validation R-Square'])
        
        model_details_all = pd.DataFrame(self.model_label_mapping).copy()
        for model_label in ranking_df['Model Label'].values:  
            model_details = model_details_all[model_details_all['Model Label'] == model_label]
            
            
            model_type = model_details['Model Type'].values[0]
            if model_type == 'Forward':
                X_vars = model_details['Media Variables'].values[0] + self.best_features_forward
            if model_type == 'Bidirectional':
                X_vars = model_details['Media Variables'].values[0] + self.best_features_bidirectional
            if model_type == 'Backward':
                X_vars = model_details['Media Variables'].values[0] + self.best_features_backward
            if model_type == 'Custom':
                X_vars = model_details['Media Variables'].values[0] + self.custom_vars
            
            self.create_model_results(X_vars= X_vars, model_type= model_label)
            
            coefficient_summary = self.model_dump[model_label]['Coefficient Summary']
            ROAS_summary = self.model_dump[model_label]['ROAS']
            modelling_summary = self.model_dump[model_label]['Modelling Stats']
            
            excel_obj.add_worksheet(coefficient_summary, 'Coefficient Model - ' + str(model_label),
                                    decimal_5_col_names= coefficient_summary.columns)
            excel_obj.add_worksheet(ROAS_summary, 'ROAS Model - ' + str(model_label),
                                    decimal_5_col_names= ROAS_summary.columns)
            excel_obj.add_worksheet(modelling_summary.reset_index(), 'Overall Model - ' + str(model_label),
                                    decimal_5_col_names= modelling_summary.columns)
        
        excel_obj.save_worksheet()
            
        self.best_model_labels = list(ranking_df['Model Label'].values)
        
        return ranking_df
    
    def set_df_input(self, df_input):
        self.df_input = df_input
    
    def visualize_due_calculations(self, model_type, start_period_1, end_period_1, 
                                   start_period_2, end_period_2, combine_holidays =False,
                                   combine_days_events_mod= False, 
                                   combine_all_dummy_variables= False, 
                                   combine_seasonaity_terms= False, combine_non_media_drivers = False,
                                   media_level= None, save_path= None):
        

        ###############################
        
        #Calculations for period 1
        volume_contribution = self.model_dump[model_type]['Volume Contribution All'].copy()
                        
        period1 = volume_contribution.copy()
        period1 = period1.drop(columns= self.target_var)
        period1['Date'] = period1.index
        period1['Date'] = pd.to_datetime(period1['Date'])
    
        period1.sort_index(inplace=True, ascending=True)
        period1 = period1.loc[start_period_1:end_period_1]
        period1.drop('Date',inplace=True,axis=1)
        period1 = period1.transpose()
        
        period1['Variable'] = period1.index
        
        #To get the Spend Var 
        period1['Variable1'] = period1['Variable'].apply(lambda x: x.rsplit('_',6)[0]) + '_SPEND'
        
        
        period1_df_input = self.df_input[((self.df_input['index'] <= end_period_1) & (self.df_input['index'] >= start_period_1))]
        period1['Spend Period 1'] = period1.Variable1.map(period1_df_input.sum()).fillna(0)
        
        period1['Variable'] = period1['Variable'].apply(self.get_var_description, 
               args= (media_level, combine_holidays, combine_days_events_mod, 
                      combine_all_dummy_variables, combine_seasonaity_terms,combine_non_media_drivers))
        
        
        period1 = period1.groupby('Variable').sum()
        period1['Contribution Period 1'] = period1.sum(axis=1)
        period1['Contribution Period 1'] = period1['Contribution Period 1']-period1['Spend Period 1']
        period1 = period1.filter(['Contribution Period 1','Spend Period 1'],axis=1)
        
        dp_period1 = pd.DataFrame(self.df[[self.target_var]]).copy()
        dp_period1['Date'] = dp_period1.index
        dp_period1=dp_period1.loc[start_period_1:end_period_1]
        dp_period1.drop('Date',inplace=True,axis=1)
        
        #Calculations for Period2
        ####Select only incremental variables if needed ###
        period2 = volume_contribution.copy()
        period2 = period2.drop(columns= self.target_var)
    
        period2['Date'] = period2.index
        period2['Date'] = pd.to_datetime(period2['Date'])
    
        period2.sort_index(inplace= True, ascending= True)
        period2 = period2.loc[start_period_2:end_period_2]
        period2.drop('Date', inplace=True, axis=1)
        period2 = period2.transpose()
        
        period2['Variable'] = period2.index
        #To get the Spend Var 
        period2['Variable1'] = period2['Variable'].apply(lambda x: x.rsplit('_',6)[0]) + '_SPEND'
        
        
        period2_df_input = self.df_input[((self.df_input['index'] <= end_period_2) & (self.df_input['index'] >= start_period_2))]
        period2['Spend Period 2'] = period2.Variable1.map(period2_df_input.sum()).fillna(0)
        display()
        period2['Variable'] = period2['Variable'].apply(self.get_var_description, 
               args= (media_level, combine_holidays, combine_days_events_mod, 
                      combine_all_dummy_variables, combine_seasonaity_terms,combine_non_media_drivers))
        period2 = period2.groupby('Variable').sum()
        period2['Contribution Period 2'] = period2.sum(axis=1)
        period2['Contribution Period 2'] = period2['Contribution Period 2']-period2['Spend Period 2']
        period2 = period2.filter(['Contribution Period 2','Spend Period 2'],axis=1)
        
     
        dp_period2 = pd.DataFrame(self.df[[self.target_var]]).copy()
        dp_period2['Date'] = dp_period2.index
        dp_period2 = dp_period2.loc[start_period_2:end_period_2]
        dp_period2.drop('Date',inplace=True,axis=1)
        
        #Due-To Calculations  
        due_to = pd.concat([period1, period2],axis=1)
        due_to['Due To']= due_to['Contribution Period 2'] - due_to['Contribution Period 1']
        due_to['Due To (%)'] = (due_to['Due To']/dp_period1.iloc[:,0].sum())*100
        
        
        outcome = pd.DataFrame({'Contribution Period 1': [dp_period1.iloc[:,0].sum()], 
                               'Contribution Period 2': [dp_period2.iloc[:,0].sum()], 
                                'Due To':[dp_period2.iloc[:,0].sum()-dp_period1.iloc[:,0].sum()],
                                   'Due To (%)':[((dp_period2.iloc[:,0].sum()-dp_period1.iloc[:,0].sum())/dp_period1.iloc[:,0].sum())*100]})
        due_to_outcome = outcome.append(due_to)
        due_to_outcome = due_to_outcome.rename(index={0:'Outcome Variable'})
        
        due_to['Variables'] = due_to.index
        
        volume_dueto=dp_period2.iloc[:,0].sum()-dp_period1.iloc[:,0].sum()
        Unexplained=pd.Series(volume_dueto-due_to['Due To'].sum())
    
        waterfall_dueto=due_to[['Variables','Due To']]
        
        waterfall_dueto = pd.DataFrame(data=waterfall_dueto)
        
        df5=pd.DataFrame([['Unexplained',int(Unexplained)]],columns=['Variables','Due To'])
        
        
        
        
        if(combine_non_media_drivers == True):
            new_non_media_dueto = (waterfall_dueto[waterfall_dueto['Variables']=='Non Media Drivers']['Due To'].tolist())[0] + (df5['Due To'].tolist())[0]
            due_to_outcome.loc['Non Media Drivers', 'Due To'] = new_non_media_dueto
            due_to_outcome.loc['Non Media Drivers', 'Due To (%)'] = (due_to_outcome.loc['Non Media Drivers', 'Due To']/due_to_outcome.loc['Outcome Variable', 'Contribution Period 1']) * 100
            
            #up_dueto = due_to_outcome.get_value(1, 2, takeable = True) 
            #up_dueto = new_non_media_dueto
            #due_to_outcome.get_value(2, 0, takeable = True) == 'Non Media Drivers', ['Due To'] = new_non_media_dueto
            waterfall_dueto.loc[waterfall_dueto['Variables'] == 'Non Media Drivers', ['Due To']] = new_non_media_dueto
            #print(type(waterfall_dueto))
            data = pd.DataFrame(data=waterfall_dueto)
            trans = pd.DataFrame(data=data)
            trans=trans.sort_values(['Due To'])
    
            df2=pd.DataFrame([['Outcome Period 1',int(dp_period1.iloc[:,0].sum())]],columns=['Variables','Due To'])
    
            trans = pd.concat([df2, trans])
    
#        trans['Variables'] = 
            trans.index = trans['Variables']
            trans = trans.drop(['Variables'],axis=1)
            due_to = due_to.drop(['Variables'],axis=1)
        #print(trans)
                                 
            title = "Waterfall Analysis: " + str(start_period_1) + "-" + str(end_period_1) + \
         " : " + str(start_period_2) + "-" + str(end_period_2)
         
            matplotlib.rcParams.update({'font.size': 15})
            plot_waterfall(trans.index.tolist(), trans['Due To'].tolist(), 
                       rotation_value= 90, net_label= "Outcome Period 2",
                       Title= title, blue_color = "#FFC220",
                       green_color = "#FFC220", red_color = '#0071CE', figsize = (15,10),
                       save_path= save_path)
         
            matplotlib.rcParams.update({'font.size': 13})
            
            
            
            # Formatting the each of the columns
            format_mapping_dto={'Contribution Period 1': '{:,.2f}', 'Contribution Period 2': '{:,.2f}', 'Due To': '{:,.2f}' , 'Due To (%)' : '{:.1f}',
                                'Spend Period 1': '{:,.0f}', 'Spend Period 2': '{:,.0f}' }
            for key, value in format_mapping_dto.items():
                due_to_outcome[key] = due_to_outcome[key].apply(value.format)
                
            #pd.options.display.float_format = '{:20,.2f}'.format      
            display(due_to_outcome)
            
            
            #display(waterfall_dueto)
        else:
            data=pd.concat([df5,waterfall_dueto])
            trans = pd.DataFrame(data=data)
            trans=trans.sort_values(['Due To'])
    
            df2=pd.DataFrame([['Outcome Period 1',int(dp_period1.iloc[:,0].sum())]],columns=['Variables','Due To'])
    
            trans = pd.concat([df2, trans])
    
#        trans['Variables'] = 
            trans.index = trans['Variables']
            trans = trans.drop(['Variables'],axis=1)
            due_to = due_to.drop(['Variables'],axis=1)
        #print(trans)
                                 
            title = "Waterfall Analysis: " + str(start_period_1) + "-" + str(end_period_1) + \
         " : " + str(start_period_2) + "-" + str(end_period_2)
         
            matplotlib.rcParams.update({'font.size': 15})
            plot_waterfall(trans.index.tolist(), trans['Due To'].tolist(), 
                       rotation_value= 90, net_label= "Outcome Period 2",
                       Title= title, blue_color = "#FFC220",
                       green_color = "#FFC220", red_color = '#0071CE', figsize = (15,10),
                       save_path= save_path)
         
            matplotlib.rcParams.update({'font.size': 13})
            
            # Formatting the each of the columns
            format_mapping_dto={'Contribution Period 1': '{:,.2f}', 'Contribution Period 2': '{:,.2f}', 'Due To': '{:,.2f}' , 'Due To (%)' : '{:.1f}',
                                'Spend Period 1': '{:,.0f}', 'Spend Period 2': '{:,.0f}' }
            for key, value in format_mapping_dto.items():
                due_to_outcome[key] = due_to_outcome[key].apply(value.format)
            
            #pd.options.display.float_format = '{:20,.2f}'.format           
            display(due_to_outcome)
            #waterfall_dueto[['Variables']=='Non Media Drivers']['Due To'] = new_non_media_dueto
            #display(waterfall_dueto)
        
        #data=pd.concat([df5,waterfall_dueto])
        
        '''
        trans = pd.DataFrame(data=data)
        trans=trans.sort_values(['Due To'])
    
        df2=pd.DataFrame([['Outcome Period 1',int(dp_period1.iloc[:,0].sum())]],columns=['Variables','Due To'])
    
        trans = pd.concat([df2, trans])
    
#        trans['Variables'] = 
        trans.index = trans['Variables']
        trans = trans.drop(['Variables'],axis=1)
        due_to = due_to.drop(['Variables'],axis=1)
        #print(trans)
                                 
        title = "Waterfall Analysis: " + str(start_period_1) + "-" + str(end_period_1) + \
         " : " + str(start_period_2) + "-" + str(end_period_2)
         
        matplotlib.rcParams.update({'font.size': 15})
        plot_waterfall(trans.index.tolist(), trans['Due To'].tolist(), 
                       rotation_value= 90, net_label= "Outcome Period 2",
                       Title= title, blue_color = "#FFC220",
                       green_color = "#FFC220", red_color = '#0071CE', figsize = (15,10),
                       save_path= save_path)
         
        matplotlib.rcParams.update({'font.size': 13})
                      
                       
        display(due_to_outcome)
        '''
        
        path = self.output_path
        if not os.path.isdir(path):
            os.mkdir(path)
        file_path = os.path.join(path, "WMC_Due_to_{start_period_1}_{end_period_1}_{start_period_2}_{end_period_2}.csv".format(
            start_period_1 = start_period_1, 
            end_period_1 = end_period_1,
            start_period_2 = start_period_2,
            end_period_2 = end_period_2
        ))
        due_to_outcome.to_csv(file_path)
    

    def modify_ROAS_table(self, ROAS_output, media_level= None):
        ''' Aggregates the contribution and Spends on the basis of media level
        Params:
            ROAS_output: ROAS data at the most granular level
            media_level: Required media level'''
            
        ROAS_output['Display Level'] = ROAS_output.Variables.apply(self.get_var_description, args= (media_level, ))        
        ROAS_output = ROAS_output.groupby(['Display Level'])[['Total Contribution', 'Total Spend ($)','Raw Media']].sum().reset_index()
        return ROAS_output
        
                        
    def calculate_ROAS(self, model_type, start_date= None, end_date= None, media_level= None):
        '''Calculates ROAS on the basis of custom time period specified
        Params:
            start_date, end_date (date, default is entire period): date to filter the ROAS calculation
            media_level (integer): Aggregation of media at specific granularity level'''
        
        all_variables = list(self.model_dump[model_type]['Coefficient Summary'].Variables).copy()
        media_vars = [col for col in all_variables if col.startswith('M_')]
        
        media_spend_mapping, spend_vars, orig_vars, orig_trans_mapping = self.get_spend_vars(media_vars= media_vars)
        
        if start_date:
            df = self.df[(self.df.index >= start_date) & (self.df.index <= end_date)].copy()
        else:
            df = self.df.copy()
        
        average_price = self.calculate_price_average(df)
        
        # Contribution calculation
        df_vol_cont = pd.DataFrame()
        for col in media_vars:
            coef_table = self.model_dump[model_type]['Coefficient Summary']
            df_vol_cont[col] = df[col] * coef_table[coef_table.Variables == col]['Coefficient'].values[0]
        
   
        # Preparation of ROAS table
        df_ROAS_final = df_vol_cont.transpose()
        df_ROAS_final['Total Contribution'] = df_ROAS_final.sum(axis=1)
    
        df_ROAS_final = df_ROAS_final[['Total Contribution']]
    
    
        df_spends = df[spend_vars]
        spends_df = pd.DataFrame(df_spends.transpose().sum(axis=1),columns=['Total Spend ($)'])
        spends_df['Variables'] = spends_df.index.map(media_spend_mapping)
        spends_df.index = spends_df['Variables']
        spends_df = spends_df.drop(['Variables'],axis=1)
    
        df_raw_media = df[orig_vars]
        raw_media_df = pd.DataFrame(df_raw_media.transpose().sum(axis=1),columns=['Raw Media'])
        raw_media_df['Variables'] = raw_media_df.index.map(orig_trans_mapping)
        raw_media_df.index = raw_media_df['Variables']
        raw_media_df = raw_media_df.drop(['Variables'],axis=1)
        
        df_ROAS_media = pd.merge(spends_df, raw_media_df,how='left', left_index= True, right_index= True)
        df_ROAS_final = pd.merge(df_ROAS_media, df_ROAS_final,how='left', left_index= True, right_index= True)
        
        df_ROAS_final[self.ROAS_label] = 100 * df_ROAS_final['Total Contribution']/df_ROAS_final['Total Spend ($)']
        df_ROAS_final = df_ROAS_final.sort_values([self.ROAS_label], ascending = (False)).reset_index()
        
        
        ROAS_output = df_ROAS_final.copy()
        
        ROAS_output = self.modify_ROAS_table(ROAS_output, media_level= media_level)
        
        ROAS_output[self.ROAS_label] = 100 * ROAS_output['Total Contribution']/ROAS_output['Total Spend ($)']
        ROAS_output = ROAS_output.sort_values([self.ROAS_label], ascending = False).reset_index()
        
        ROAS_output[self.ROAS_value_label] = average_price * ROAS_output[self.ROAS_label]  
        
        return ROAS_output
    
    
    def visualize_ROAS(self, model_type, start_date= None, end_date= None, media_level= None, 
                       roas_100_multiplication= True,
                       spend_percent= False,
                       save_path= None, show_yaxis= True, save_roas_stats= False, custom_height= 900, 
                       custom_width = 1100, custom_space= -0.15, custom_RoAS_size =15):
        ''' Function to visualize ROAS
        Params:
            model_type: label for model
            start_date: period for filtering data (default is entire period)
            end_date: period for filtering data (default is entire period)
            media_level: granularity of media to be visualized
            save_path: path to save the model
        '''
        
        # To display numbers in decimal separated format
        pd.options.display.float_format = '{:20,.1f}'.format
        
        
        
        if start_date:
            df = self.df[(self.df.index >= start_date) & (self.df.index <= end_date)].copy()
        else:
            df = self.df.copy()
            
        average_price = self.calculate_price_average(df)
                
        ROAS_output = self.calculate_ROAS(model_type, start_date= start_date, end_date= end_date, 
                                        media_level= media_level)
        
        ROAS_output_display = ROAS_output.copy()
        
        ROAS_output_display = ROAS_output_display.drop(columns = 'index')
        
        total_contribution = ROAS_output_display['Total Contribution'].sum()
        total_spend = ROAS_output_display['Total Spend ($)'].sum()
        total_raw_media = ROAS_output_display['Raw Media'].sum()
        total_overall = df[self.target_var].sum()
        total_base = df[self.target_var].sum() - total_contribution
        
        ROAS_output_display['Contribution Share (%)'] = 100 * ROAS_output_display['Total Contribution']/total_contribution
        ROAS_output_display['Raw Media Share (%)'] = 100 * ROAS_output_display['Raw Media']/total_raw_media
        ROAS_output_display['Spend Share (%)'] = 100 * ROAS_output_display['Total Spend ($)']/total_spend
        ROAS_output_display = ROAS_output_display[['Display Level', 'Contribution Share (%)', 'Total Contribution', 'Total Spend ($)','Spend Share (%)','Raw Media','Raw Media Share (%)', self.ROAS_label,
                                                 self.ROAS_value_label]]
        
        ROAS_output_display.loc[ROAS_output_display.shape[0]] = ['Total Incremental', 
                                                                 100 * total_contribution/total_overall,
                                                                 total_contribution, total_spend,100,
                                                                 total_raw_media,100,
                                                                 100 * total_contribution / total_spend,
                                                                 100 * average_price * total_contribution / total_spend] 
        
        ROAS_output_display.loc[ROAS_output_display.shape[0]] = ['Base', 
                                                                 100 * total_base/total_overall,
                                                                 total_base, 
                                                                 0, 0, 0, 0, 0, 0] 
        
        ROAS_output_display.loc[ROAS_output_display.shape[0]] = ['Total', 
                                                                 100,
                                                                 df[self.target_var].sum(), 
                                                                 total_spend, 0, total_raw_media, 0,
                                                                 0, 0] 

        
        ROAS_output_display['Total Sales ($)'] = ROAS_output_display['Total Contribution'] * average_price
        
        
        ROAS_output_display = ROAS_output_display[['Display Level', 'Contribution Share (%)', 'Total Contribution', 
                                                   'Total Sales ($)', 'Total Spend ($)','Spend Share (%)', 'Raw Media','Raw Media Share (%)',
                                                   self.ROAS_label, self.ROAS_value_label]]
        
        if not roas_100_multiplication:
            ROAS_output_display[self.ROAS_label] = ROAS_output_display[self.ROAS_label]/100
            ROAS_output_display[self.ROAS_value_label] = ROAS_output_display[self.ROAS_value_label]/100
            
            ROAS_output[self.ROAS_label] = ROAS_output[self.ROAS_label]/100
            ROAS_output[self.ROAS_value_label] = ROAS_output[self.ROAS_value_label]/100
            
        pd.options.display.float_format = '{:,}'.format

        ROAS_output_display['Contribution Share (%)'] = round(ROAS_output_display['Contribution Share (%)'], 1)
        ROAS_output_display['Total Contribution'] = round(ROAS_output_display['Total Contribution']).astype('int64').apply('{:,}'.format)
        ROAS_output_display['Total Sales ($)'] = round(ROAS_output_display['Total Sales ($)']).astype('int64').apply('{:,}'.format)
        ROAS_output_display['Total Spend ($)'] = round(ROAS_output_display['Total Spend ($)']).astype('int64').apply('{:,}'.format)
        ROAS_output_display['Spend Share (%)'] = round(ROAS_output_display['Spend Share (%)'], 1)
        ROAS_output_display['Raw Media'] = round(ROAS_output_display['Raw Media']).astype('int64').apply('{:,}'.format)
        ROAS_output_display['Raw Media Share (%)'] = round(ROAS_output_display['Raw Media Share (%)'], 1)


        if roas_100_multiplication:
            ROAS_output_display[self.ROAS_label] = round(ROAS_output_display[self.ROAS_label], 2)
            ROAS_output_display[self.ROAS_value_label] = round(ROAS_output_display[self.ROAS_value_label], 2)
        else:
            ROAS_output_display[self.ROAS_label] = round(ROAS_output_display[self.ROAS_label], 3)
            ROAS_output_display[self.ROAS_value_label] = round(ROAS_output_display[self.ROAS_value_label], 3)
            
        if save_path == None:
            if roas_100_multiplication:
                display(ROAS_output_display)
            else:
                display_df = ROAS_output_display.copy()
                display(display_df)
        
        
        
        if save_roas_stats:
            return ROAS_output_display
            
        pd.options.display.float_format = '{:20,.5f}'.format
      
        
        bar1 = go.Bar(x= ROAS_output['Display Level'].apply(self.create_var_spacing), 
                      y= ROAS_output[self.ROAS_value_label], 
                      text = round(ROAS_output[self.ROAS_value_label], 1) if roas_100_multiplication else round(ROAS_output[self.ROAS_value_label], 3),
                      textposition='outside',outsidetextfont={'size':custom_RoAS_size},
                      marker_color= '#0071CE',yaxis='y1',name = self.ROAS_value_label)
                              
        if spend_percent:
            line1 = go.Scatter(x= ROAS_output['Display Level'].apply(self.create_var_spacing), 
                           y= 100 * ROAS_output['Total Spend ($)']/ROAS_output['Total Spend ($)'].sum(),
                           line= dict(color='#FFC220'), name= 'Spend ($)', yaxis='y2')
            data = [line1, bar1]
        else:
                   
            line1 = go.Scatter(x= ROAS_output['Display Level'].apply(self.create_var_spacing), 
                               y= ROAS_output['Total Contribution'],
                               line= dict(color='#041E41'),name='Volume Contribution', yaxis='y2')
                                          
            line2 = go.Scatter(x= ROAS_output['Display Level'].apply(self.create_var_spacing), 
                               y= ROAS_output['Total Spend ($)'],
                               line= dict(color='#FFC220'), name= 'Spend ($)', yaxis='y2')
            data = [line1, line2, bar1]
        
        fig = go.Figure(data)
        
        height= custom_height
        width= custom_width
        
        if ROAS_output.shape[0] <= 4:
            height= custom_height
            width= custom_width
        
        fig = self.update_layout(fig, title= self.ROAS_value_label + " by Media Driver",
                                 legend_orientation= 'h', height= height, width= width,
                                 title_x= 0.5, title_y= 0.95, legend_x= 0.25, legend_y= custom_space, 
                                 show_yaxis= show_yaxis, tickangle= 0)
  
        
        if save_path == None:
            fig.show()
        else:
            fig.write_image(os.path.join(save_path, "ROAS Analysis " + "Granularity " + str(media_level) + ".png"),
                      width= width, height= height, scale= 5)
        
        self.visualize_incremental_charts(model_type, ROAS_output, df, media_level, save_path= save_path)
        
        path = self.output_path
        if not os.path.isdir(path):
            os.mkdir(path)
        file_path = os.path.join(path, "WMC_{start_date}_{end_date}.csv".format(start_date = start_date, end_date = end_date))
        ROAS_output_display.to_csv(file_path)
            
            
        
    def visualize_incremental_charts(self, model_type, ROAS_output, df, media_level= None, save_path= None):
        
        ROAS_metric = ROAS_output.copy()
        
        incremental = ROAS_metric['Total Contribution'].sum()
        base = df[self.target_var].sum(axis=0) - incremental
        t_vc = [base, incremental]
        
        fig = go.Figure(data=[go.Pie(labels= ['Base','Incremental'], values= t_vc)])
        fig.update_traces(hoverinfo= 'label+percent', textfont_size= 15, textposition= 'outside',
                          marker= dict(colors=['#0071CE','#FFC220']))
        fig.update_layout(legend_orientation = 'h',
            legend=dict(x=0.3, y=-.15, font= dict(size= 14)),
            title={
                'text': "Base vs Incremental",
                'y':.9,
                'x':0.5,
                'xanchor': 'center',
                'yanchor': 'top'})
        if save_path == None:
            fig.show()
        else:
            fig.write_image(os.path.join(save_path, "Overall Increment Pie Chart.png"),
                      scale= 5)
        
                
        incremental_labels = ROAS_output['Display Level']
        incremental_values = ROAS_output['Total Contribution']
        
        all_colors = ['#0071CE', '#041E41','#FFC220', '#414041','#BFBFBF', '#9D9FA2', '#BDD7EE',
                       '#F58345', '#FF0000', '#70AD47', '#7F6000', '#008EA8']
        nunique_label = ROAS_output.shape[0]
        
        fig1 = go.Figure(data=[go.Pie(labels= incremental_labels, values= incremental_values)])
        fig1.update_traces(hoverinfo= 'label+percent', textfont_size= 15, textposition= 'outside',
                          marker= dict(colors= all_colors[0: nunique_label]))
        fig1.update_layout(legend_orientation = 'h',
            legend=dict(x=0.28, y=-.25, font= dict(size= 14)),
            title={
                'text': "Incremental by Media",
                'y':.9,
                'x':0.5,
                'xanchor': 'center',
                'yanchor': 'top'})
        if save_path == None:
            fig1.show()
        else:
            fig1.write_image(os.path.join(save_path, "Increment Pie Chart "+ "Granularity " + str(media_level) + ".png") ,
                      scale= 5)
            
            
       
    def update_layout(self, fig, title, legend_orientation= 'h', height= 500, width= 1000,
                      title_x= 0.46, title_y= 0.8, legend_x= 0.05, legend_y= -0.15, show_yaxis= True,
                      tickformat= ',.1f',
                      tickangle= 30, label_fontsize= 14, legend_fontsize= 14, title_fontsize= 20):
        
        fig.update_layout(dict(xaxis = dict(showgrid= False, ticks= 'outside', mirror= False, showline= False,
                                            linecolor= '#CED0D2', linewidth=1, tickangle= tickangle),
                                            
                               yaxis = dict(showgrid= False, mirror= True, ticks= '', showline= False, 
                                            showticklabels= show_yaxis,
                                            linecolor= 'black', linewidth= 1, tickformat= tickformat, rangemode= 'tozero'),
                                            
                               yaxis2 = dict(overlaying= 'y', side= 'right', tickformat= tickformat,
                                             showticklabels= show_yaxis,
                                             tickmode= 'auto', rangemode= 'tozero'), 
                                             
                               font=dict(size= label_fontsize),),
                                             
                            autosize= True,
                            width= width,
                            height= height,
                            paper_bgcolor= 'rgba(0,0,0,0)',
                            plot_bgcolor= 'rgba(0,0,0,0)',
                            title={
                                'text': title,
                                'y': title_y,
                                'x': title_x,
                                'xanchor': 'center',
                                'yanchor': 'top',
                                'font': dict(size= title_fontsize)},
                                legend_orientation= legend_orientation,
                                legend=dict(x= legend_x, y= legend_y, font= dict(size= legend_fontsize)))
        return fig    
                 
                               
    def visualize_model_outputs(self, model_type, contribution_graph= True, 
                                prediction_comparison= True, add_residual= True,
                                separate_validation= False, coeff_table= True,
                                show_yaxis= False,
                                analyst_review= False,
                                coef_threshold= 0, relative_imp_threshold= 0, significance_threshold= 85, 
                                p_value_threshold= 0.15,
                                elasticity_threshold= 0, vif_threshold= 5, mape_threshold= 10,
                                r_sq_threshold= 85, r_sq_adj_threshold= 85,
                                save_path= None):
        '''Single function to visualize model outputs.
        Params:
            model_type: Model Label
            contribution_graph: toggle for contribution graph (here would display for both modelling and validation period)
            prediction_comparison: toggle for prediction vs actual line graph
            add_residual: toggle to add residual term in the model
            separate_validation: if set to True, model would output different graphs for modelling and validation comparisoon
            coeff_table: toggle to view coefficient table
            analyst_review: toggle for analyst review
            threshold parameters: threshold for analyst review 
        '''
          
        # Analysis for Coefficient Summary
        if coeff_table:
            
            coeff_summary = self.model_dump[model_type]['Coefficient Summary'].copy()
            
            if analyst_review:
                self.coef_threshold = coef_threshold
                self.relative_imp_threshold = relative_imp_threshold
                self.significance_threshold = significance_threshold
                self.p_value_threshold = p_value_threshold
                self.elasticity_threshold = elasticity_threshold
                self.vif_threshold = vif_threshold
                
                coeff_summary = coeff_summary.style.apply(self.analyst_review_coef, axis= None)
                
            if save_path == None:
                display(coeff_summary)
            
            
        if prediction_comparison:
            model_stats = self.model_dump[model_type]['Modelling Metrics'].copy()
            df_validation_comparsion = self.model_dump[model_type]['Validation Comparison'].copy()
            df_modelling_comparsion = self.model_dump[model_type]['Modelling Comparison'].copy()

            if analyst_review:
                self.mape_threshold = mape_threshold
                self.r_sq_threshold = r_sq_threshold
                self.r_sq_adj_threshold = r_sq_adj_threshold
                model_stats = model_stats.style.apply(self.analyst_review_model, axis= None)
               
                
            if save_path == None:   
                display(model_stats)       
                        
              
            if separate_validation == False:
                data = []
                line1 = go.Scatter(x= df_modelling_comparsion.index, y= df_modelling_comparsion['Actuals'],
                                   line=dict(color='#0071CE'), name='Modeling Actual', yaxis= 'y1')
                line2 = go.Scatter(x= df_modelling_comparsion.index, y= df_modelling_comparsion['Predicted'],
                                   line=dict(color='#FFC220'), name='Modeling Predicted', yaxis= 'y1') 
                data.append(line1)
                data.append(line2)                                     
                
                if add_residual:
                    line3 = go.Scatter(x= df_modelling_comparsion.index, 
                                       y= ((df_modelling_comparsion.Predicted/df_modelling_comparsion.Actuals)-1),
                                       line=dict(color='#9D9FA2', width= 1), name='Modeling Residual', yaxis= 'y2')
                    data.append(line3)
                
                
                line4 = go.Scatter(x= df_validation_comparsion.index, y= df_validation_comparsion['Actuals'],
                                   line=dict(color='#0071CE'), name='Validation Actual', yaxis= 'y1')
                data.append(line4)
                
                line5 = go.Scatter(x= df_validation_comparsion.index, y= df_validation_comparsion['Predicted'],
                                   line=dict(color='#70AD47'), name='Validation Predicted', yaxis= 'y1')
                data.append(line5)
            
                if add_residual:
                    line6 = go.Scatter(x= df_validation_comparsion.index, 
                                       y= ((df_validation_comparsion.Predicted/df_validation_comparsion.Actuals)-1),
                                       line=dict(color='#9D9FA2', width= 1), name='Validation Residual', yaxis= 'y2')
                    data.append(line6)
    

                fig = go.Figure(data)
                fig = self.update_layout(fig, title= "Actual vs Predicted", legend_x= 0.15, show_yaxis= show_yaxis)
                
                if save_path == None:
                    fig.show()
                else:
                    if add_residual:
                        fig.write_image(os.path.join(save_path, " Residual Actual vs Predicted.png"),
                                    width= 1000, height= 500, scale= 5)
                    else:
                        fig.write_image(os.path.join(save_path, "Actual vs Predicted.png"),
                                    width= 1000, height= 500, scale= 5)
            
            else:
                
                data =  []
                line1 = go.Scatter(x= df_modelling_comparsion.index, y= df_modelling_comparsion['Actuals'],
                                   line=dict(color='#0071CE'), name='Modeling Actual', yaxis= 'y1')
                data.append(line1)
                
                if add_residual:
                    line2 = go.Scatter(x= df_modelling_comparsion.index, 
                                       y= ((df_modelling_comparsion.Predicted/df_modelling_comparsion.Actuals)-1),
                                       line=dict(color='#9D9FA2', width= 1), name='Modeling Residual', yaxis= 'y2')
                    data.append(line2)
                
                line3 = go.Scatter(x= df_modelling_comparsion.index, y= df_modelling_comparsion['Predicted'],
                                   line=dict(color='#FFC220'), name='Modeling Predicted', yaxis= 'y1')
                data.append(line3)
            
                    
                fig = go.Figure(data)
                fig = self.update_layout(fig, title= "Actual vs Predicted Modeling Period",
                                         legend_y= -0.25,
                                         legend_x= 0.25, show_yaxis= show_yaxis)
                
                if save_path == None:
                    fig.show()
                else:
                    if add_residual:
                        fig.write_image(os.path.join(save_path, "Residual Actual vs Predicted Modeling Period.png"),
                                        width= 1000, height= 500, scale= 5)
                    else:
                        fig.write_image(os.path.join(save_path, "Actual vs Predicted Modeling Period.png"),
                                        width= 1000, height= 500, scale= 5)
                   
                data = []
                # Validation period graph
                line1 = go.Scatter(x= df_validation_comparsion.index, 
                                   y= df_validation_comparsion['Actuals'],
                                   line=dict(color='#0071CE'), name='Validation Actual', yaxis= 'y1')
                data.append(line1)
                
                if add_residual:
                    line3 = go.Scatter(x= df_validation_comparsion.index, 
                                       y= ((df_validation_comparsion.Predicted/df_validation_comparsion.Actuals)-1),
                                       line=dict(color='#9D9FA2', width= 1), name='Validation Residual', yaxis= 'y2')
                    data.append(line3)
                
                line5 = go.Scatter(x= df_validation_comparsion.index, y= df_validation_comparsion['Predicted'],
                                   line=dict(color='#FFC220'), name='Validation Predicted', yaxis= 'y1')
                data.append(line5)

                    
                fig = go.Figure(data)
                
                fig = self.update_layout(fig, title= "Actual vs Predicted Validation Period",
                                         legend_y= -0.25,
                                         legend_x= 0.25, show_yaxis= show_yaxis)

                if save_path == None:
                    fig.show()
                else:
                    if add_residual:
                        fig.write_image(os.path.join(save_path, "Residual Actual vs Predicted Validation Period.png"),
                                        width= 1000, height= 500, scale= 5)
                    else:
                        fig.write_image(os.path.join(save_path, "Actual vs Predicted Validation Period.png"),
                                        width= 1000, height= 500, scale= 5)
            

            
        if contribution_graph:
            self.visualize_ROAS(model_type, save_path= save_path)
            
            
    def visualizate_media_transformation(self, media_var):
        
            lag = int(media_var.split("_")[-5])
            halflife = int(media_var.split("_")[-4])
            sscurve_inflection = float(media_var.split("_")[-3])
            sscurve_scale = float(media_var.split("_")[-2])
            ccurve = float(media_var.split("_")[-1])
            
            name = ''
            if lag != 0:
                name += 'Lag-' + str(lag) + ", "
            if halflife != 0:
                name += 'Halflife-' + str(halflife) + ", "
            if sscurve_scale != 0:
                name+= 'SCurve Scale-' + str(sscurve_scale)  + ", "
            if sscurve_inflection != 0:
                name+= 'SCurve Inflection-' + str(sscurve_inflection)  + ", "
            if ccurve > 0.0:
                name+= 'CCurve-' + str(ccurve)  + ", "
            name = name[:-2]
            
            orig_media_var = media_var.split("_")[:-5]
            orig_media_var = '_'.join([str(elem) for elem in orig_media_var])
            
            var_trans_obj = VariableTransformation(self.df, None, 
                                                   apply_adstock = self.apply_adstock)
    
            transformed_var = var_trans_obj.apply_media_transformations(var= self.df[orig_media_var],
                                                               lag= lag, halflife= halflife, inflection= sscurve_inflection,
                                                               scale= sscurve_scale, ccurve_toggle= ccurve).values
            orig_var = self.df[orig_media_var]
            
            plt.figure(figsize = (10, 6))

            fig = sns.scatterplot(x= orig_var, y= transformed_var)
            plt.ylabel(name, fontsize= 14)
            xlabel = self.data_dict[self.data_dict['Variable Name'] == orig_media_var]['Variable Description'].values[0]
            plt.xlabel(xlabel, fontsize= 14)
            plt.title('Transformation Scatter Plot', fontsize= 16)
            
            fig.set_xticklabels([])
            fig.set_yticklabels([])

            plt.show()
            
    def save_iteration_log(self):
        self.model_log.save_worksheet()
        
    def add_iteration_log(self, model_label):
        
        self.n_model_iteration += 1
        startrow = 0
        
        coefficient_summary = self.model_dump[model_label]['Coefficient Summary'].copy()
        coefficient_summary['Variable Actual'] = coefficient_summary.Variables
        coefficient_summary.Variables = coefficient_summary.Variables.apply(self.get_var_description)
        
        self.model_log.add_worksheet(coefficient_summary, 'Iteration ' + str(self.n_model_iteration),
                                    decimal_5_col_names= coefficient_summary.columns,
                                    startrow= startrow)
        
        startrow += coefficient_summary.shape[0] + 2
        
        model_stats = self.model_dump[model_label]['Modelling Stats'].reset_index().copy()
        model_stats = model_stats.rename(columns= {'index': 'Metric', 'Validation Metrics': 'Validation Fit'})
        self.model_log.add_worksheet(model_stats, 'Iteration ' + str(self.n_model_iteration),
                                    decimal_5_col_names= model_stats.columns,
                                    startrow= startrow)
        
        ROAS_stats = self.visualize_ROAS(model_type= model_label, start_date= self.modelling_start, 
                                         end_date= self.modelling_end,
                                         roas_100_multiplication= True,
                                         save_roas_stats= True)

        
        startrow += model_stats.shape[0] + 2
        
        self.model_log.add_worksheet(ROAS_stats, 'Iteration ' + str(self.n_model_iteration),
                                decimal_col_names = ['Total Sales ($)', 'Total Spend ($)', 
                                                     'Total Contribution', 'Contribution Share (%)',
                                                     'Spend Share (%)', 'Raw Media','Raw Media Share (%)'],
                                decimal_5_col_names= [self.ROAS_label, self.ROAS_value_label],
                                startrow= startrow)
        
        pd.options.display.float_format = '{:20,.5f}'.format
        
            
    def save_manual_model(self, model_label, start_period_1, end_period_1,
                          start_period_2, end_period_2, year_1, year_2,
                          media_vars_plot,
                          add_ROAS_for_validation= False,
                          on_air_start = '2019-04-01', 
                          on_air_end= '2020-01-31', 
                          roas_100_multiplication= True,
                          folder_name= None):   
        
        
        start_date = self.modelling_start
        end_date = self.modelling_end
        
        if add_ROAS_for_validation:
            end_date = self.validiation_end
            
            
        path = self.output_path 
        if folder_name:
            path = os.path.join(path, folder_name)
            
        os.mkdir(path)
        
        graph_path = os.path.join(path, "graphs")
        
        try:
            os.mkdir(path)
        except:
            pass
        os.mkdir(graph_path)
        
        excel_obj = SaveExcelTemplated(os.path.join(path, "model_outputs.xlsx"))
        
        coefficient_summary = self.model_dump[model_label]['Coefficient Summary'].copy()
        coefficient_summary['Variable Actual'] = coefficient_summary.Variables
        coefficient_summary.Variables = coefficient_summary.Variables.apply(self.get_var_description)
        excel_obj.add_worksheet(coefficient_summary, 'Coefficient Summary',
                                    decimal_5_col_names= coefficient_summary.columns)
        
        model_stats = self.model_dump[model_label]['Modelling Stats'].reset_index().copy()
        model_stats = model_stats.rename(columns= {'index': 'Metric', 'Validation Metrics': 'Validation Fit'})
        excel_obj.add_worksheet(model_stats, 'Model Stats',
                                    decimal_5_col_names= model_stats.columns)
        
        # ROAS_stats = self.model_dump[model_label]['ROAS'].copy()
        # ROAS_stats.Variables = ROAS_stats.Variables.apply(self.get_var_description)
        
        ROAS_stats = self.visualize_ROAS(model_type= model_label, start_date= start_date, 
                                         end_date= end_date,
                                         roas_100_multiplication= roas_100_multiplication,
                                         save_roas_stats= True)
        
        excel_obj.add_worksheet(ROAS_stats, 'Contribution',
                                decimal_col_names = ['Total Sales ($)', 'Total Spend ($)', 
                                                     'Total Contribution', 'Contribution Share (%)',
                                                     'Spend Share (%)', 'Raw Media','Raw Media Share (%)'],
                                decimal_5_col_names= [self.ROAS_label, self.ROAS_value_label])
        
        
        df_act_vs_pred_mod = self.model_dump[model_label]['Modelling Comparison'].copy()
        df_act_vs_pred_mod['index'] = df_act_vs_pred_mod.index
        df_act_vs_pred_mod['index'] = df_act_vs_pred_mod['index'].astype(str)
        df_act_vs_pred_mod['Residual'] = (df_act_vs_pred_mod.Predicted/df_act_vs_pred_mod.Actuals)-1
        excel_obj.add_worksheet(df_act_vs_pred_mod[['index','Actuals', 'Predicted', 'Residual']], 'Act vs Pred Modelling',
                                decimal_col_names = ['Predicted','Actuals'],
                                decimal_5_col_names = ['Residual'])
        
        df_act_vs_pred_val = self.model_dump[model_label]['Validation Comparison'].copy()
        df_act_vs_pred_val['index'] = df_act_vs_pred_val.index
        df_act_vs_pred_val['index'] = df_act_vs_pred_val['index'].astype(str)        
        df_act_vs_pred_val['Residual'] = (df_act_vs_pred_val.Predicted/df_act_vs_pred_val.Actuals)-1
        excel_obj.add_worksheet(df_act_vs_pred_val[['index','Actuals', 'Predicted', 'Residual']], 'Act vs Pred Validation',
                                decimal_col_names = ['Predicted','Actuals'],
                                decimal_5_col_names = ['Residual'])
        
        vol_cont_all = self.model_dump[model_label]['Volume Contribution All'].copy()
        vol_cont = self.model_dump[model_label]['Volume Contribution'].copy()
        media_col = [col for col in vol_cont if col.startswith('M_')]
        vol_cont['Baseline Sales'] = vol_cont_all[self.target_var] - vol_cont[media_col].sum(axis= 1)
        vol_cont['Total Sales'] = vol_cont_all[self.target_var]
        vol_cont['index'] = vol_cont.index
        vol_cont['index'] = vol_cont['index'].astype(str)                
        vol_cont.set_index(vol_cont.columns[-1], inplace=True)
        vol_cont.reset_index(inplace=True)
        excel_obj.add_worksheet(vol_cont, 'Base - Incrmental Contribution',
                                decimal_col_names = [[media_col,'Baseline Sales', 'Total Sales']])
        

        excel_obj.save_worksheet()
        
        
        # Variable transformations
        excel_obj = SaveExcelTemplated(os.path.join(path, "variables_transformation_summary.xlsx"))
        
        df_tranf = pd.DataFrame()
        df_points = pd.DataFrame(columns= ['Variable', 'Threshold Point', 'Inflection Point', 'Saturation Point', 'Non-Zero Average'])
        df_points_sp = pd.DataFrame(columns= ['Variable', 'Threshold Point', 'Inflection Point', 'Saturation Point', 'Non-Zero Average'])
        df_tranf_op_analysis = pd.DataFrame()
        df_tranf_op_analysis_sp = pd.DataFrame()
        
        for var in self.model_dump[model_label]['Coefficient Summary'].Variables.values:
            if var.startswith('M_'):
                try:
                    var_name, transf, sat_pt, inf_pt, opt_analysis, non_zero_average, threshold_point, inf_pt_sp, non_zero_av_sp, sat_pt_sp, thres_pt_sp, opt_analysis_sp = self.plot_response_curve(var, model_label, save_path= graph_path,
                                                                                                                                                                                    start_date= self.modelling_start, 
                                                                                                                                                                                    end_date= self.modelling_end,
                                                                                                                                                                                    save_excel= True,
                                                                                                                                                                                    use_freezed_values= True, use_freezed_values_tp= True,
                                                                                                                                                                                    spend= False)
                    self.plot_response_curve(var, model_label, save_path= graph_path,
                                             use_freezed_values= True,
                                             start_date= self.modelling_start, 
                                             end_date= self.modelling_end,
                                             save_excel= False,
                                             spend= False)
                    
                    df_tranf[self.get_var_description(var_name)] = transf
                    df_points.loc[df_points.shape[0]] = [var_name, threshold_point, inf_pt, sat_pt, non_zero_average]
                    df_points_sp.loc[df_points_sp.shape[0]] = [var_name, thres_pt_sp, inf_pt_sp, sat_pt_sp, non_zero_av_sp]
                    df_tranf_op_analysis = pd.concat([df_tranf_op_analysis, opt_analysis], axis= 0)
                    df_tranf_op_analysis_sp = pd.concat([df_tranf_op_analysis_sp, opt_analysis_sp], axis= 0)
                except:
                    pass
        try:
            excel_obj.add_worksheet(df_tranf, 'Transformations',
                                    decimal_5_col_names= df_tranf.columns)
            excel_obj.add_worksheet(df_points, 'Points')
            excel_obj.add_worksheet(df_points_sp, 'Spends Points')
            excel_obj.add_worksheet(df_tranf_op_analysis, 'Airing Analysis',
                                    percent_col_names= ['Optimal Range Days (%)',
                                                        'Beyond Saturation Days (%)', 
                                                        'Below Inflection Days (%)'])
            excel_obj.add_worksheet(df_tranf_op_analysis_sp, 'Airing Analysis Spends',
                                    percent_col_names= ['Optimal Range Days (%)',
                                                        'Beyond Saturation Days (%)', 
                                                        'Below Inflection Days (%)'])
            excel_obj.save_worksheet()
        
        except:
            pass
        

        self.visualize_model_outputs(model_label, contribution_graph= False,  
                                prediction_comparison= True, add_residual= True, coeff_table= False,
                                save_path= graph_path)
        
        self.visualize_model_outputs(model_label, contribution_graph= False, 
                                prediction_comparison= True, add_residual= False, coeff_table= False,
                                save_path= graph_path)
        
        self.visualize_model_outputs(model_label, contribution_graph= False, 
                                separate_validation= True,
                                prediction_comparison= True, add_residual= True, coeff_table= False,
                                save_path= graph_path)
        
        self.visualize_model_outputs(model_label, contribution_graph= False, 
                                separate_validation= True,
                                prediction_comparison= True, add_residual= False, coeff_table= False,
                                save_path= graph_path)
        
        
            
        self.visualize_ROAS(model_label, start_date= start_date, end_date= end_date,
                           media_level= 3, save_path= graph_path)
        self.visualize_ROAS(model_label, start_date= start_date, end_date= end_date,
                           media_level= 4, save_path= graph_path)
        self.visualize_ROAS(model_label,  start_date= start_date, end_date= end_date,
                           media_level= 5, save_path= graph_path)
        self.visualize_ROAS(model_label,  start_date= start_date, end_date= end_date,
                           media_level= 6, save_path= graph_path)
        
        self.visualize_ROAS(model_label, media_level= 6, save_path= graph_path)
        self.visualize_ROAS(model_label, media_level= 6, save_path= graph_path)
        
        
        self.visualize_due_calculations(model_label, start_period_1= start_period_1, end_period_1= end_period_1, 
                                        start_period_2= start_period_2, end_period_2= end_period_2,
                                        combine_all_dummy_variables= True,
                                        combine_seasonaity_terms= True,
                                        save_path= graph_path)
    
        self.display_elasticity_plot(model_label, bar_variable= 'Elasticity', save_path= graph_path)
        self.display_elasticity_plot(model_label, bar_variable= 'Coefficient', save_path= graph_path)
        self.display_ROAS_year_on_year(model_label, year_1= year_1, year_2= year_2, save_path= graph_path)
        self.display_base_incremental(model_label, save_path= graph_path)
        
        add_plots_obj = ModellingPlots(self)

        add_plots_obj.plot_media_on_off_analysis(model_label, show_yaxis= True,
                                                 on_air_start = on_air_start, 
                                                 on_air_end= on_air_end, 
                                                 on_air_vars= media_vars_plot,
                                                 save_path= graph_path)
           
        

    def get_var_description(self, x, media_level= None, combine_holidays= False, combine_days_events_mod= False, 
                            combine_all_dummy_variables= False,
                            combine_seasonaity_terms= False,combine_non_media_drivers= False):
        
        if x.startswith('M_'):
            try:
                int(x.split("_")[-1])
                var = x.split("_")[:-5]
                var = '_'.join([str(elem) for elem in var])
            except:
                var = x
            if media_level:
                level_var = self.media_hier[self.media_hier.Variable == var]['Hierarchy ' + str(media_level)].values[0]
                output_desc =  self.data_dict[self.data_dict['Variable Name'] == level_var]['Variable Description'].values[0]
            else:
                output_desc = self.data_dict[self.data_dict['Variable Name'] == var]['Variable Description'].values[0]
    
            output_desc = output_desc.replace("Offsite Display Viewable Impression", "Offsite AppNexus Viewable Imp")
            output_desc = output_desc.replace("Offsite Display Impression", "Offsite AppNexus Imp")
            output_desc = output_desc.replace("Offsite Display Click", "Offsite AppNexus Click")
            output_desc = output_desc.replace("Offsite Display Spend", "Offsite AppNexus Spend")
            
            output_desc = output_desc.replace(" Viewable Impression", " Viewable Imp")
            output_desc = output_desc.replace(" Impression", " Imp")
            
            #output_desc = output_desc.replace("Onsite Display", "Onsite")
            #output_desc = output_desc.replace("Offsite Display", "Offsite")
            output_desc = output_desc.replace("  ", " ")
            return output_desc
        
        else:
            if self.data_dict[self.data_dict['Variable Name'] == x].shape[0] > 0:
                output_desc = self.data_dict[self.data_dict['Variable Name'] == x]['Variable Description'].values[0]
                if combine_all_dummy_variables:
                    if ('Dummy' in output_desc) | ('EVENT' in x) | ('DAY' in x) | ('MOD' in x):
                        return 'Days/Holidays/Events'
                if combine_holidays:
                    if 'Holiday' in output_desc:
                        return 'Holidays'
                if combine_days_events_mod:
                    if ('day' in output_desc) | ('EVENT' in x) | ('MOD' in x):
                        return 'Days/Events/Mod'
                if combine_seasonaity_terms:
                    if ('SEASON' in x) | ('TREND' in x) | ('RESIDUAL' in x) | ('SARIMA' in x) | ('_SMA_DAY_' in x):
                        return 'Seasonality'
                if combine_non_media_drivers:
                    if ('COVID' in x) | ('EVENT' in x) | ('DAY' in x) | ('MOD' in x) | ('PRICE' in x) | ('Unexplained' in output_desc) | ('Dummy' in output_desc) | ('Holiday' in output_desc) | ('SEASON' in x) | ('TREND' in x) | ('RESIDUAL' in x) | ('SARIMA' in x) | ('_SMA_DAY_' in x) :
                        return 'Non Media Drivers'
                return output_desc
            
            # If variable is not availabe in data dictionary
            else:
                if combine_all_dummy_variables:
                    if x.startswith('D_'):
                        return 'Days/Holidays/Events'
                if combine_holidays:
                    if x.startswith('D_HOL'):
                        return 'Holidays'
                if combine_days_events_mod:
                    if (x.startswith('D_DAY')) | ('EVENT' in x) | ('MOD' in x):
                        return 'Days/Events/Mod'
                if combine_seasonaity_terms:
                    if ('SEASON' in x) | ('TREND' in x) | ('RESIDUAL' in x) | ('SARIMA' in x) | ('_SMA_DAY_' in x):
                        return 'Seasonality'
                if combine_non_media_drivers:
                    if ('COVID' in x) | ('EVENT' in x) | ('DAY' in x) | ('MOD' in x) | ('PRICE' in x) | ('Unexplained' in x) | (x.startswith('D_')) | (x.startswith('D_HOL')) | ('SEASON' in x) | ('TREND' in x) | ('RESIDUAL' in x) | ('SARIMA' in x) | ('_SMA_DAY_' in x) :
                        return 'Non Media Drivers'
                    
            return x.replace(self.target_var + "_", "")
                    
        
    def display_elasticity_plot(self, model_label, bar_variable, save_path= None):
        '''Function to display elasticity plot
        Params:
            model_label: label for model
            bar_variable: option to choose b/w elasticity and coefficient
        '''
        coeff_summary = self.model_dump[model_label]['Coefficient Summary'].copy()
        coeff_summary = coeff_summary[coeff_summary.Variables.str.startswith('M_')]
        
        coeff_summary.Variables = coeff_summary.Variables.apply(self.get_var_description)
        coeff_summary = coeff_summary.sort_values(by= bar_variable, ascending= False).reset_index(drop= True)
        
        
        coeff_summary_plot = coeff_summary.copy()
        coeff_summary_plot[bar_variable] = coeff_summary_plot[bar_variable]
        plt.figure(figsize=(10,5))
        splot = sns.barplot(x= bar_variable, y= "Variables", data= coeff_summary_plot,
                   color= '#0071CE')
        
        for p in splot.patches:
            splot.annotate(format(p.get_width(), '.5f'), 
                           (p.get_width(), p.get_y() + p.get_height()/1.3), 
                           ha = 'center', va = 'center', xytext = (25, 10), textcoords = 'offset points')
                    
        plt.ylabel('')
        plt.xlabel('')
        plt.xticks([])
        plt.xticks(rotation= 90)
        
        splot.spines['right'].set_visible(False)
        splot.spines['top'].set_visible(False)
        splot.spines['left'].set_visible(False)
        
        
        plt.title(bar_variable)
        if save_path == None:
            plt.show()
        else:
            plt.tight_layout()
            plt.savefig(os.path.join(save_path, bar_variable + " Bar Chart.png"))
        
        
    def display_ROAS_year_on_year(self, model_label, media_level= None, 
                                  roas_100_multiplication= True,
                                  switch_to_value_roas= False,
                                  save_path= None, year_1= 2018, year_2= 2019):
        '''Function to display ROAS for yearly comparison
        
        Params:
            model_label: label for model
            media_level: granularity for media
            year_1, year_2: years for comparison
        '''
        
        ROAS_yearly = self.model_dump[model_label]['ROAS Yearly'].copy()
        
        ROAS_yearly.Variable = ROAS_yearly.Variable.apply(self.get_var_description, 
                                                        args= (media_level, ))
        
        ROAS_yearly = ROAS_yearly.groupby(['Year', 'Variable']).sum().reset_index()
        
        if roas_100_multiplication:
            ROAS_yearly['ROAS'] = 100 * ROAS_yearly['Contribution']/ROAS_yearly['Spend ($)']
        else:
            ROAS_yearly['ROAS'] = ROAS_yearly['Contribution']/ROAS_yearly['Spend ($)']
            
        if switch_to_value_roas:
            ROAS_yearly['ROAS'] = ROAS_yearly['ROAS'] * self.calculate_price_average(None)
            
        ROAS_yearly = ROAS_yearly[ROAS_yearly.Year.isin([year_1, year_2])]
        
        plt.figure(figsize=(14, 8))
        splot = sns.barplot(x= "Variable", y= 'ROAS', hue= "Year", data= ROAS_yearly,
                            ci=None,  palette=["#0071CE", "#FFC220"])
        
        for p in splot.patches:
            if roas_100_multiplication:
                splot.annotate(format(p.get_height(), '.1f'), 
                               (p.get_x() + p.get_width() / 2., p.get_height()), 
                               ha = 'center', va = 'center', xytext = (0, 10), textcoords = 'offset points')
            else:
                splot.annotate(format(p.get_height(), '.3f'), 
                               (p.get_x() + p.get_width() / 2., p.get_height()), 
                               ha = 'center', va = 'center', xytext = (0, 10), textcoords = 'offset points')
        plt.ylabel('')
        plt.xlabel('')
        plt.yticks([])
        plt.xticks(rotation= 0)
        plt.legend(loc='best')
        splot.spines['right'].set_visible(False)
        splot.spines['top'].set_visible(False)
        splot.spines['left'].set_visible(False)
        
        import textwrap
        splot.set_xticklabels(textwrap.fill(x.get_text(), 12) for x in splot.get_xticklabels())
        
        plt.title(self.ROAS_label + " Yearly Analysis")
        
        if switch_to_value_roas:
            plt.title(self.ROAS_value_label + " Yearly Analysis")
            
        if save_path == None:
            plt.show()
        else:
            plt.tight_layout()
            if switch_to_value_roas:
                plt.savefig(os.path.join(save_path, self.ROAS_label + " yearly analysis.png"))
            else:
                plt.savefig(os.path.join(save_path, self.ROAS_value_label + " yearly analysis.png"))
            
        
    def display_base_incremental(self, model_label, media_level= None, save_path= None, 
                                 n_top_channels= None,
                                 start_date= None, end_date= None):
        '''Function to display base vs incremental area plot. 
        No option of displaying y axis as graph has been scaled to show media variables more intuitively
        
        Params:
            model_label: label for model
            media_level: granularity of media for visualization
            n_top_channels: Number of top channels to be viewed (on basis of ROAS/NCOI)
            start_date, end_date: Specify the time period for graph
        '''
        plot_obj = ModellingPlots(self)
        vol_cont, base_vol = plot_obj.display_base_incremental(model_label, media_level= media_level, 
                                                               save_path= save_path, 
                                                               n_top_channels= n_top_channels,
                                                               start_date= start_date, end_date= end_date)
        # create the dataframe for the modeling duration, start date, end_date
        model_report_df = pd.DataFrame({"model_start_date":[start_date], 
                                        "model_end_date":[end_date]}, index = [0])
        base_vol = pd.DataFrame({'index': base_vol.index,
                                 'base':base_vol.values})
        ### add the data to work_sheet
        path = self.output_path
        base_incremental_path = os.path.join(path, "base_incremental")
        if not os.path.isdir(path):
            os.mkdir(path)
        if not os.path.isdir(base_incremental_path):
            os.mkdir(base_incremental_path)
        excel_obj = SaveExcelTemplated(os.path.join(base_incremental_path, "base_incremental.xlsx"))   
        excel_obj.add_worksheet(vol_cont, 'base_incremental', decimal_5_col_names= vol_cont.columns)
        excel_obj.add_worksheet(base_vol, 'base_vol', decimal_5_col_names= base_vol.columns)
        excel_obj.add_worksheet(model_report_df, 'modelling', decimal_5_col_names= model_report_df.columns)
        excel_obj.save_worksheet()

    def set_plot_point_position(self,inf_pt_pos,
                              sat_pt_pos, thres_pt_pos, avg_pt_pos):
        self.inf_pt_pos = inf_pt_pos
        self.sat_pt_pos = sat_pt_pos
        self.thres_pt_pos = thres_pt_pos
        self.avg_pt_pos = avg_pt_pos

    def plot_response_curve(self, var, model_label, start_date, end_date, spend= True, save_path= None,show_xy_labels = False,
                            saturation_calculator= 'logistic', threshold_calculator ='logistic',show_xyaxis_title = True,
                            use_freezed_values= False,use_freezed_values_tp= False,
                            save_excel= False):
        
        # Fetching the variable details i.e. original variable name and the corresponding transformations
        plot_obj = ModellingPlots(self)

        plot_obj.set_plot_point_position(self.inf_pt_pos, self.sat_pt_pos,self.thres_pt_pos,self.avg_pt_pos)

        if use_freezed_values:
            if var in self.var_satur_points.keys():
                saturation_calculator = self.var_satur_points[var]
        
        if use_freezed_values_tp:
            if var in self.var_thres_points.keys():
                threshold_calculator = self.var_thres_points[var]
#         print(saturation_calculator,threshold_calculator)
        self.threshold_calculator[var] = threshold_calculator
        self.saturation_calculator[var] = saturation_calculator
      
        
        if save_excel:
            var, transf, saturation_point, inflection_point, op_results, non_zero_average, threshold_point,inf_pt_sp, non_zero_av_sp, sat_pt_sp, thres_pt_sp, opt_analysis_sp = plot_obj.plot_response_curve(var= var, model_label= model_label, 
                                                                                                                                                                                            start_date= start_date, end_date= end_date, 
                                                                                                                                                                                            saturation_calculator= saturation_calculator,
                                                                                                                                                                                            threshold_calculator= threshold_calculator,
                                                                                                                                                                                            save_path= save_path, spend= spend, save_excel= True)
            return var, transf, saturation_point, inflection_point, op_results, non_zero_average, threshold_point, inf_pt_sp, non_zero_av_sp, sat_pt_sp, thres_pt_sp, opt_analysis_sp
        else:
            inflection_point, inflection_point_y, non_zero_average, non_zero_average_y, saturation_point, saturation_point_y, threshold_point, threshold_point_y, df_plot, artificial_x, artificial_y = plot_obj.plot_response_curve(var= var, model_label= model_label,
                                 start_date= start_date, end_date= end_date, show_xy_labels = show_xy_labels,show_xyaxis_title = show_xyaxis_title,
                                 saturation_calculator= saturation_calculator,threshold_calculator=threshold_calculator,
                                 save_path= save_path, spend= spend, save_excel= False)
        response_curve_points_dic = {"points": ["inflection", "non_zero_average", "saturation", "threshold"],
                                    "x" : [inflection_point, non_zero_average, saturation_point, threshold_point],
                                    "y" : [inflection_point_y, non_zero_average_y, saturation_point_y, threshold_point_y]}
        response_curve_points_df = pd.DataFrame(response_curve_points_dic)
        # create the dataframe for the modeling duration, start date, end_date
        model_report_df = pd.DataFrame({"model_start_date":[start_date], 
                                           "model_end_date":[end_date]}, index = [0])
        
        # updated Aug 2
        artificial_df = pd.DataFrame({'artificial_x': artificial_x, 
                                    'artificial_y': artificial_y})
        
        
        ### add the data to work_sheet
        path = self.output_path
        response_curve_path = os.path.join(path, 'response_curve_{start}_{end}'.format(start = start_date, end = end_date))
        if not os.path.isdir(path):
            os.mkdir(path)
        if not os.path.isdir(response_curve_path):
            os.mkdir(response_curve_path)
        excel_obj = SaveExcelTemplated(os.path.join(response_curve_path, "{var}.xlsx".format(var=var)))   
        #excel_obj.add_worksheet(df_plot, '{var}'.format(var=var), decimal_5_col_names= df_plot.columns)
        # change July 26
        #excel_obj.add_worksheet(df_plot, '{var}'.format(var=var.rsplit('_', 5)[0]), decimal_5_col_names= df_plot.columns)
        excel_obj.add_worksheet(df_plot, 's_curve', decimal_5_col_names= df_plot.columns)
        
        excel_obj.add_worksheet(response_curve_points_df, 'points', decimal_5_col_names= response_curve_points_df.columns)
        excel_obj.add_worksheet(model_report_df, 'modelling', decimal_5_col_names= model_report_df.columns)
        # added Aug 2
        excel_obj.add_worksheet(artificial_df, 'Artificial', decimal_5_col_names= artificial_df.columns)
        excel_obj.save_worksheet()
        
            
    def freeze_saturation_point(self, var, saturation_calculator):
        self.var_satur_points[var] = saturation_calculator
    
    def freeze_threshold_point(self, var, threshold_calculator):
        self.var_thres_points[var] = threshold_calculator
        
        
    def create_var_spacing(self, x):
        x = str(x)
        
        x = x.replace("Onsite ", "Onsite<br>")
        x = x.replace("Offsite ", "Offsite<br>")
        x = x.replace("Display ", "Display<br>")
        x = x.replace("Sponsored ", "Sponsored<br>")
        x = x.replace("Contextual ","Contextual<br>")
        x = x.replace("Behavioral ","Behavioral<br>")
        x = x.replace(" & ", " &<br>")
        x = x.replace(", ", ",<br>")
        x = x.replace(" Imp", "<br> Imp")
        x = x.replace(" Click", "<br> Click")
        x = x.replace(" Spend", "<br> Spend")
        
        return x
        
