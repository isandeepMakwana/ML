# -*- coding: utf-8 -*-
"""
Created on Fri May 15 13:57:01 2020
Updated on Fri Sep 08 2021 by rohan garg

@author: rajat.bansal
"""

import pandas as pd
import numpy as np
import plotly.graph_objects as go
import os
import math
from IPython.display import display
import matplotlib.pyplot as plt
from custom_transformation_functions import lag_transformation, halflife_transformation

#Below function transforms the data basis the given transformation
def transformation_calc(df,Media_var,inflection,scale,percent,coeff):
    
    Points_for_calc = pd.DataFrame({"X_values" : [df.loc[:,Media_var].mean() * inflection]})
    a = Points_for_calc.shape[0]
    Points_for_calc.loc[a] = ['']
    Points_for_calc.iloc[a,0] = (1+percent/100) * Points_for_calc.iloc[a-1,0]
    
    Impressions = pd.concat([df[Media_var],Points_for_calc['X_values']],ignore_index=True)
    Impressions = pd.DataFrame(Impressions).rename(columns={0:Media_var})
    scurve_data = Impressions.applymap(float)
    scurve_data['var_mean']=scurve_data.iloc[0:df.shape[0],0].mean()
    scurve_data['trans_var']=scurve_data.iloc[:,0]
    scurve_data['t']=scurve_data['trans_var']/scurve_data['var_mean']
    scurve_data['Scale_term'] = ((inflection - scurve_data['t'])*scale)
    scurve_data['exp_scale_term'] = 1/(1+np.exp(scurve_data['Scale_term']))
    scurve_data['exp_scale_inf_term'] = 1/(1+np.exp(inflection*scale))
    scurve_data['scf'] = scurve_data['exp_scale_term'] - scurve_data['exp_scale_inf_term']  
    scurve_data['scurve_term'] = (scurve_data['scf'] * scurve_data['var_mean'])/scurve_data.loc[:df.shape[0]-1,'scf'].mean()
    scurve_data['VC'] = scurve_data['scurve_term'] * abs(coeff)
    return scurve_data

def gompertz_logistic_saturation_pts(df_plot, Media_var, percent, inflection, scale, coeff, saturation_calculator):

    df = df_plot.copy()
    #Calculation of Saturation Point using Gompertz function
    n_mod = df.shape[0] #storing no. of rows for modelling period data
    
    scurve_data1 = transformation_calc(df,Media_var,inflection,scale,percent,coeff) #Calling transformation function 
    
    n_tot = scurve_data1.shape[0] #storing no. of rows for total data
    Max_x = scurve_data1.iloc[:n_mod,0].max()
    Max_y = scurve_data1.loc[:n_mod-1,'VC'].max()

    Max_x_all = scurve_data1.iloc[:, 0].max()
    Max_y_all = scurve_data1.loc[:,'VC'].max()

    if (Max_x_all > Max_x) or (Max_y_all > Max_y):
        Max_x = Max_x_all
        Max_y = Max_y_all + 0.1
    Point = pd.DataFrame({'Media':[Media_var]})  
    
    if saturation_calculator == 'gompertz'or saturation_calculator == 'average':
        print('Note: By default the exported excel file values for Saturation point calculation follows LOGISTIC calculator. In case user want to use saturation calculator other than Logistic, user need to update values in exported excel file manually')
        scurve_data1['x_indexed']=scurve_data1[Media_var]/Max_x
        scurve_data1['y_indexed']=scurve_data1['VC']/Max_y
        df2=scurve_data1.loc[df.shape[0]:,[Media_var,'VC','x_indexed','y_indexed']]

        b = math.exp((df2['x_indexed'][n_tot-2]*math.log(-math.log(df2['y_indexed'][n_tot-1]))-(df2['x_indexed'][n_tot-1]*math.log(-math.log(df2['y_indexed'][n_tot-2]))))/(df2['x_indexed'][n_tot-2]-df2['x_indexed'][n_tot-1]))

        c= (math.log(-math.log(df2['y_indexed'][n_tot-2])/b)/-(df2['x_indexed'][n_tot-2]))
        x = math.log(math.log(.999)/-b)*(1/-c)
        Point['Saturation Point using Gompertz'] =  x*Max_x

    #Calculation of Threshold Point using Logistic function
    # 4.59511985013 for 99% saturation and 2.944438979 for 95% saturation
    data = transformation_calc(df,Media_var,inflection,scale,percent,coeff)
    scurve_data = data[0:-2]
    
    
#     scurve_data['Adjusted S'] = scurve_data['scurve_term']/scurve_data['scurve_term'].max()
#     scurve_data['Slope'] = (1- scurve_data['Adjusted S']) * scurve_data['Adjusted S']
#     scurve_data['Derivative Of Slope'] = (1- scurve_data['Adjusted S']) * scurve_data['Slope'] - scurve_data['Adjusted S'] * scurve_data['Slope']     
#     scurve_data['Logistic Function'] = np.log( 1 / (scurve_data['Adjusted S']+coeff)-1) / ((scurve_data[Media_var].astype(float) -(scurve_data[Media_var].mean() *inflection)))
    
#     scurve_data['Logistic Function'] = scurve_data['Logistic Function'].fillna(0) # if there is any error in this column, fillNA=0



    # 4.59511985013 for 99% saturation and 2.944438979 for 95% saturation
    
    Point['Saturation Point using Logistic'] = (4.59511985013/(scale) + inflection) * scurve_data[Media_var].mean()
       
    
    if saturation_calculator == 'average':
        saturation = Point[['Saturation Point using Gompertz', 'Saturation Point using Logistic']].mean(axis= 1)
    elif saturation_calculator == 'gompertz':
        saturation = Point[['Saturation Point using Gompertz']].min(axis= 1)
    else:
        saturation = Point[['Saturation Point using Logistic']].min(axis= 1)
        
    return saturation.values[0]

def gompertz_logistic_threshold_pts(df_plot,Media_var,percent,inflection,scale,coeff,threshold_calculator):
    df = df_plot.copy()
    n_mod = df.shape[0]
    
    scurve_data1 = transformation_calc(df,Media_var,inflection,scale,percent,coeff) #Calling transformation function 
    n_tot = scurve_data1.shape[0] #storing no. of rows for total data
    Max_x = scurve_data1.iloc[:n_mod,0].max()
    Max_y = scurve_data1.loc[:n_mod-1,'VC'].max()
    
    # Handling of special cases
    Max_x_all = scurve_data1.iloc[:,0].max()
    Max_y_all = scurve_data1.loc[:,'VC'].max()
    
    if Max_x_all > Max_x:
        Max_x = Max_x_all
        Max_y = Max_y_all + 0.01
    Point = pd.DataFrame({'Media':[Media_var]})  
    
    if threshold_calculator == 'gompertz' or threshold_calculator == 'average':
        print('Note: By default the exported excel file values for Threshold point calculation follows LOGISTIC calculator. In case user want to use Thresohold calculator other than Logistic, user need to update values in exported excel file manually')
        scurve_data1['x_indexed']=scurve_data1[Media_var]/Max_x
        scurve_data1['y_indexed']=scurve_data1['VC']/Max_y
        df2=scurve_data1.loc[df.shape[0]:,[Media_var,'VC','x_indexed','y_indexed']]
        b = math.exp((df2['x_indexed'][n_tot-2]*math.log(-math.log(df2['y_indexed'][n_tot-1]))-(df2['x_indexed'][n_tot-1]*math.log(-math.log(df2['y_indexed'][n_tot-2]))))/(df2['x_indexed'][n_tot-2]-df2['x_indexed'][n_tot-1]))
        c= (math.log(-math.log(df2['y_indexed'][n_tot-2])/b)/-(df2['x_indexed'][n_tot-2]))
        x = math.log(math.log(.0001)/-b)*(1/-c)
        Point['Threshold Point using Gompertz'] = x*Max_x
    
    #Calculation of Threshold Point using Logistic function
    # 4.59511985013 for 99% saturation and 2.944438979 for 95% saturation
    
    data = transformation_calc(df,Media_var,inflection,scale,coeff,percent)
    scurve_data = data[0:-2]
    
#     scurve_data['Adjusted S'] = scurve_data['scurve_term']/scurve_data['scurve_term'].max()
#     scurve_data['Slope'] = (1- scurve_data['Adjusted S']) * scurve_data['Adjusted S']
#     scurve_data['Derivative Of Slope'] = (1- scurve_data['Adjusted S']) * scurve_data['Slope'] - scurve_data['Adjusted S'] * scurve_data['Slope']
#     scurve_data['Logistic Function'] = np.log( 1 / (scurve_data['Adjusted S'] + coeff)-1) / ((scurve_data[Media_var]-(scurve_data[Media_var].mean() *inflection)))
#     scurve_data['Logistic Function'] = scurve_data['Logistic Function'].fillna(0) #if there is any error in this column, fillNA=0
    


    # 4.59511985013 for 99% saturation and 2.944438979 for 95% saturation
    if scale*inflection < 4.59511985013:
        print('Note: Threshold is set to Zero, earlier it was negative because here , scale*Inflection < 4.61')
        Point['Threshold Point using Logistic'] = 0
    else:
        Point['Threshold Point using Logistic'] = (-4.59511985013/(scale) + inflection) * scurve_data[Media_var].mean()
   
        
    if threshold_calculator == 'average':
        threshold = Point[['Threshold Point using Gompertz', 'Threshold Point using Logistic']].mean(axis= 1)
    elif threshold_calculator == 'gompertz':
        threshold = Point[['Threshold Point using Gompertz']].max(axis= 1)
    else:
        threshold = Point[['Threshold Point using Logistic']].max(axis = 1)
        
       
    return threshold.values[0]


class ModellingPlots:
    
    def __init__(self, model_obj):
        '''Function to plot response curve of media variables
        Params:
            var: Media variable
            model_label: Model Label used at time of modelling
            start_date, end_date: Dates to calculate non-zero average and CPI
        '''
        
        # Object of the modelling class (this object would have model dump data required for visualization)
        self.model_obj = model_obj
        
    def display_base_incremental(self, model_label, media_level= None, save_path= None, 
                                 n_top_channels= None,
                                 start_date= None, end_date= None):
        
        '''Function to display base vs incremental area plot. 
        No option of displaying y axis as graph has been scaled to show media variables more intuitively
        
        Params:
            model_label: label for model
            media_level: granularity of media for visualization
            n_top_channels: #top channels to be viewed
            start_date, end_date: Specify the time period for graph
        '''
        
        vol_cont = self.model_obj.model_dump[model_label]['Volume Contribution All'].copy()
        if start_date:
            vol_cont = vol_cont[(vol_cont.index >= start_date) & (vol_cont.index <= end_date)]

        
        # Summing at monthly level
        vol_cont = vol_cont.resample('MS').sum()
        
        media_col = [col for col in vol_cont if col.startswith('M_')]
        
        base_vol = vol_cont[self.model_obj.target_var] - vol_cont[media_col].sum(axis= 1)

        fig = go.Figure()

        fig.add_trace(go.Scatter(x= base_vol.index, y= base_vol.values, 
                                 fill= 'tozeroy', yaxis= 'y1', name= 'Base Volume', 
                                 mode= 'lines',
                                 line= dict(width=0.2, color= 'grey'))) 
        
        total_incremental = base_vol.values.copy()
        
        color_list = ['blue', 'orange','green', 'yellow','brown', 'red', 'violet',
                      'pink', '#FF0000', '#70AD47', '#7F6000', '#008EA8',
                     'blue', 'orange','green', 'yellow','brown', 'red', 'violet',
                      'pink', '#FF0000', '#70AD47', '#7F6000', '#008EA8']
            
        
        vol_cont = vol_cont.T
        vol_cont['Variable'] = vol_cont.index
        vol_cont = vol_cont[vol_cont.Variable.str.startswith('M_')]
        vol_cont['Variable'] = vol_cont['Variable'].apply(self.model_obj.get_var_description,
                                                          args= (media_level, ))
        vol_cont = vol_cont.groupby('Variable').sum()
        vol_cont = vol_cont.T
        
        top_ROAS = self.model_obj.calculate_ROAS(model_type= model_label, start_date= start_date, 
                                               end_date= end_date, media_level= media_level)
        
        top_ROAS = top_ROAS.sort_values(by= self.model_obj.ROAS_label, ascending= False).reset_index(drop= True)
        top_ROAS = top_ROAS.head(n_top_channels)

        vol_cont = vol_cont[top_ROAS['Display Level'].values]
        
        
                   
        for i, col in enumerate(vol_cont.columns):
            total_incremental +=  7 * vol_cont[col]  # Scaled by factor of 7 to make better visualization
            
            fig.add_trace(go.Scatter(x= vol_cont.index, y=  total_incremental, fill='tonexty', yaxis= 'y1',
                                     mode= 'lines',
                                     line= dict(width= 0.2, color= color_list[i]),
                                     name= col))
        
        fig = self.model_obj.update_layout(fig, title= "Base vs Incremental", legend_orientation= "h",
                                 show_yaxis= False, title_x= 0.5, title_y= 0.9, legend_x= 0.05, legend_y= -0.25,
                                 tickangle= 45, height= 600, width= 1200)
        
        if save_path == None:
                    fig.show()
        else:
            fig.write_image(os.path.join(save_path, "Base vs Incremental Shade Plot.png"),
                            width= 1200, height= 600, scale= 5)
        return vol_cont, base_vol
    
    def set_plot_point_position(self,inf_pt_pos,
                              sat_pt_pos, thres_pt_pos, avg_pt_pos):
        self.inf_pt_pos = inf_pt_pos
        self.sat_pt_pos = sat_pt_pos
        self.thres_pt_pos = thres_pt_pos
        self.avg_pt_pos = avg_pt_pos

    def plot_response_curve(self, var, model_label, start_date, end_date, show_xy_labels = False,
                            save_path= None, spend= True, save_excel= False,show_xyaxis_title = True,
                            saturation_calculator = 'logistic',threshold_calculator='logistic'):
        
        def calculate_y(value, scale, inflection, orig_var_mean, scurve_var_orig, coef):
            '''Function inside a function i.e. to calculate y from x'''
            
            
            transformed_var_scaled = value/orig_var_mean
            saturation_term = scale * (inflection - transformed_var_scaled)
        
            scurve_var = 1/(1+np.exp(saturation_term))-1/(1+np.exp(scale * inflection))
            scurve_var = scurve_var * orig_var_mean / scurve_var_orig.mean()
            return scurve_var * coef
        
        
        # Fetching the variable details i.e. original variable name and the corresponding transformations
        var_transf_dict = self.model_obj.get_orig_var(var)
        orig_var = var_transf_dict['Original Variable']
        scale = var_transf_dict['Scale']
        inflection = var_transf_dict['Inflection']
        lag = var_transf_dict['Lag']
        halflife = var_transf_dict['Halflife']
        
        
        # Calculation of CPI for the total time period - for Saturation, Inflection & Threshold Points
        df_cpi_tot = self.model_obj.df_train.copy()       
        total_imp = df_cpi_tot[orig_var].sum()
        total_spend = df_cpi_tot[orig_var.replace('VIEW_IMP', 'SPEND').replace('IMP', 'SPEND').replace('CLK', 'SPEND')].sum()
        cpi_tot = total_spend/total_imp
#        display(cpi_tot)        
        
        # Calculation of CPI (restricted by time period)
        ''' 
        We will avoid using this as the date imputations was to change non_zero_average point on S-curve.
        In case we want to use cpi, user need to change in Line 456 - 464
        
        ''' 
        df_cpi = self.model_obj.df[(self.model_obj.df.index >= start_date) & 
                                   (self.model_obj.df.index <= end_date)]
        total_imp = df_cpi[orig_var].sum()
        total_spend = df_cpi[orig_var.replace('VIEW_IMP', 'SPEND').replace('IMP', 'SPEND').replace('CLK', 'SPEND')].sum()
        cpi = total_spend/total_imp
#        display(cpi)        
        
        # Dataframe to plot the curve
        df_plot = self.model_obj.df_train[[orig_var]].copy()
        
        
        # Calculation of non-zero average (restricted by time period)
        df_av = self.model_obj.df[(self.model_obj.df.index >= start_date) & 
                                  (self.model_obj.df.index <= end_date)]
        df_av = df_av[orig_var].copy()
        var_period_mean = df_av[df_av != 0].mean()
        var_period_average = df_av.mean()
    
        # Preparation of plot dataframe
        df_plot.columns = ['Raw Variable']
        df_plot_temp = self.model_obj.df[[orig_var]]
        df_plot_temp.columns = ['Raw Variable']
        
        # S-Curve Transformation of the raw variable
        if lag != 0:
            df_plot['Raw Variable'] = lag_transformation(df_plot['Raw Variable'], int(lag)) 
        orig_var_mean = float(df_plot['Raw Variable'].mean())

        if halflife != 0:
            df_plot['Raw Variable'] = halflife_transformation(df_plot['Raw Variable'], halflife)
            
        transformed_var_scaled = df_plot['Raw Variable']/orig_var_mean
        saturation_term = scale * (inflection - transformed_var_scaled)
        scurve_var_orig = 1/(1+np.exp(saturation_term))-1/(1+np.exp(scale * inflection))
        scurve_var = scurve_var_orig * orig_var_mean / scurve_var_orig.mean()
        
        df_plot['S-Curve Transformed Variable'] = scurve_var
        
        model = self.model_obj.model_dump[model_label]['Model']
        coeff = model.params[var]
        df_plot['Contribution'] = df_plot['S-Curve Transformed Variable'] * coeff
        
        
        # Inflection point
        inflection_point = orig_var_mean * inflection    
        inflection_pt_sp = inflection_point * cpi_tot       
        inflection_point_y = calculate_y(inflection_point, scale, inflection, 
                                         orig_var_mean, scurve_var_orig, coeff)
        
        # Non-Zero Average
        non_zero_average = var_period_mean
        non_zero_av_sp = non_zero_average * cpi_tot
            
        non_zero_average_y = calculate_y(non_zero_average, scale, inflection,
                                         orig_var_mean, scurve_var_orig, coeff)
        
        
        # Average 
        average = var_period_average
        average_sp = average * cpi_tot
        # Saturation point
        if str(type(saturation_calculator)) == "<class 'str'>":

            saturation_point = gompertz_logistic_saturation_pts(df_plot, 'Raw Variable', 10, 
                                                                    inflection, scale, coeff, saturation_calculator)                    
        else:
       
            saturation_point = saturation_calculator
            
        saturation_pt_sp = saturation_point * cpi_tot
        saturation_point_y = calculate_y(saturation_point, scale, inflection,
                                         orig_var_mean, scurve_var_orig, coeff)
                
        # threshold point
        if str(type(threshold_calculator)) == "<class 'str'>":
     
            threshold_point = gompertz_logistic_threshold_pts(df_plot, 'Raw Variable', -5, 
                                                          inflection, scale, coeff, threshold_calculator)
        else:
            threshold_point = threshold_calculator
            
        threshold_pt_sp = threshold_point * cpi_tot
        threshold_point_y = calculate_y(threshold_point, scale, inflection,
                                         orig_var_mean, scurve_var_orig, coeff)
        
        df_on_off_air = df_plot_temp[(df_plot_temp.index >= start_date) & (df_plot_temp.index <= end_date)].copy()
        #df_on_off_air = df_on_off_air[on_air_vars]
                
        total_days = df_on_off_air.shape[0]
        on_air_df = df_on_off_air[df_on_off_air['Raw Variable'] > 0]
        on_air_days = on_air_df.shape[0]
        beyond_saturation_days = (on_air_df['Raw Variable'] > saturation_point).mean()
        
        beyond_saturation_days_count = (on_air_df['Raw Variable'] > saturation_point).sum()
        below_saturation_days_count = (on_air_df['Raw Variable'] <= saturation_point).sum()
        
        below_inflection_days = (on_air_df['Raw Variable'] <= inflection_point).mean()
        optimal_days = (1 - beyond_saturation_days - below_inflection_days)
        
        df_optimal_analysis = pd.DataFrame([[var, total_days, on_air_days, optimal_days,
                                           beyond_saturation_days, below_inflection_days,
                                           beyond_saturation_days_count, below_saturation_days_count,
                                           non_zero_average,average,threshold_point,inflection_point,saturation_point]],
                                           columns= ['Variable', 'Total Days', 'On Air Days', 
                                                     'Optimal Range Days (%)',
                                                     'Beyond Saturation Days (%)', 
                                                     'Below Inflection Days (%)',
                                                     'Days above Saturation',
                                                     'Days below Saturation',
                                                     'Actual Average Point',
                                                     'Average',
                                                     'Threshold point',
                                                     'Inflection Point',
                                                     'Saturation Point'])
        
        df_optimal_analysis_spend = pd.DataFrame([[var, total_days, on_air_days, optimal_days,
                                           beyond_saturation_days, below_inflection_days,
                                           beyond_saturation_days_count, below_saturation_days_count,
                                           non_zero_av_sp,average_sp,threshold_pt_sp,inflection_pt_sp,saturation_pt_sp]],
                                           columns= ['Variable', 'Total Days', 'On Air Days', 
                                                     'Optimal Range Days (%)',
                                                     'Beyond Saturation Days (%)', 
                                                     'Below Inflection Days (%)',
                                                     'Days above Saturation',
                                                     'Days below Saturation',
                                                     'Actual Average Point (Spend)',
                                                     'Average (Spend)',
                                                     'Threshold point (Spend)',
                                                     'Inflection Point (Spend)',
                                                     'Saturation Point (Spend)'])        
        
        
        if save_excel:
            return var, df_plot['S-Curve Transformed Variable'], saturation_point, inflection_point, df_optimal_analysis, non_zero_average, threshold_point, inflection_pt_sp, non_zero_av_sp, saturation_pt_sp, threshold_pt_sp, df_optimal_analysis_spend 
        
        for col in df_optimal_analysis.columns:
            if '%' in col:
                df_optimal_analysis[col] = 100 * df_optimal_analysis[col]
                df_optimal_analysis['Saturation Point'] = round(saturation_point, 2)
                df_optimal_analysis['Inflection Point'] = round(inflection_point, 2)
                df_optimal_analysis['Actual Average Point'] = round(non_zero_average, 2)
                df_optimal_analysis['Threshold point'] = round(threshold_point, 2)
                df_optimal_analysis['Average'] = round(average, 2)

        
        pd.options.display.float_format = '{:20,.1f}'.format
        if not save_path:
            display(df_optimal_analysis)
        pd.options.display.float_format = '{:20,.5f}'.format
        
        df_plot = df_plot.sort_values(by= 'Raw Variable').reset_index(drop= True)
        
        
        # Adding artificial points
        max_point = np.max([df_plot['Raw Variable'].max(), saturation_point, inflection_point])
        min_point = np.min([df_plot['Raw Variable'].min(), threshold_point])
        
        artificial_x = np.linspace(min_point, max_point, 50)
        
        artificial_y = [calculate_y(i, scale, inflection, orig_var_mean, scurve_var_orig, coeff)
                        for i in artificial_x]
        
        df_artificial = pd.DataFrame({'Raw Variable' : artificial_x, 'Contribution': artificial_y})
        df_artificial = pd.concat([df_plot, df_artificial], axis= 0).reset_index(drop= True)
        df_artificial = df_artificial.sort_values(by= 'Raw Variable').reset_index(drop= True)
        '''
        We are using cpi_tot all along as it is calculated on Modelling Time-frame
        
        '''
        
        if spend:
           df_plot['Raw Variable'] = df_plot['Raw Variable'] * cpi_tot
           inflection_point = inflection_point * cpi_tot
           non_zero_average = non_zero_average * cpi_tot
           saturation_point = saturation_point * cpi_tot
           threshold_point = threshold_point * cpi_tot
           average = average * cpi_tot
           df_artificial['Raw Variable'] = df_artificial['Raw Variable'] * cpi_tot
           
           for col in df_optimal_analysis_spend.columns:
            if '%' in col:
                df_optimal_analysis_spend[col] = 100 * df_optimal_analysis_spend[col]
                df_optimal_analysis_spend['Saturation Point (Spend)'] = round(saturation_pt_sp,2)
                df_optimal_analysis_spend['Inflection Point (Spend)'] = round(inflection_pt_sp, 2)
                df_optimal_analysis_spend['Actual Average Point (Spend)'] = round(non_zero_av_sp, 2)
                df_optimal_analysis_spend['Threshold point (Spend)'] = round(threshold_pt_sp, 2)
                df_optimal_analysis_spend['Average (Spend)'] = round(average_sp, 2)
           pd.options.display.float_format = '{:20,.1f}'.format
#           display("Airing Analysis for Spends")
           display(df_optimal_analysis_spend)
        
        # Actual graph plot
        line1 = go.Scatter(x=df_plot['Raw Variable'], y=df_plot['Contribution'], mode='markers',
                           connectgaps=True,
                           marker = dict(color= '#9D9FA2'),showlegend=False,
                           name= 'Actual values (adstocked)  ')
   
        line2 = go.Scatter(x=[inflection_point], y=[inflection_point_y], mode='markers',connectgaps=True, 
                           line=dict(color='#FFC220'),
                           marker= dict(size= 12), name= "Inflection Point  ")
        
        line3 = go.Scatter(x=[non_zero_average], y=[non_zero_average_y], mode='markers',connectgaps=True, 
                           line=dict(color='#414042'), 
                           marker= dict(size= 12),
                           name= "Actual Average Point  ")
        
        line4 = go.Scatter(x=[saturation_point], y=[saturation_point_y], mode='markers',connectgaps=True, 
                           line=dict(color='#0071CE'), 
                           marker= dict(size= 12),
                           name= "Saturation Point  ")
        
        line5 = go.Scatter(x=[threshold_point], y=[threshold_point_y], mode='markers',connectgaps=True, 
                           line=dict(color='red'), 
                           marker= dict(size= 12),
                           name= "Threshold Point  ")
        
        line6 = go.Scatter(x= df_artificial['Raw Variable'], y= df_artificial['Contribution'],
                           mode='lines',connectgaps=True, 
                           line=dict(color='#9D9FA2'), line_shape= 'spline', showlegend=False,
                           name= "Curve Line  " )
        
        # update the artificial_x, artificial_y when spend = True
        artificial_x = df_artificial['Raw Variable']
        artificial_y = df_artificial['Contribution']
        
        
        x_inf_pt = '{:1,.0f}'.format(inflection_point)
        y_inf_pt = '{:1,.0f}'.format(inflection_point_y) 
        inf_label = x_inf_pt + y_inf_pt  
        inf_label = "("+"Inf:"+x_inf_pt+","+"VC:"+y_inf_pt +")"                
        x_avg_pt = '{:1,.0f}'.format(non_zero_average)
        y_avg_pt = '{:1,.0f}'.format(non_zero_average_y) 
        avg_label = x_avg_pt + y_avg_pt  
        avg_label = "("+"Avg:"+x_avg_pt+","+"VC:"+y_avg_pt +")"
        x_sat_pt = '{:1,.0f}'.format(saturation_point)
        y_sat_pt = '{:1,.0f}'.format(saturation_point_y) 
        sat_label = x_sat_pt + y_sat_pt  
        sat_label = "("+"Sat:"+x_sat_pt+","+"VC:"+y_sat_pt +")"
        x_thres_pt = '{:1,.0f}'.format(threshold_point)
        y_thres_pt = '{:1,.0f}'.format(threshold_point_y) 
        thres_label = x_thres_pt + y_thres_pt  
        thres_label = "("+"Thres:"+x_thres_pt+","+"VC:"+y_thres_pt +")"

        if show_xy_labels == True:
            line2 = go.Scatter(x=[inflection_point], y=[inflection_point_y], mode='markers+text',connectgaps=True, 
                               line=dict(color='#FFC220'),text = inf_label, 
                               textposition= self.inf_pt_pos,textfont=dict(
                                       family="Bogle/Bogle Regular",
                                       size=12,
                                       color="#FFC220"),
                               marker= dict(size= 12), name= "Inflection Point  ")            

            line3 = go.Scatter(x=[non_zero_average], y=[non_zero_average_y], mode='markers+text',connectgaps=True, 
                               line=dict(color='#414042'), text =avg_label, 
                               textposition= self.avg_pt_pos,textfont=dict(
                                       family="Bogle/Bogle Regular",
                                       size=12,
                                       color="#414042"),
                               marker= dict(size= 12),
                               name= "Actual Average Point  ")

            line4 = go.Scatter(x=[saturation_point], y=[saturation_point_y], mode='markers+text',connectgaps=True, 
                               line=dict(color='#0071CE'), text = sat_label, 
                               textposition= self.sat_pt_pos,textfont=dict(
                                       family="Bogle/Bogle Regular",
                                       size=12,
                                       color="#0071CE"),
                               marker= dict(size= 12),
                               name= "Saturation Point  ")

            line5 = go.Scatter(x=[threshold_point], y=[threshold_point_y], mode='markers+text',connectgaps=True, 
                               line=dict(color='red'), text = thres_label, 
                               textposition= self.thres_pt_pos,textfont=dict(
                                       family="Bogle/Bogle Regular",
                                       size=12,
                                       color="red"),
                               marker= dict(size= 12),
                               name= "Threshold Point  ")



        
        var_name = self.model_obj.get_var_description(var)
        
        data = [line6, line1, line2, line3, line4, line5]
        fig = go.Figure(data = data)
        
        title = 'Raw Impression/Day (adstocked)'
        if 'CLK' in var:
            title = 'Raw Click/Day (adstocked)'
        if 'SPEND' in var:
            title = 'Raw Spend/Day (adstocked)'
        if 'VIEW_IMP' in var:
            title = 'Viewable Impression/Day (adstocked)'
            
        
        fig.update_layout(
            dict(xaxis = dict(title= 'Spends/Day' if spend else title, 
                              showgrid= False,
                              ticks= 'outside', mirror= False, showline= False, linecolor= 'black',
                              linewidth= 2, tickangle= 30, tickformat= ',.1f'),
                        yaxis = dict(title= 'Volume Contribution', 
                                     showgrid= False, mirror= True, ticks= 'outside', showline= False,
                                     showticklabels= True,
                                     linecolor= 'black', linewidth= 2, tickformat= ',.1f'),
                        font=dict(size= 16, family= 'Bogle/Bogle Regular'),
                        ),
            #showlegend=True,                         
            autosize= True,
            width= 1050,
            height= 600,
            paper_bgcolor= 'rgba(0,0,0,0)',
            plot_bgcolor= 'rgba(0,0,0,0)',
            title={
                'text': "Response Curve - " + str(var_name),
                'y':0.95,
                'x':0.48,
                'xanchor': 'center',
                'yanchor': 'top',
                'font': dict(size= 20, family= 'Bogle/Bogle Regular')},
            legend_orientation= "h",
            legend=dict(x= 0.05, y= -0.32, font= dict(size= 16, family= 'Bogle/Bogle Regular'))
        )
        
        if show_xyaxis_title == False:
            fig.update_layout(
            dict(xaxis = dict(showticklabels= False,title= 'Spends/Day' if spend else title, 
                              showgrid= False,
                              ticks= "", mirror= False, showline= False, linecolor= 'black',
                              linewidth= 2, tickangle= 30, tickformat= ',.1f'),
                        yaxis = dict(title= 'Volume Contribution', 
                                     showgrid= False, mirror= True, ticks= "", showline= False,
                                     showticklabels= False,
                                     linecolor= 'black', linewidth= 2, tickformat= ',.1f'),
                        font=dict(size= 16, family= 'Bogle/Bogle Regular'),
                        ),
            #showlegend=True,                         
            autosize= True,
            width= 1050,
            height= 600,
            paper_bgcolor= 'rgba(0,0,0,0)',
            plot_bgcolor= 'rgba(0,0,0,0)',
            title={
                #'text': "Response Curve - " + str(var_name),
                'y':0.95,
                'x':0.48,
                'xanchor': 'center',
                'yanchor': 'top',
                'font': dict(size= 20, family= 'Bogle/Bogle Regular')},
            legend_orientation= "h",
            legend=dict(x= 0.05, y= -0.32, font= dict(size= 16, family= 'Bogle/Bogle Regular'))
            )            



        
        if save_path == None:
            fig.show()
        else:
            fig.write_image(os.path.join(save_path, "Response curve - " + str(var_name) + ".png"),
                            width= 1050, height= 600, scale= 5)
            
        return inflection_point, inflection_point_y, non_zero_average, non_zero_average_y, saturation_point, saturation_point_y, threshold_point, threshold_point_y, df_plot, artificial_x, artificial_y
    
            
    def plot_media_on_off_analysis(self, model_label, on_air_start, on_air_end, 
                                   on_air_vars, show_yaxis= True, save_path= None):
        
        model_obj = self.model_obj
        df_tranf_op_analysis = pd.DataFrame()
        
        for var in model_obj.model_dump[model_label]['Coefficient Summary'].Variables.values:
            if var.startswith('M_'):
                var_name, transf, sat_pt, inf_pt, opt_analysis, non_zero_average, threshold_point, inf_pt_sp, non_zero_av_sp, sat_pt_sp, thres_pt_sp, opt_analysis_sp = model_obj.plot_response_curve(var, model_label,
                                                                                                                                                                                     start_date= on_air_start, 
                                                                                                                                                                                     end_date= on_air_end,
                                                                                                                                                                                     use_freezed_values= True,                    
                                                                                                                                                                                     save_excel= True,
                                                                                                                                                                                     spend= False)
    
                #opt_analysis = opt_analysis[(opt_analysis.index >= on_air_start) & (opt_analysis.index <= on_air_end)].copy()
                df_tranf_op_analysis = pd.concat([df_tranf_op_analysis, opt_analysis], axis= 0)

        
        df_tranf_op_analysis['Variable'] = df_tranf_op_analysis.Variable.apply(model_obj.get_var_description)
        
        df_tranf_op_analysis = df_tranf_op_analysis.sort_values(by= ['Days below Saturation']).reset_index(drop= True)
        if df_tranf_op_analysis.shape[0] < 6:
            width = 1050
        else:
            width = 1200
        
        # On-Air Days below or above saturation
        fig = go.Figure(data=[
            go.Bar(name='On Air Days Below Saturation      ', x= df_tranf_op_analysis.Variable.apply(model_obj.create_var_spacing), 
                   y= df_tranf_op_analysis['Days below Saturation'].values,
                   marker_color= '#0071CE',
                   width= 0.6,
                   textposition= 'inside',
                   text= df_tranf_op_analysis['Days below Saturation'].values),
            
            go.Bar(name='On Air Days Above Saturation      ', x= df_tranf_op_analysis.Variable.apply(model_obj.create_var_spacing),
                   y= df_tranf_op_analysis['Days above Saturation'].values,
                   marker_color= '#FFC220',
                   width= 0.6,
                   textposition= 'inside',
                   text= df_tranf_op_analysis['Days above Saturation'].values)
            
        ])
        fig = model_obj.update_layout(fig, title= "On Air Days: Below or Above Saturation",
                                         legend_orientation= 'h', height= 700, width= width,
                                         title_x= 0.5, title_y= 0.95, legend_x= 0.15, legend_y= -0.22, 
                                         show_yaxis= show_yaxis, tickangle= 0,
                                         label_fontsize= 12, legend_fontsize= 14, title_fontsize= 20)
        fig.update_layout(barmode = 'stack')
        
        if not save_path:
            fig.show();
        
        if save_path:
            fig.write_image(os.path.join(save_path, "On Air Days (below or above Saturation).png"),
                      scale= 5, width= width)
        
        # Average Daily
        fig = go.Figure(data=[
            go.Bar(name='Actual - Average Daily      ', x= df_tranf_op_analysis.Variable.apply(model_obj.create_var_spacing), 
                   y= df_tranf_op_analysis['Actual Average Point'].values,
                   marker_color= '#0071CE'),
            
            go.Bar(name='Saturation Point - Average Daily      ', x= df_tranf_op_analysis.Variable.apply(model_obj.create_var_spacing),
                   y= df_tranf_op_analysis['Saturation Point'].values,
                   marker_color= '#FFC220')
            
        ])
        fig = model_obj.update_layout(fig, title= "On Air Average",
                                         legend_orientation= 'h', height= 600, width= width,
                                         title_x= 0.5, title_y= 0.95, legend_x= 0.15, legend_y= -0.22, 
                                         show_yaxis= show_yaxis, tickangle= 0,
                                         label_fontsize= 12, legend_fontsize= 14, title_fontsize= 20)
        
        if not save_path:
            fig.show();
        
        if save_path:
            fig.write_image(os.path.join(save_path, "On Air Average.png"),
                      scale= 5, width= width)
        
        
        ##################################################################################################
        df_air_days = model_obj.df[(model_obj.df.index >= on_air_start) & (model_obj.df.index <= on_air_end)].copy()
        df_air_days = df_air_days[on_air_vars]
        
        df_air_analysis = pd.DataFrame(on_air_vars, columns= ['Variable'])
        df_air_analysis['Variable'] = df_air_analysis['Variable'].apply(model_obj.get_var_description)
        df_air_analysis['Total Days'] = df_air_days.shape[0]
        df_air_analysis['On Air Days'] = (df_air_days > 0).sum().values
        df_air_analysis['Off Air Days'] = df_air_analysis['Total Days'] - df_air_analysis['On Air Days'] 
        df_air_analysis = df_air_analysis.sort_values(by= 'On Air Days', ascending= False).reset_index(drop= True)
        
        df_air_analysis['On Air Days'] = 100 * df_air_analysis['On Air Days']/df_air_analysis['Total Days']
        df_air_analysis['Off Air Days'] = 100 * df_air_analysis['Off Air Days']/df_air_analysis['Total Days']
        
        fig = go.Figure(data=[
            go.Bar(name='On Air Days', y= df_air_analysis.Variable, 
                   x= df_air_analysis['On Air Days'].values,
                   marker_color= '#4372c4',
                   textposition= 'inside',
                   text= df_air_analysis['On Air Days'].apply(lambda x : round(x,0)).astype(int).astype(str) + "%",
                   orientation='h'),
            
            go.Bar(name='Off Air Days', y= df_air_analysis.Variable,
                   x= df_air_analysis['Off Air Days'].values,
                   marker_color= '#dae4f4',
                   orientation='h')
            
        ])
        fig = model_obj.update_layout(fig, title= "Media Flight",
                                         legend_orientation= 'h', height= 500, width= 1000,
                                         title_x= 0.5, title_y= 0.95, legend_x= 0.05, legend_y= -0.25, 
                                         show_yaxis= show_yaxis, tickangle= 0,
                                         label_fontsize= 14, legend_fontsize= 14, title_fontsize= 20)
        fig.update_layout(barmode='stack')
        
        if not save_path:
            fig.show();
        
        if save_path:
            fig.write_image(os.path.join(save_path, "Media Flight.png"),
                      scale= 5)



            
                
                
            
        
