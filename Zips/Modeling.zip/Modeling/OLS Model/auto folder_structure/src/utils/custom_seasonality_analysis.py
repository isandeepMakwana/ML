

# importing Libraries here
import pandas as pd
from statsmodels.tsa.seasonal import seasonal_decompose
from statsmodels.tsa.holtwinters import SimpleExpSmoothing
from statsmodels.tsa.holtwinters import ExponentialSmoothing
from save_excel import SaveExcelTemplated
from statsmodels.tsa.stattools import adfuller
from statsmodels.tsa.statespace.tools import diff
from statsmodels.tsa.arima_model import ARMA,ARMAResults,ARIMA,ARIMAResults
from custom_transformation_functions import ccurve_transformation
from statsmodels.tsa.statespace.sarimax import SARIMAX


# Load specific forecasting tools
from statsmodels.tsa.stattools import arma_order_select_ic
import statsmodels.api as sm
from pmdarima import auto_arima # for determining ARIMA orders
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
formatter = ticker.StrMethodFormatter('{x:,.0f}')


from custom_transformation_functions import find_best_var_transformation

import warnings
warnings.filterwarnings("ignore")



class VariableSeasonality:
    
    def __init__(self, df, key_variable, file_path=None, modelling_start=None, modelling_end=None,
                 validation_start= None, validiation_end= None, m= 7, exog=None):
        self.df = df
        self.key_variable = key_variable
        if file_path is not None:
            self.excel_obj = SaveExcelTemplated(file_path)
        self.modelling_start = modelling_start
        self.modelling_end = modelling_end
        self.validation_start = validation_start
        self.validiation_end = validiation_end
        self.exog = exog
        
        self.df_final_rankings = None
        self.df_transformations = None
        self.df_seasonal_decompose = None
        self.df_arma_arima = None
        
        self.m = m

    def residual_calculation(self,var,exog):
        """
        Returns residuals of var to a regression with exog
        """
        Y = var
        X = exog
        X = sm.add_constant(X)
        model = sm.OLS(Y, X, missing='drop')
        model_result = model.fit()
        outcome_residuals=model_result.resid
        return outcome_residuals

    # Implementation of Dicky Fuller Test
    def adf_test(self, series):
    
        """
        Pass in a time series and an optional title, returns an ADF report
        """
    
        print('Augmented Dickey-Fuller')
        result = adfuller(series.dropna(), autolag='AIC') # .dropna() handles differenced data
    
        labels = ['ADF  Statistic','P-Value','#Lags Used','#Observations']
        out = pd.Series(result[0:4],index=labels)
    
        for key,val in result[4].items():
            out[f'critical value ({key})']=val
    
        print(out.to_string())          # .to_string() removes the line "dtype: float64"
    
        if result[1] <= 0.05:
            print("Strong evidence against the null hypothesis")
            print("Reject the null hypothesis")
            print("Data has no unit root and is stationary")
        else:
            print("Weak evidence against the null hypothesis")
            print("Fail to reject the null hypothesis")
            print("Data has a unit root and is non-stationary")
        
        return result[1] 
    
    # To check for stationarity 
    def arma_arima_func(self, start_p, start_q, day_start= 5, day_end= 8, custom_order= None, custom_seasonal_order= None):
        if self.exog:
            df = self.residual_calculation(self.df[self.key_variable],self.df[self.exog])
            df_log = self.residual_calculation(ccurve_transformation(self.df[self.key_variable]),self.df[self.exog])
        else:
            df = self.df[self.key_variable]
            df_log = ccurve_transformation(self.df[self.key_variable])
        adf_score = self.adf_test(df)
        
        m= self.m
        if adf_score<=0.05: 
            print('Since Data is Stationary, we will be using SARIMAX and enforce stationarity') # performs ARMA when score is <=0.05
            
            
            stepwise_fit = auto_arima(df, start_p= start_p, start_q= start_q,
                                      max_p= 6, max_q= 3, m= m,
                                      d= None, 
                                      error_action= 'ignore', 
                                      suppress_warnings= True, 
                                      enforce_stationarity= True,
                                      stepwise= True)       
                        
            order = stepwise_fit.to_dict()['order']    # Best order in ARIMA
            seasonal_order = stepwise_fit.to_dict()['seasonal_order']

            if custom_order:
              order = custom_order
              
            if custom_seasonal_order:
               seasonal_order =  custom_seasonal_order
                        
            model = SARIMAX(df, order= order, seasonal_order= seasonal_order)
            results = model.fit()

            self.pred_var_name = self.key_variable + '_SARIMAX ' + str(order) + " " + str(seasonal_order)
            predictions = results.predict().rename(self.pred_var_name)  # predicting on the results

            predictions = pd.concat([df.rename(self.key_variable), 
                                     predictions], axis= 1)[self.pred_var_name].fillna(0)
    
            # Doing same for log data
            stepwise_fit_log = auto_arima(df_log, start_p= start_p, start_q= start_q,
                                      max_p= 6, max_q= 3, m= m,
                                      d= None, 
                                      error_action= 'ignore', 
                                      suppress_warnings= True, 
                                      enforce_stationarity= True,
                                      stepwise= True)       
                        
            order_log = stepwise_fit_log.to_dict()['order']
            seasonal_order_log = stepwise_fit_log.to_dict()['seasonal_order']
                        
            model_log = SARIMAX(df_log, order= order_log, seasonal_order= seasonal_order_log)
            results_log = model_log.fit()
            
            self.pred_var_name_log = self.key_variable + '_SARIMAX_LOG ' + str(order_log) + " " + str(seasonal_order_log)
            predictions_log = results_log.predict().rename(self.pred_var_name_log)  # predicting on the results

            predictions_log = pd.concat([df_log.rename(self.key_variable), 
                                         predictions_log], axis= 1)[self.pred_var_name_log].fillna(0)
    
        else:
            print("Data is non-stationary, so we will be doing SARIMAX") #performs ARIMA when score >0.05
            stepwise_fit = auto_arima(df, start_p= start_p, start_q= start_q,
                                      max_p= 6, max_q= 3, m= m,
                                      d= None, 
                                      error_action= 'ignore', 
                                      suppress_warnings= True,  
                                      stepwise= True)       
                        
            order = stepwise_fit.to_dict()['order']    # Best order in ARIMA
            seasonal_order = stepwise_fit.to_dict()['seasonal_order']
            
            if custom_order:
              order = custom_order
              
            if custom_seasonal_order:
               seasonal_order =  custom_seasonal_order
                
            model = SARIMAX(df, order= order, seasonal_order= seasonal_order)    # taking the minimum order given by ARIMA
            results = model.fit()
            
            results.summary()
            
            self.pred_var_name = self.key_variable + '_SARIMAX ' + str(order) + " " + str(seasonal_order)
            
            #Creating predictions by ARIMA on historical data to create AR_var
            predictions = results.predict(dynamic=False, typ='levels').rename(self.pred_var_name) 
            
            predictions = pd.concat([df.rename(self.key_variable), 
                                     predictions], axis= 1)[self.pred_var_name].fillna(0)
            
    
            # Similar for log    
            stepwise_fit_log = auto_arima(df_log, start_p= start_p, start_q= start_q,
                                          max_p= 6, max_q= 3, m= m,
                                          d= None, 
                                          error_action= 'ignore',   
                                          suppress_warnings= True,  
                                          stepwise= True)       
                        
            order_log = stepwise_fit_log.to_dict()['order']    # Best order in ARIMA
            seasonal_order_log = stepwise_fit_log.to_dict()['seasonal_order']
            
            model_log = SARIMAX(df_log, order= order_log, seasonal_order= seasonal_order_log)    # taking the minimum order given by ARIMA
            results_log = model_log.fit()
                        
            self.pred_var_name_log = self.key_variable + '_SARIMAX_LOG ' + str(order_log) + " " + str(seasonal_order_log)
            
            #Creating predictions by ARIMA on historical data to create AR_var
            predictions_log = results_log.predict(dynamic=False, typ='levels').rename(self.pred_var_name_log) 
            
            predictions_log = pd.concat([df_log.rename(self.key_variable), 
                                         predictions_log], axis= 1)[self.pred_var_name_log].fillna(0)
                
        self.df[self.pred_var_name] = predictions.values
        self.df[self.pred_var_name_log] = predictions_log.values
        
        # Plot predictions against known values
        ylabel= self.key_variable+' residuals'
        ax = df.plot(legend=True,figsize=(15,10),title='')
        predictions.plot(legend=True)
        ax.autoscale(axis='x',tight=True)
        ax.set(ylabel=ylabel)
        ax.yaxis.set_major_formatter(formatter);
        
        self.seasonal_terms = []
        for day in range(day_start, day_end + 1):
            df.index.freq = 'D'
            day_str = str(day)
            span = day
            alpha = 2/(span+1)
                        
            # Seasonal Moving Average Calculation - SMA
            self.df[self.key_variable + '_SMA_DAY_' + day_str] = df.rolling(window= day, min_periods= 1).mean().shift(1).fillna(df)
            self.seasonal_terms.append(self.key_variable + '_SMA_DAY_' + day_str)
            
            # # Exponential Weighted Average Calculation - EWMA
            # self.df[self.key_variable + '_EWMA_DAY_' + day_str] = df.ewm(span=day, adjust=False).mean().shift(1).fillna(df)
            # self.seasonal_terms.append(self.key_variable + '_EWMA_DAY_' + day_str)
            
            # # Simple Exponential Smoothing Calculation - SES
            # self.df[self.key_variable + '_SES_DAY_' + day_str]=SimpleExpSmoothing(df).fit(smoothing_level=alpha,
            #                                                           optimized=False).fittedvalues.fillna(df)
                                          
            # self.seasonal_terms.append(self.key_variable + '_SES_DAY_' + day_str)
                                        
            # # Double Exponential Smoothing Calculation - DES
            # self.df[self.key_variable + '_DES_ADD_DAY_' + day_str] = ExponentialSmoothing(df, trend='add').fit().fittedvalues.fillna(df)
            # self.seasonal_terms.append(self.key_variable + '_DES_ADD_DAY_' + day_str)
            
            
            # self.df[self.key_variable + '_DES_MUL_DAY_' + day_str] = ExponentialSmoothing(df, trend='mul').fit().fittedvalues.fillna(df)
            # self.seasonal_terms.append(self.key_variable + '_DES_MUL_DAY_' + day_str)
            
            # # Triple Exponential Smoothing Calculation - TES
            # self.df[self.key_variable + '_TES_ADD_DAY_' + day_str] = ExponentialSmoothing(df, trend='add',
            #                                                                               seasonal='add', seasonal_periods=12).fit().fittedvalues.fillna(df)
            # self.seasonal_terms.append(self.key_variable + '_TES_ADD_DAY_' + day_str)
            
            # self.df[self.key_variable + '_TES_MUL_DAY_' + day_str ] = ExponentialSmoothing(df, trend='mul',
            #                                                                                seasonal='mul',seasonal_periods=12).fit().fittedvalues.fillna(df)
            # self.seasonal_terms.append(self.key_variable + '_TES_MUL_DAY_' + day_str)
    
    
    #To create the dataframe for all the variables in a given range
    def creating_var_func(self, additional_period_start_date= None):
        if self.exog:
            df = self.residual_calculation(self.df[self.key_variable],self.df[self.exog])
        else:
            df = self.df[self.key_variable]
        
        if additional_period_start_date is not None:
            df_filtered_1 = self.df[(self.df.index < additional_period_start_date)].copy()
            df_filtered_2 = self.df[(self.df.index >= additional_period_start_date)].copy()
            
            if self.exog:
                df = self.residual_calculation(df_filtered_1[self.key_variable],df_filtered_1[self.exog])
                df_added = self.residual_calculation(df_filtered_2[self.key_variable],df_filtered_2[self.exog])
            else:
                df = df_filtered_1[self.key_variable]
                df_added = df_filtered_2[self.key_variable]

            df_added.index.freq = 'D'   
            
        df.index.freq = 'D'    
        
        result = seasonal_decompose(df, model='additive')  # model='mul' also works
        result.plot();
    
        
        df_seasonal_decompose = pd.concat([pd.DataFrame(result.seasonal),
                                           pd.DataFrame(result.trend),
                                           pd.DataFrame(result.resid)], axis=1).reset_index().fillna(0)

        df_seasonal_decompose.columns = ['Date', 'SEASONALITY', 'TREND', 'RESIDUAL']
        
        if additional_period_start_date is not None:
            result_added = seasonal_decompose(df_added, model='additive')
            df_seasonal_decompose_added = pd.concat([pd.DataFrame(result_added.seasonal),
                                                   pd.DataFrame(result_added.trend),
                                                   pd.DataFrame(result_added.resid)], axis=1).reset_index().fillna(0)
            df_seasonal_decompose_added.columns = ['Date', 'SEASONALITY', 'TREND', 'RESIDUAL']
            
            df_seasonal_decompose = pd.concat([df_seasonal_decompose, df_seasonal_decompose_added], axis= 0).reset_index(drop= False)
            
        
        # Creating similar transformations after applying log transformation on the target variable
        if self.exog:
            df_log = self.residual_calculation(ccurve_transformation(self.df[self.key_variable]),self.df[self.exog])
        else:
            df_log = ccurve_transformation(self.df[self.key_variable])
        
        if additional_period_start_date is not None:
            df_filtered_1 = self.df[(self.df.index < additional_period_start_date)].copy()
            df_filtered_2 = self.df[(self.df.index >= additional_period_start_date)].copy()
            
            if self.exog:
                df_log = self.residual_calculation(ccurve_transformation(df_filtered_1[self.key_variable]),df_filtered_1[self.exog]) 
                df_added_log = self.residual_calculation(ccurve_transformation(df_filtered_2[self.key_variable]),df_filtered_2[self.exog]) 
            else:
                df_log = ccurve_transformation(df_filtered_1[self.key_variable]) 
                df_added_log = ccurve_transformation(df_filtered_2[self.key_variable])

            df_added_log.index.freq = 'D'   
            
        df_log.index.freq = 'D' 
        result_log = seasonal_decompose(df_log, model= 'additive')
        
        df_seasonal_decompose_log = pd.concat([pd.DataFrame(result_log.seasonal),
                                               pd.DataFrame(result_log.trend),
                                               pd.DataFrame(result_log.resid)], axis=1).reset_index().fillna(0)

        df_seasonal_decompose_log.columns = ['Date', 'SEASONALITY_LOG', 'TREND_LOG', 'RESIDUAL_LOG']
        
        if additional_period_start_date is not None:
            result_added_log = seasonal_decompose(df_added_log, model='additive')
            df_seasonal_decompose_added_log = pd.concat([pd.DataFrame(result_added_log.seasonal),
                                                       pd.DataFrame(result_added_log.trend),
                                                       pd.DataFrame(result_added_log.resid)], axis=1).reset_index().fillna(0)
            df_seasonal_decompose_added_log.columns = ['Date', 'SEASONALITY_LOG', 'TREND_LOG', 'RESIDUAL_LOG']
            
            df_seasonal_decompose_log = pd.concat([df_seasonal_decompose_log, 
                                               df_seasonal_decompose_added_log], axis= 0).reset_index(drop= False)
            
        
        self.df[self.key_variable + '_SEASONALITY'] = df_seasonal_decompose['SEASONALITY'].values
        self.df[self.key_variable + '_TREND'] = df_seasonal_decompose['TREND'].values
        self.df[self.key_variable + '_RESIDUAL'] = df_seasonal_decompose['RESIDUAL'].values
        
        # Adding log terms
        self.df[self.key_variable + '_SEASONALITY_LOG'] = df_seasonal_decompose_log['SEASONALITY_LOG'].values
        self.df[self.key_variable + '_TREND_LOG'] = df_seasonal_decompose_log['TREND_LOG'].values
        self.df[self.key_variable + '_RESIDUAL_LOG'] = df_seasonal_decompose_log['RESIDUAL_LOG'].values
        
        
    def ranking_func(self, decimal_col_names, scientific_col_names, decimal_5_col_names):    
        
        df_model = self.df[(self.df.index >= self.modelling_start) & (self.df.index <= self.modelling_end)]
        
        df_trans = df_model[[self.pred_var_name, self.key_variable + '_SEASONALITY', self.key_variable + '_TREND',
                             self.key_variable + '_RESIDUAL']]
        
        df_trans_all = df_model[[self.pred_var_name, self.key_variable + '_SEASONALITY', self.key_variable + '_TREND',
                             self.key_variable + '_RESIDUAL'] + self.seasonal_terms]
        
        if self.exog:
            ranked_output = find_best_var_transformation(target_var_series= self.residual_calculation(df_model[self.key_variable],df_model[self.exog]),
                                                     var_transformations= df_trans)
        
            ranked_output_all = find_best_var_transformation(target_var_series= self.residual_calculation(df_model[self.key_variable],df_model[self.exog]),
                                                         var_transformations= df_trans_all)
        else:
            ranked_output = find_best_var_transformation(target_var_series= df_model[self.key_variable],
                                                     var_transformations= df_trans)
        
            ranked_output_all = find_best_var_transformation(target_var_series= df_model[self.key_variable],
                                                         var_transformations= df_trans_all)            
    
        df_trans = df_trans.reset_index()
        df_trans['index'] = df_trans['index'].astype(str)
        
        self.excel_obj.add_worksheet(df_trans, 'Variable Transformation',
                                     decimal_col_names= [col for col in df_trans.columns if col != 'index'])
        
        self.excel_obj.add_worksheet(ranked_output, 'Ranks Outcome',
                                     decimal_col_names= decimal_col_names,
                                     decimal_5_col_names = decimal_5_col_names,
                                     scientific_col_names= scientific_col_names)
        
        self.excel_obj.add_worksheet(ranked_output_all, 'Ranks Outcome All',
                                     decimal_col_names= decimal_col_names,
                                     decimal_5_col_names = decimal_5_col_names,
                                     scientific_col_names= scientific_col_names)
        
        self.excel_obj.save_worksheet()
        return ranked_output