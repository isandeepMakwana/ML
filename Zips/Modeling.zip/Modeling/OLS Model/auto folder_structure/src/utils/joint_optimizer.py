import pandas as pd
import numpy as np
import statsmodels.tsa.filters.filtertools
import statsmodels.api as sm
import math
import re
import glob
import os
import sys
module_path = os.path.abspath(os.path.join('../../src/utils'))
if module_path not in sys.path:
    sys.path.append(module_path)

from scipy.optimize import differential_evolution, NonlinearConstraint, LinearConstraint
from scipy.optimize import minimize
from datetime import datetime
from save_excel import SaveExcelTemplated
import warnings
warnings.filterwarnings('ignore')

from custom_transformation_functions import adstock_transformation 
from dataclasses import dataclass, field
from typing import List

# each of the variable (media driver) used in the model has the below attributes
@dataclass
class ModelVariable:
    
    # the model results attributes for each variable
    model_var: str = ''
    spend_var: str = ''
    rate_var: str = ''
    converted_var: str = ''
    model_var_full: str = ''
    var_source: str = ''
    var_comps: List[float] = field(default_factory=list)
    var_head: str = '' 
        
    # the coeff and transformation values for each variable 
    var_coef: float = 0
    lag: int = 0
    halflife: int = 0
    inflection: float = 0
    scale: float = 0
    log: int = 0
    
    # means after transformation
    var_mean: float = 0 # var_mean
    s_curve_var_mean: float = 0 # for s_curve transformation
    k_scalar: float = 0 # for c_curve transformation
    
    # about the optimization 
    var_spend_sum: float = 0 # the spend sum of the variable    
    media_budget_range: List[float] = field(default_factory=list) # the budget limits for each variable
    media_multiplier_idx: int = 999

# each of the model used in the model has the below attributes       
@dataclass
class ModelData:
    
    model_type: str = ''
    final_model_path: str = ''
    granular_media_dict: dict = field(default_factory=dict)
    inc_contribution: float = 0
    max_lift: float = 0
    opt_var_ls: list = field(default_factory=list)
    media_spend_sum_before: float = 0
    opt: float = 0 # the optimized value : total_contribution/inc_contribution
    apply_adstock: bool = False
    model_var_dict: ModelVariable = ModelVariable()
    
class Optimizer:
    
    def __init__(self,
                df,
                forward_opt,
                forward_opt_model_weight,
                transformation_method,
                opt_start_end_date,
                modeling_start_end_date,
                perc,
                media_range_dict,
                final_model_path_1,
                final_model_path_2,
                granular_media_dict_1,
                granular_media_dict_2,
                inc_contribution_1,
                inc_contribution_2,
                max_lift_1,
                max_lift_2,
                apply_adstock = False,
                ):
        
        self.df = df
        self.forward_opt = forward_opt
        self.forward_opt_model_weight = forward_opt_model_weight
        self.transformation_method = transformation_method
        self.DEFAULT_K_CONSTANT = 0.2
        # reformat the optimization start and end dates
        self.opt_start_date_str, self.opt_end_date_str = opt_start_end_date
        self.opt_start_date = pd.to_datetime(self.opt_start_date_str)
        self.opt_end_date = pd.to_datetime(self.opt_end_date_str)
        
        # reformat the transformation start and end dates
        self.modeling_start_date_str, self.modeling_end_date_str = modeling_start_end_date
        self.modeling_start_date = pd.to_datetime(self.modeling_start_date_str)
        self.modeling_end_date = pd.to_datetime(self.modeling_end_date_str)
        
        self.perc = perc
        self.media_range_dict = media_range_dict
        
        self.final_model_path_1 = final_model_path_1
        self.final_model_path_2 = final_model_path_2
        
        self.granular_media_dict_1 = granular_media_dict_1
        self.granular_media_dict_2 = granular_media_dict_2
        
        self.inc_contribution_1 = inc_contribution_1
        self.inc_contribution_2 = inc_contribution_2
        
        self.max_lift_1 = max_lift_1
        self.max_lift_2 = max_lift_2
        self.apply_adstock = apply_adstock

        # update the self.df to the combined_df, simulated from two models if forward_opt = True 
        self.update_df()
        # get the index of the optimization start, end dates from the df
        self.opt_start_row = self.df.index.get_loc(self.opt_start_date)
        self.opt_end_row = self.df.index.get_loc(self.opt_end_date)
        
        # initiate the multipliers for each media driver
        self.x0 = [1] * len(self.media_range_dict)
        # init the dataframes for the optimization and transformation
        self.custom_df, self.trans_df = self.initiate_custom_trans_dataframes()
        # initiate the model_var_dict, which includes the attributes for all variables in the modeling
        self.model_var_dict_1 = {}
        self.model_var_dict_2 = {}
        
        # create the folder to export all the optimization results
        self.result_folder = self.create_results_folder()
        self.create_optimization_log()
        
        # construct and update the dict to save all the data for each model
        self.OPTIMIZATION_DICT = self.construct_model_data_dict()
        for model_type, model_data in self.OPTIMIZATION_DICT.items():
            self.update_model_data_dict(model_data)
        
        # display the dataframe including the historical attributes for each variable for reference
        self.display_historical_reference_dataframe()
        
        self.bnds = [tuple(self.media_range_dict[var]) for var in self.media_range_dict]
        # get the constraints for the optimization
        self.cons = {'type' : 'ineq', 'fun' : self.media_sum_before_after}
    
    def construct_model_data_dict(self):
        model_data_dict = {}
        # data for model_1
        model_data_obj = ModelData()
        model_data_obj.final_model_path = self.final_model_path_1
        model_data_obj.model_type = Optimizer.get_model_type(self.final_model_path_1)
        model_data_obj.granular_media_dict = self.granular_media_dict_1
        model_data_obj.inc_contribution = self.inc_contribution_1
        model_data_obj.max_lift = self.max_lift_1
        model_data_obj.model_var_dict = self.model_var_dict_1
        model_data_obj.apply_adstock = self.apply_adstock
        model_data_dict['1'] = model_data_obj
        # data for model_2
        model_data_obj = ModelData()
        model_data_obj.final_model_path = self.final_model_path_2
        model_data_obj.model_type = Optimizer.get_model_type(self.final_model_path_2)
        model_data_obj.granular_media_dict = self.granular_media_dict_2
        model_data_obj.inc_contribution = self.inc_contribution_2
        model_data_obj.max_lift = self.max_lift_2
        model_data_obj.model_var_dict = self.model_var_dict_2
        model_data_obj.apply_adstock = self.apply_adstock
        model_data_dict['2'] = model_data_obj
        return model_data_dict
        
    def update_model_data_dict(self, model_data):
        model_results_df = self.get_model_result_df(model_data)
        self.update_model_result_variables(model_results_df, model_data)
        self.update_inc_contribution(model_data)
        self.update_granular_media_variables(model_data)
        model_data.opt_var_ls = self.get_opt_variable_ls(model_data)
        self.update_variable_transformation_values(model_data)
        model_data.media_spend_sum_before =  sum([model_data.model_var_dict[var].var_spend_sum for var in model_data.opt_var_ls]) * self.perc
     
    def get_per_model_simulated_dataframe(self, final_model_path):
        model_type = Optimizer.get_model_type(final_model_path)
        simulation_folder = final_model_path.rsplit('/', 2)[0]
        simulation_path = os.path.join(simulation_folder, 'simulation_results', 'Updated_Stack_df.csv') 
        if os.path.isfile(simulation_path):
            simulation_df = pd.read_csv(simulation_path)
            return simulation_df
        else:
            raise NameError('Future dataframe for {} model is not available, please run simulator first!'.format(model_type))
    
    def get_simulated_var_ls(self):
        model_results_df = pd.read_excel(self.final_model_path_1)['Variable Actual'].values
        model_results_var_ls = [var.rsplit('_', 5)[0] for var in model_results_df if var.startswith('M_')]
        
        model_var_ls = [var for var in model_results_var_ls if Optimizer.get_spend_var(var) in self.media_range_dict]
        spend_var_ls = [Optimizer.get_spend_var(var) for var in model_var_ls]

        if len(spend_var_ls) != len(self.media_range_dict):
            print('\nWARNING! The variables from media_range_dict are not the same with those from model results!')
        simulated_var_ls = model_var_ls + spend_var_ls
        return simulated_var_ls
    
    def update_df(self):
        simulated_var_ls = self.get_simulated_var_ls()
        if self.forward_opt:
            print('Forward optimization is in use!')
            df_1 = self.get_per_model_simulated_dataframe(self.final_model_path_1) # TODO: for testing
            df_2 = self.get_per_model_simulated_dataframe(self.final_model_path_2)
            combined_df = df_1.copy()
            for col in simulated_var_ls:
                combined_df[col] = df_1[col] * self.forward_opt_model_weight[0] + df_2[col] * self.forward_opt_model_weight[1]
            combined_df['index'] = pd.to_datetime(combined_df['index']) 
            combined_df.set_index("index", inplace = True, drop= False)
            self.df = combined_df
        else:
            print('Backward optimization is in use!')
            
    @staticmethod
    def parse_var_str(var_str):
        model_var_obj = ModelVariable()
        model_var_obj.model_var = var_str
        pattern = re.match(r"(.*?)_[0-9.]*_[0-9.]*_[0-9.]*_[0-9.]*_[0-9.]", var_str)
        if pattern:
            model_var_obj.model_var = pattern.group(1)
            model_var_obj.spend_var = Optimizer.get_spend_var(model_var_obj.model_var)
            model_var_obj.lag = int(var_str.split("_")[-5])
            model_var_obj.halflife = int(var_str.split("_")[-4])
            model_var_obj.inflection = float(var_str.split("_")[-3])
            model_var_obj.scale = float(var_str.split("_")[-2])
            model_var_obj.log = int(var_str.split("_")[-1])   
        return model_var_obj

    @staticmethod
    def get_spend_var(var):
        spend_var = ''
        if var.startswith('M_') and (var.rsplit('_', 1)[-1].upper() != 'SPEND'):
            spend_var = var.replace('VIEW_IMP', 'SPEND')
            spend_var = spend_var.replace('CLK', 'SPEND')
            spend_var = spend_var.replace('IMP', 'SPEND')
        return spend_var
    
    @staticmethod
    def get_rate_var(var):
        rate_var = ''
        if var.startswith('M_'):
            if var.rsplit('_', 1)[-1].upper() == 'IMP':
                rate_var = 'RATE_' + '_'.join(var.split('_')[1:-1])
            elif var.rsplit('_', 1)[-1].upper() == 'CLK':
                rate_var = 'RATE_' + '_'.join(var.split('_')[1:])
        return rate_var
    
    @staticmethod
    def get_converted_var(spend_var):
        converted_var = ''
        return spend_var.replace('_SPEND', '_CONVERTED')

    @staticmethod
    def lag_transformation(var, lag = 1):
        lag_variable = var.shift(lag)
        lag_variable = lag_variable.fillna(0)
        return lag_variable

    @staticmethod
    def halflife_transformation(var, halflife = 1):
        retention = np.exp(math.log(0.5)/halflife)        
        transformed_var = var * (1 - retention)
        transformed_var = transformed_var.fillna(0)
        transformed_var = statsmodels.tsa.filters.filtertools.recursive_filter(transformed_var, retention)
        return transformed_var
    
    @staticmethod
    def s_curve_transformation(non_transformed_var_mean, transformed_var, scale = 1, inflection = 1):
        transformed_var_scaled = transformed_var/non_transformed_var_mean
        saturation_term = scale * (inflection - transformed_var_scaled)
        scurve_var = 1/(1+np.exp(saturation_term))-1/(1+np.exp(scale * inflection))
        s_curve_var_mean = scurve_var.mean()
        return s_curve_var_mean
    
    def get_k_scalar(self, var_mean, var):
        # get the k_scalar required for the c_curve transformation
        k_scalar = (max(var) * self.DEFAULT_K_CONSTANT)/var_mean
        return k_scalar
        
    @staticmethod
    def c_curve_transformation(var_mean, k_scalar, var):
        transformed_var =  np.log(var/(k_scalar * var_mean) + 1)
        return transformed_var
    
    @staticmethod
    def get_model_type(final_model_path):
        if 'sale' in final_model_path.lower():
            model_type = 'UNIT_SALES'
        elif 'customer' in final_model_path.lower():
            model_type = 'NEW_CUSTOMER'
        else:
            model_type = 'New Model Type'
        return model_type
            
    def update_inc_contribution(self, model_data):
        inc_contribution = model_data.inc_contribution
        model_type = model_data.model_type
        if not inc_contribution:
            model_folder = model_data.final_model_path.rsplit('/', 2)[0]
            model_path = os.path.join(model_folder, 'WMC_{}_{}.csv'.format(self.opt_start_date_str, self.opt_end_date_str))
            if os.path.isfile(model_path):
                model_result_df = pd.read_csv(model_path)
                model_data.inc_contribution = int(model_result_df[model_result_df['Display Level'] == 'Total Incremental']['Total Contribution'].values[0].replace(',', ''))
                print('\ninc_contribution for {} model is read from model_obj.visualize_ROAS with period between {} and {}: {}, please overwrite if necessary!'.format(model_type, self.opt_start_date_str, self.opt_end_date_str, model_data.inc_contribution))
            else:
                raise NameError('\nThe inc_contribution for {} model is not available!'.format(model_type))
            
    def check_max_lift(self):
        max_lift_ls = [self.OPTIMIZATION_DICT[model_type].max_lift for model_type in self.OPTIMIZATION_DICT]
        result = all(value is not None for value in max_lift_ls)
        if not result:
            raise NameError('The max_lift values are required when goal_opt = True!')
        return result
    
    # get the dataframe for the model results including the variable coefficients
    def get_model_result_df(self, model_data):
        final_model_path = model_data.final_model_path
        try:    
            model_results_df = pd.read_excel(final_model_path)[['Variable Actual', 'Coefficient']]
        except:
            model_results_df = pd.read_excel("\\\\?\\"+os.path.abspath(final_model_path))[['Variable Actual', 'Coefficient']]
        model_results_df = model_results_df[model_results_df['Variable Actual'].str.startswith('M_')].reset_index(drop= True)
        model_results_df = model_results_df.reset_index(drop= True)
        return model_results_df
    
    def get_media_budget_range(self, spend_var):
        if spend_var in self.media_range_dict:
            media_budget_range = self.media_range_dict[spend_var]
            return media_budget_range
            
    def get_var_spend_sum(self, spend_var):
        if spend_var in self.custom_df.columns.str.upper():
            return self.custom_df[spend_var].sum()
                   
    def get_media_multiplier_idx(self, spend_var):
        if spend_var in self.media_range_dict:
            idx = list(self.media_range_dict).index(spend_var)
            return idx + 1
        
    # get the variables need to be optimized
    def get_opt_variable_ls(self, model_data):
        model_var_dict = model_data.model_var_dict
        opt_var_ls = [var for var in model_var_dict if model_var_dict[var].var_source == 'model']
        return opt_var_ls
    
    def create_results_folder(self):
        folder = os.path.abspath(os.path.join('./', 'jointOpt_results'))
        if not os.path.isdir(folder):
            os.mkdir(folder)
        subdirs = [os.path.join(folder, o) for o in os.listdir(folder) if os.path.isdir(os.path.join(folder,o))]
        if not subdirs:
            result_folder = os.path.abspath(os.path.join(folder, 'jointOpt_outputs_v1'))
        else:
            max_version = [int(folder_name.split('_')[-1].replace('v', '')) for folder_name in subdirs]
            max_version = 'jointOpt_outputs_v' + str(list(set(max_version))[-1] + 1)
            result_folder = os.path.abspath(os.path.join(folder, max_version))
        result_folder = os.path.abspath(result_folder)
        if not os.path.isdir(result_folder):
            os.mkdir(result_folder)
        return result_folder
    
    # create the dataframe for the joint optimization duration, start date, end_date
    def create_optimization_log(self):
        optimization_log_df = pd.DataFrame({'optimization_start_date':[self.opt_start_date_str], 
                                            'optimization_end_date':[self.opt_end_date_str],
                                             'transformation_start_date': [self.modeling_start_date_str],
                                             'transformation_end_date': [self.modeling_end_date_str],
                                             'transformation_apply_adstock': [self.apply_adstock]
                                             }, index = [0])
        result_folder = self.result_folder
        if not os.path.isdir(result_folder):
            os.mkdir(result_folder)
        excel_obj = SaveExcelTemplated(os.path.join(result_folder, "jointOpt_Log.xlsx"))   
        excel_obj.add_worksheet(optimization_log_df, 'jointOpt Log', decimal_5_col_names= optimization_log_df.columns)
        excel_obj.save_worksheet()
        
    def initiate_custom_trans_dataframes(self):
        custom_df = self.df[((self.df['index'] >= self.opt_start_date) & (self.df['index'] <= self.opt_end_date))]
        trans_df = self.df[((self.df['index'] >= self.modeling_start_date) & (self.df['index'] <= self.modeling_end_date))]
        return custom_df, trans_df
    
    # update the dict of all variable attributes from model_results_df
    def update_model_result_variables(self, model_results_df, model_data):
        model_var_dict = model_data.model_var_dict
        for var_str in model_results_df['Variable Actual'].values:
            model_var_obj = Optimizer.parse_var_str(var_str)
            model_var = model_var_obj.model_var
            if model_var not in model_var_dict:
                model_var_dict[model_var] = model_var_obj
            spend_var = model_var_dict[model_var].spend_var
            model_var_dict[model_var].var_coef = model_results_df[model_results_df['Variable Actual'] == var_str]['Coefficient'].values[0]
            model_var_dict[model_var].model_var_full = var_str
            model_var_dict[model_var].rate_var = Optimizer.get_rate_var(model_var)
            model_var_dict[model_var].var_source = 'model'
            model_var_dict[model_var].media_budget_range = self.get_media_budget_range(spend_var)
            model_var_dict[model_var].var_spend_sum = self.get_var_spend_sum(spend_var)
            model_var_dict[model_var].media_multiplier_idx = self.get_media_multiplier_idx(spend_var)
     
    # update the dict of all variables from the granular_media_dict
    def update_granular_media_variables(self, model_data):
        model_var_dict = model_data.model_var_dict
        granular_media_dict = model_data.granular_media_dict
        for var in granular_media_dict:
            var_comps = granular_media_dict[var]
            for comp in var_comps:
                if comp not in model_var_dict:
                    model_var_obj = ModelVariable()
                    model_var_obj.model_var = comp
                    model_var_obj.rate_var = Optimizer.get_rate_var(comp)
                    spend_var = Optimizer.get_spend_var(comp)
                    model_var_obj.spend_var = spend_var
                    model_var_obj.converted_var = Optimizer.get_converted_var(spend_var)
                    model_var_obj.var_source = 'singular'
                    model_var_obj.media_budget_range = self.get_media_budget_range(spend_var)
                    model_var_obj.var_spend_sum = self.get_var_spend_sum(spend_var)
                    model_var_obj.media_multiplier_idx = self.get_media_multiplier_idx(spend_var)
                    model_var_dict[comp] = model_var_obj
                model_var_dict[comp].var_head = var
            if var not in model_var_dict:
                model_var_obj = ModelVariable()
                model_var_obj.model_var = var
                model_var_obj.rate_var = Optimizer.get_rate_var(var)
                spend_var = Optimizer.get_spend_var(var)
                model_var_obj.spend_var = spend_var
                model_var_obj.converted_var = Optimizer.get_converted_var(spend_var)
                model_var_obj.media_budget_range = self.get_media_budget_range(spend_var)
                model_var_obj.var_spend_sum = sum([model_var_dict[comp].var_spend_sum for comp in var_comps])
                model_var_obj.media_multiplier_idx = self.get_media_multiplier_idx(spend_var)
                model_var_dict[var] = model_var_obj  
            model_var_dict[var].var_comps = var_comps
   
    # update var_mean, s_curve_var_mean for variables from model_results_df
    def update_variable_transformation_values(self, model_data):
        model_var_dict = model_data.model_var_dict
        opt_var_ls = model_data.opt_var_ls
        
        for var in opt_var_ls:
            lag = model_var_dict[var].lag
            halflife = model_var_dict[var].halflife
            scale = model_var_dict[var].scale
            inflection = model_var_dict[var].inflection
            var_comps = model_var_dict[var].var_comps
            # if the variable is a combined var, it has var_comps
            if var_comps:
                transformed_var_orig = 0
                for comp in var_comps:
                    term = self.trans_df[model_var_dict[comp].spend_var]/self.trans_df[model_var_dict[comp].rate_var]
                    term = term.fillna(0)
                    transformed_var_orig += term
            # if the variable is a singular variable from model_output_result
            else:
                transformed_var_orig = self.trans_df[model_var_dict[var].spend_var]/self.trans_df[model_var_dict[var].rate_var]
                transformed_var_orig = transformed_var_orig.fillna(0)
                  
            var_mean = transformed_var_orig.mean()
            model_var_dict[var].var_mean = var_mean

            if (self.apply_adstock):
                if (lag>0.0) or (halflife > 0.0):
                    transformed_var_orig = adstock_transformation(transformed_var_orig, float(lag), float(halflife)))

            else:
                if lag != 0:
                    transformed_var_orig = Optimizer.lag_transformation(transformed_var_orig, int(lag))
                    var_mean = transformed_var_orig.mean()
                    model_var_dict[var].var_mean = var_mean

                if halflife != 0:
                    transformed_var_orig = Optimizer.halflife_transformation(transformed_var_orig, halflife)
                
            if self.transformation_method.upper() == 'S_CURVE':
                if (scale != 0) and (inflection != 0):
                    s_curve_var_mean = Optimizer.s_curve_transformation(var_mean, transformed_var_orig, scale, inflection)
                    model_var_dict[var].s_curve_var_mean = s_curve_var_mean
                    
            elif self.transformation_method.upper() == 'C_CURVE':
                k_scalar = self.get_k_scalar(var_mean, transformed_var_orig)
                model_var_dict[var].k_scalar = k_scalar
                
    def media_sum_before_after(self, x):
        sum_after = 0
        model_data = self.OPTIMIZATION_DICT['1']
        media_spend_sum_before = model_data.media_spend_sum_before
        model_var_dict = model_data.model_var_dict
        opt_var_ls = model_data.opt_var_ls
        for var in opt_var_ls:
            var_spend_sum = model_var_dict[var].var_spend_sum
            spend_var = model_var_dict[var].spend_var
            var_comps = model_var_dict[var].var_comps
            multiplier = x[model_var_dict[var].media_multiplier_idx -1]
            var_sum_after = (self.custom_df[spend_var].copy() * multiplier).sum()
            if var_comps:
                media_multiplier_idx_ls = [model_var_dict[comp].media_multiplier_idx for comp in var_comps]
                multipliers = [x[media_multiplier_idx - 1] for media_multiplier_idx in media_multiplier_idx_ls]
                var_spend_sum = sum([model_var_dict[var_comp].var_spend_sum for var_comp in var_comps])
                var_sum_after = (self.custom_df[var_comps].copy() * multipliers).sum(axis = 1) 
            
            sum_after += var_sum_after
        return media_spend_sum_before - sum_after
    
    def obj_fn(self, x, model_data):
        total_contribution = 0
        model_var_dict = model_data.model_var_dict
        inc_contribution = model_data.inc_contribution
        opt_var_ls = model_data.opt_var_ls
        for var in opt_var_ls:
            model_var = model_var_dict[var].model_var
            spend_var = model_var_dict[var].spend_var
            rate_var = model_var_dict[var].rate_var
            var_coef = model_var_dict[var].var_coef
            # transformation values
            lag = model_var_dict[var].lag
            halflife = model_var_dict[var].halflife
            inflection = model_var_dict[var].inflection
            scale = model_var_dict[var].scale
            # check if the variable is a combined variable
            var_comps = model_var_dict[var].var_comps
            media_multiplier_idx = model_var_dict[var].media_multiplier_idx
            if var_comps:
                spend_vars = [model_var_dict[comp].spend_var for comp in var_comps]
                rate_vars = [model_var_dict[comp].rate_var for comp in var_comps]
                converted_vars = [model_var_dict[comp].converted_var for comp in var_comps]
                media_multiplier_idx_ls = [model_var_dict[comp].media_multiplier_idx for comp in var_comps]
                multipliers = [x[media_multiplier_idx - 1] for media_multiplier_idx in media_multiplier_idx_ls]
                for i in range(len(spend_vars)):
                    self.df[converted_vars[i]] = self.df[spend_vars[i]]/self.df[rate_vars[i]]
                    self.df[converted_vars[i]] = self.df[converted_vars[i]].fillna(0)
                transformed_var_solver = (self.df[converted_vars] * multipliers).sum(axis = 1)
                transformed_var_orig = self.df[spend_vars].sum(axis = 1) 
            else:
                transformed_var_solver = self.df[spend_var].copy() * x[media_multiplier_idx-1] 
                transformed_var_solver = transformed_var_solver/self.df[rate_var]
                transformed_var_solver = transformed_var_solver.fillna(0)
                transformed_var_orig = self.df[spend_var].copy()

            if (self.apply_adstock):
                if (lag>0.0) or (halflife > 0.0):
                    transformed_var_solver = adstock_transformation(transformed_var_solver, float(lag), float(halflife)))

            else:
                if lag != 0:
                    transformed_var_solver = Optimizer.lag_transformation(transformed_var_solver, int(lag))

                if halflife != 0:
                    transformed_var_solver = Optimizer.halflife_transformation(transformed_var_solver, halflife)
                
            if self.transformation_method.upper() == 'S_CURVE':
                if (scale != 0) and (inflection != 0):
                    var_mean = model_var_dict[var].var_mean
                    scurve_var_mean = model_var_dict[var].s_curve_var_mean
                    transformed_var_solver_scaled = transformed_var_solver/var_mean
                    saturation_term_solver = scale * (inflection - transformed_var_solver_scaled)
                    scurve_var_solver = 1/(1+np.exp(saturation_term_solver))-1/(1+np.exp(scale * inflection))
                    transformed_var_solver = scurve_var_solver * var_mean/scurve_var_mean
            
            elif self.transformation_method.upper() == 'C_CURVE':
                var_mean = model_var_dict[var].var_mean
                k_scalar = model_var_dict[var].k_scalar
                transformed_var_solver = Optimizer.c_curve_transformation(var_mean, k_scalar, transformed_var_solver)
                
            transf_var = transformed_var_solver[self.opt_start_row : self.opt_end_row]
            var_contribution = transf_var.sum() * var_coef     
            total_contribution += var_contribution
        return -total_contribution/inc_contribution
    
    def optimization_fn(self, x):
        w1 = self.weights[0]
        w2 = self.weights[1]
        
        model_data_1 = self.OPTIMIZATION_DICT['1']
        model_data_2 = self.OPTIMIZATION_DICT['2']
        opt_1 = self.obj_fn(x, model_data_1)
        opt_2 = self.obj_fn(x, model_data_2)
        
        model_data_1.opt = opt_1
        model_data_2.opt = opt_2

        if self.goal:
            if self.check_max_lift():
                result = w1 * (model_data_1.max_lift + opt_1) ** 2 + w2 * (model_data_2.max_lift + opt_2) ** 2
        else:
            result = w1 * opt_1 + w2 * opt_2
        return result

    def run_optimizer(self, num_cores, goal, global_opt):
        self.goal = goal
        model_data = self.OPTIMIZATION_DICT['1']
        if global_opt:
            nlc = NonlinearConstraint((self.media_sum_before_after), -0.1, np.inf)
            solution = differential_evolution(self.optimization_fn, self.bnds, constraints = (nlc), seed = 1, workers = num_cores, tol = 0.01) 
        else:
            solution = minimize(self.optimization_fn, self.x0,  bounds = self.bnds, method = 'SLSQP', constraints = [self.cons]) 
            
        solution['opts'] = [self.OPTIMIZATION_DICT['1'].opt, self.OPTIMIZATION_DICT['2'].opt]
        return solution
        
    def display_historical_reference_dataframe(self):
        
        model_data = self.OPTIMIZATION_DICT['1']
        model_var_dict = model_data.model_var_dict
        opt_var_ls = model_data.opt_var_ls
        
        df_solver_results = pd.DataFrame()
        spend_var_ls = [model_var_dict[var].spend_var for var in opt_var_ls]
        og_spend_ls = [model_var_dict[var].var_spend_sum for var in opt_var_ls]
        df_solver_results['Variable'] = spend_var_ls
        df_solver_results['Original Sum'] = og_spend_ls
        overall_df = pd.DataFrame({'Variable': ['Total'],
                                  'Original Sum': sum(og_spend_ls)})
        df_solver_results = df_solver_results.append(overall_df, ignore_index = True).fillna(np.nan)
        display(df_solver_results)
        
    # calculate the values of overall contribution dict for one weight, e.g. [0.9, 0.1]
    def get_per_weight_overall_contribution(self, solution):
        model_data_1 = self.OPTIMIZATION_DICT['1']
        model_data_2 = self.OPTIMIZATION_DICT['2']
        
        # inc_contribution from optimization
        opt_1 = self.obj_fn(solution['x'], model_data_1) 
        opt_2 = self.obj_fn(solution['x'], model_data_2)
        inc_solver_1 = -model_data_1.opt * model_data_1.inc_contribution
        inc_solver_2 = -model_data_2.opt * model_data_2.inc_contribution
        # inc_contribution from model
        inc_model_1 = model_data_1.inc_contribution
        inc_model_2 = model_data_2.inc_contribution
        
        contrib_dict = {}
        # append values for model_1
        contrib_dict['Incremental from model1'] = inc_model_1
        contrib_dict['Maximized from Solver1'] = inc_solver_1
        contrib_dict['Maximized from Solver1 True'] = -opt_1 * model_data_1.inc_contribution
        contrib_dict['Opt 1'] = -model_data_1.opt
        contrib_dict['True Opt 1'] = -opt_1
        # append values for model_2
        contrib_dict['Incremental from model2'] = inc_model_2
        contrib_dict['Maximized from Solver2'] = inc_solver_2
        contrib_dict['Maximized from Solver2 True'] = -opt_2 * model_data_2.inc_contribution
        contrib_dict['Opt 2'] = -model_data_2.opt
        contrib_dict['True Opt 2'] = -opt_2
        # append values for solver and model difference
        contrib_dict['Difference1'] = inc_solver_1 - inc_model_1
        contrib_dict['%age change1'] = 100 * (inc_solver_1 - inc_model_1)/inc_model_1
        contrib_dict['Difference2'] = inc_solver_2 - inc_model_2
        contrib_dict['%age change2'] = 100 * (inc_solver_2 - inc_model_2)/inc_model_2
        contrib_dict['w1'] = self.weights[0]
        return contrib_dict
        
    # calculate the values of detailed contribution dataframe for one weight, e.g. [0.9, 0.1]
    def get_per_weight_detailed_contribution(self, solution):
        model_data = self.OPTIMIZATION_DICT['1']
        model_var_dict = model_data.model_var_dict
        opt_var_ls = model_data.opt_var_ls
        idx_ls = [model_var_dict[var].media_multiplier_idx for var in opt_var_ls]
        var_ls = [x for _, x in sorted(zip(idx_ls, opt_var_ls))]
        solver_result_df = pd.DataFrame()
        spend_var_ls = [model_var_dict[var].spend_var for var in var_ls]
        og_spend_ls = [model_var_dict[var].var_spend_sum for var in var_ls]
        solver_result_df['Variable'] = spend_var_ls
        solver_result_df['Original Sum'] = og_spend_ls
        solver_result_df['Solver Percentage'] = solution['x']
        solver_result_df['Solver Sum'] = solver_result_df['Solver Percentage'] * solver_result_df['Original Sum']
        solver_result_df['w1'] = self.weights[0]
        overall_df = pd.DataFrame({'Variable': ['Total'],
                                  'Original Sum': sum(og_spend_ls),
                                  'Solver Sum': solver_result_df['Solver Sum'].sum()})
        
        solver_result_df = solver_result_df.append(overall_df, ignore_index = True).fillna(np.nan)
        return solver_result_df
            
    
    def rank_weights_results(self, weights_arr, goal_opt, global_opt, num_cores):

        n_arr = len(weights_arr)
        n_half = int((n_arr + 1)/2)
        solution_results = [None] * n_arr

        for i in range(n_half):
            
            inv_i = (n_arr - i - 1)
            if (i > 0):
                self.bnds = (ordered_bounds)

            if (i != inv_i):
                self.weights = weights_arr[i]
                upper_result = self.run_optimizer(num_cores = num_cores, goal = goal_opt, global_opt = global_opt)
                solution_results[i] = upper_result
            
            self.weights = weights_arr[inv_i]
            lower_result = self.run_optimizer(num_cores = num_cores, goal = goal_opt, global_opt = global_opt)
            solution_results[inv_i] = lower_result

            lower_best_x, upper_best_x = lower_result['x'], upper_result['x']
            bounds = [[upper_best_x[i], lower_best_x[i]] for i in range(len(lower_best_x))]
            ordered_bounds = [tuple([min(c), max(c)]) for c in bounds]
            
        return solution_results
    
    # public function: export and display the optimization results
    def export_and_display_jointOpt_results(self, weights_arr, goal_opt, global_opt, num_cores):
        start = datetime.now()
        print('start at {}'.format(start))

        results = self.rank_weights_results(weights_arr, goal_opt, global_opt, num_cores)
        overall_contrib_ls = []
        detailed_contrib_ls = []

        count = 0
        for i, weights in enumerate(weights_arr):
            print('processing weight: {}...'.format(weights))
            self.weights = weights
            
            if len(results) == 0:
                solution = self.run_optimizer(num_cores = num_cores, goal = goal_opt, global_opt = global_opt)

            else:
                solution = results[i]
                self.OPTIMIZATION_DICT['1'].opt, self.OPTIMIZATION_DICT['2'].opt = solution['opts'][0], solution['opts'][1]

            detailed_contrib_df = self.get_per_weight_detailed_contribution(solution)
            overall_contrib_dict = self.get_per_weight_overall_contribution(solution)
            overall_contrib_ls.append(overall_contrib_dict)
                
            self.prev_solution = solution['x']
            if count > 0:
                detailed_contrib_df.columns = [col + '.{}'.format(str(count)) for col in detailed_contrib_df.columns]
            detailed_contrib_ls.append(detailed_contrib_df)
    
            count += 1
            print('Completed!')
            print()
            
        overall_contrib_df = pd.DataFrame(overall_contrib_ls)
        detailed_contrib_df = pd.concat(detailed_contrib_ls, axis = 1)
        
        # 1. export result_contrib
        file_path = os.path.join(self.result_folder, 'result_contrib.csv')   
        overall_contrib_df.to_csv(file_path)
        print('Overall Contribution result saved to: {}'.format(file_path))
        display(overall_contrib_df)
        
        # 2. export result_df
        file_path = os.path.join(self.result_folder, 'result_df.csv')   
        detailed_contrib_df.to_csv(file_path)
        print('Detailed Contribution result saved to: {}'.format(file_path))
        display(detailed_contrib_df)
        print('Total running time:', round((datetime.now() - start).seconds/60, 4), 'mins')
        return overall_contrib_df, detailed_contrib_df
        
        
    
    
