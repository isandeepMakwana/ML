# -*- coding: utf-8 -*-
"""
Created on Tue Mar 31 16:40:49 2020

@author: rajat.bansal
"""
import pandas as pd

def colnum_string(n):
    string = ""
    while n > 0:
        n, remainder = divmod(n - 1, 26)
        string = chr(65 + remainder) + string
    return string

class SaveExcelTemplated:
    
    def __init__(self, path):
        self.path = path
        self.writer = pd.ExcelWriter(self.path, engine='xlsxwriter')
        
        self.header_format_features = {'font': 'Bogle',
                                      'font_color': 'white',
                                      'bold': False,
                                      'text_wrap': True,
                                      'valign': 'center',
                                      'fg_color': '#0071CE',
                                      'font_size': 11,
                                      'border': 1}
        
        self.odd_row_format_features = {'font_size': 11,
                                        'border': 1,
                                        'num_format': '#,##0'}
                                        
        self.odd_row_format_percentage = {'font_size': 11,
                                        'border': 1,
                                        'num_format': '0.0%'}
        
        self.odd_row_format_features_decimal = {'font_size': 11,
                                                'border': 1,
                                                'num_format': '#,##0.000'}
                                                
        self.odd_row_format_features_decimal_5 = {'font_size': 11,
                                                'border': 1,
                                                'num_format': '#,##0.00000'}
                                                
        self.odd_row_format_features_scientific = {'font_size': 11,
                                                'border': 1,
                                                'num_format': '0.00E+00'}
        
        self.even_row_format_features = {'bg_color': '#E6E7E8',
                                         'font_size': 11,
                                         'border': 1,
                                         'num_format': '#,##0'}
                                         
        self.even_row_format_percentage = {'bg_color': '#E6E7E8',
                                         'font_size': 11,
                                         'border': 1,
                                         'num_format': '0.0%'}
        
        self.even_row_format_features_decimal = {'bg_color': '#E6E7E8',
                                                 'font_size': 11,
                                                 'border': 1,
                                                 'num_format': '#,##0.000'}
                                                 
        self.even_row_format_features_decimal_5 = {'bg_color': '#E6E7E8',
                                                 'font_size': 11,
                                                 'border': 1,
                                                 'num_format': '#,##0.00000'}
                                                 
        self.even_row_format_features_scientific = {'bg_color': '#E6E7E8',
                                                 'font_size': 11,
                                                 'border': 1,
                                                 'num_format': '0.00E+00'}
        
        
    def add_worksheet(self, df, sheetname, percent_col_names = [], decimal_col_names = [], scientific_col_names= [],
                      decimal_5_col_names = [], startrow= 0):

        df.to_excel(self.writer, sheet_name= sheetname, index= False, startrow= startrow)
        
        self.workbook  = self.writer.book
        self.worksheet = self.writer.sheets[sheetname]
        
        self.workbook.formats[0].set_font_name('Bogle')
        self.workbook.formats[0].set_font_size(10)
        self.worksheet.hide_gridlines(2)
        self.worksheet.set_zoom(90)
        

        for i, col in enumerate(df.columns):
            width= max(df[col].astype(str).apply(lambda x: len(x)))
            width= max([width+2, len(str(col))+2])
            self.worksheet.set_column(i, i, width)
                        
        header_format = self.workbook.add_format(self.header_format_features)
        
        odd_row_format = self.workbook.add_format(self.odd_row_format_features)
        even_row_format = self.workbook.add_format(self.even_row_format_features)
        
        odd_row_percent_format = self.workbook.add_format(self.odd_row_format_percentage)
        even_row_percent_format = self.workbook.add_format(self.even_row_format_percentage)
        
        odd_row_decimal_format = self.workbook.add_format(self.odd_row_format_features_decimal)
        even_row_decimal_format = self.workbook.add_format(self.even_row_format_features_decimal)
        
        odd_row_decimal_5_format = self.workbook.add_format(self.odd_row_format_features_decimal_5)
        even_row_decimal_5_format = self.workbook.add_format(self.even_row_format_features_decimal_5)
        
        odd_row_scientific_format = self.workbook.add_format(self.odd_row_format_features_scientific)
        even_row_scientific_format = self.workbook.add_format(self.even_row_format_features_scientific)
        
        for col_num, value in enumerate(df.columns.values):
            self.worksheet.write(startrow, col_num, value, header_format)
            
#        all_cols = []
#        last_col = colnum_string(df.shape[1])
#
#        for i in range(0, df.shape[0]+1):
#            if i%2==0:  
#                self.worksheet.conditional_format('A' + str(i+1) + ':' + last_col + str(i+1), 
#                                                  {'type': 'no_errors',
#                                                   'format': odd_row_format})
#            else:     
#                self.worksheet.conditional_format('A' + str(i+1) + ':' + last_col + str(i+1), 
#                                                  {'type': 'no_errors',
#                                                   'format': even_row_format})
#            
            
        all_cols = [colnum_string(i) for i in range(1 ,df.shape[1]+1)]
        
        percent_cols = []
        for i in range(0 ,df.shape[1]):
            if df.columns.values[i] in percent_col_names:
                percent_cols.append(colnum_string(i+1))
        
        decimal_cols = []
        for i in range(0 ,df.shape[1]):
            if df.columns.values[i] in decimal_col_names:
                decimal_cols.append(colnum_string(i+1))
        
        decimal_5_cols = []
        for i in range(0 ,df.shape[1]):
            if df.columns.values[i] in decimal_5_col_names:
                decimal_5_cols.append(colnum_string(i+1))
                
        scientific_cols = []
        for i in range(0 ,df.shape[1]):
            if df.columns.values[i] in scientific_col_names:
                scientific_cols.append(colnum_string(i+1))

        for row in range(startrow + 2, startrow + df.shape[0]+2):
            for col in all_cols:
                if row%2==0:  
                    if col in percent_cols:
                        self.worksheet.conditional_format(col + str(row), 
                                                          {'type': 'no_errors',
                                                           'format': odd_row_percent_format})
                    elif col in decimal_cols:
                        self.worksheet.conditional_format(col + str(row), 
                                                          {'type': 'no_errors',
                                                           'format': odd_row_decimal_format})
            
                    elif col in decimal_5_cols:
                        self.worksheet.conditional_format(col + str(row), 
                                                          {'type': 'no_errors',
                                                           'format': odd_row_decimal_5_format})
            
                    elif col in scientific_cols:
                        self.worksheet.conditional_format(col + str(row), 
                                                          {'type': 'no_errors',
                                                           'format': odd_row_scientific_format})
            
                    else:
                        self.worksheet.conditional_format(col + str(row), 
                                                          {'type': 'no_errors',
                                                           'format': odd_row_format})
                else: 
                    if col in percent_cols:
                        self.worksheet.conditional_format(col + str(row), 
                                                          {'type': 'no_errors',
                                                           'format': even_row_percent_format})
            
                    elif col in decimal_cols:
                        self.worksheet.conditional_format(col + str(row), 
                                                          {'type': 'no_errors',
                                                           'format': even_row_decimal_format})
                
                    elif col in decimal_5_cols:
                        self.worksheet.conditional_format(col + str(row), 
                                                          {'type': 'no_errors',
                                                           'format': even_row_decimal_5_format})
            
                    elif col in scientific_cols:
                        self.worksheet.conditional_format(col + str(row), 
                                                          {'type': 'no_errors',
                                                           'format': even_row_scientific_format})
                    else:
                        self.worksheet.conditional_format(col + str(row), 
                                                          {'type': 'no_errors',
                                                           'format': even_row_format})
            
    def add_worksheet_analyst(self, df, sheetname, percent_col_names = [], decimal_col_names = [], scientific_col_names= [],
                      decimal_5_col_names = []):

        df.to_excel(self.writer, sheet_name= sheetname, float_format="%.2f", index= False)
        
        self.workbook  = self.writer.book
        self.worksheet = self.writer.sheets[sheetname]
        
        self.workbook.formats[0].set_font_name('Bogle')
        self.workbook.formats[0].set_font_size(10)
        self.worksheet.hide_gridlines(2)
        self.worksheet.set_zoom(90)
        
                        
                
    def save_worksheet(self):
        self.writer.save()
    

        