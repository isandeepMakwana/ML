from dataclasses import dataclass, field
from typing import List
import typing
import numpy as np
import pandas as pd
import statsmodels.tsa.filters.filtertools
from scipy.stats import pearsonr
import math
import re
import os
from datetime import datetime, date, timedelta
import matplotlib.pyplot as plt
from save_excel import SaveExcelTemplated
import warnings
warnings.filterwarnings('ignore')

from custom_transformation_functions import lag_transformation, halflife_transformation, adstock_transformation, scurve_transformation

# each of the variable (media driver) used in the model has the below attributes
@dataclass
class ModelVariable:
    
    # the model results attributes for each variable
    model_var: str = ''
    spend_var: str = ''
    rate_var: str = ''
    model_var_full: str = ''
    var_coef: float = 0
    var_source: str = ''
    simulation_start_date: str = ''
        
    # the transformaiton values for each variable 
    lag: int = 0
    halflife: int = 0
    inflection: float = 0
    scale: float = 0
    log: int = 0
    
    # means after transformation
    var_mean: float = 0 # var_mean
    s_curve_var_mean: float = 0 # for s_curve transformation
    k_scalar: float = 0 # for c_curve transformation
    
    # spend
    total_spend: float = 0
    historical_spend: float = 0
    daily_spend: float = 0 
    spend_ratio: float = 0
    
    # metrics   
    total_metrics: float = 0
    daily_metrics: float = 0
    metric_rate: List[float] = field(default_factory=list)
    model_rate: List[float] = field(default_factory=list)
    rate_unit: str = '' # CPD, CPC, CPM, CPI
        
    # this is only for HPLO variables
    hist_imp_per_on_air_day: float = 0
    # this is only for Search variables ending with _IMP 
    historical_CTR: float = 0
        
    # three points
    threshold_point: float = 0
    inflection_point: float = 0
    saturation_point: float = 0
        
    # impact
    impact: float = 0
    historical_impact: float = 0
    impact_lift: float = 0
    impact_ratio: float = 0
    
    # iroas
    iroas: float = 0
    historical_iroas: float = 0
    iroas_lift: float = 0
          
    # on air days  
    on_air_days: int = 0
    historical_on_air_days: int = 0
    
    # percentage of on air days
    pct_historical_days_less_than_threshold: float = 0
    pct_historical_days_between_threshold_saturation: float = 0
    pct_historical_days_beyond_saturation: float = 0
    pct_simulation_days_less_than_threshold: float = 0
    pct_simulation_days_between_threshold_saturation: float = 0
    pct_simulation_days_beyond_saturation: float = 0
    

class Simulator:
    def __init__(self,
                 df,
                 transformation_method,
                 final_model_path,
                 trans_path,
                 simulation_start_end_date,
                 modeling_start_end_date,
                 media_spends_dict,
                 granular_media_dict,
                 media_cpm_cpi_dict,
                 apply_adstock = False
                ):
        self.df = df
        self.transformation_method = transformation_method
        self.final_model_path = final_model_path
        self.trans_path = trans_path
        self.apply_adstock = apply_adstock
        self.s_curve_points = self.get_s_curve_points_dict()
        
        self.DEFAULT_K_CONSTANT = 0.2
        # reformat the simulaiton start and end dates
        self.simulation_start_date_str, self.simulation_end_date_str = simulation_start_end_date
        self.simulation_start_date = pd.to_datetime(self.simulation_start_date_str)
        self.simulation_end_date = pd.to_datetime(self.simulation_end_date_str)
        # check the simulation days, if > 366, throw an error. 
        if (self.simulation_end_date - self.simulation_start_date).days > 366:
            raise NameError('The simulation days should be < 366, please adjust the simulation start, end dates!')
        
        # reformat the transformation start and end dates
        self.modeling_start_date_str, self.modeling_end_date_str = modeling_start_end_date
        self.modeling_start_date = pd.to_datetime(self.modeling_start_date_str)
        self.modeling_end_date = pd.to_datetime(self.modeling_end_date_str)
    
        self.media_spends_dict = media_spends_dict
        self.granular_media_dict = granular_media_dict
        self.media_cpm_cpi_dict = media_cpm_cpi_dict
        
        # if the variables are cpd_variables, rate = total_spend / total_on_air_days
        # the rates are fixed, we can only increase the budget to increase the on_air_days
        self.CPD_variables = ['M_ON_DIS_HPLO_SPEND', 
                              'M_ON_DIS_HPLO_IMP', 
                              'M_ON_DIS_HPLO_VIEW_IMP', 
                              'M_ON_DIS_HPLO_CLK',
                              'M_ON_DIS_HPLO_SPEND_CALC',
                              'M_INSTORE_TV_WALL_IMP',
                              'M_INSTORE_SCO_DETECTED_IMP',
                              'M_INSTORE_SCO_IMP',
                              'M_INSTORE_SCO_SPEND_CALC']
        
        # if the variables contain one of the below component, it is a search variable, it should use CPC or CPM rate
        self.search_variable_substrings = ['_SEARCH_', '_SBA_', '_SP_']
        
        # get all the variables need to be simulated 
        dict_1 = self.get_model_result_variables()
        dict_2 = self.get_media_spend_variables()
        dict_3 = self.get_granular_media_variables()
        self.model_variable_dict = self.combine_model_variables(dict_1, dict_2, dict_3)
        
        # update the threshold, inflection, and saturations values to each variable
        self.update_threshold_inflection_saturation_values()
        
        # initiate dataframes 
        self.all_df_base, self.prev_df_base, self.simulator_df_base, self.updated_stack_all_cols_df = self.initialize_dataframes()
        self.prev_days, self.simulation_days = len(self.prev_df_base), len(self.simulator_df_base)

        # the dict includes the columns which will be exported for model variable
        # the keys are the attributes from the ModelVariable class 
        # the values could be any names 
        self.var_result_cols = {
                'model_var': 'Media',
                'var_coef': 'Variable Coeff', 
                'impact': 'New Contribution',
                'impact_lift': 'Contribution Lift',
                'historical_impact': 'Historical Contribution',
                'impact_ratio': 'Contribution Ratio', 
                'total_spend': 'New Spend',
                'spend_ratio': 'Current Hist Spend Ratio',
                'historical_spend': 'Historical Spend',
                'iroas':'New iRoAS',
                'iroas_lift': 'iRoAS Lift',
                'historical_iroas': 'Historical iRoAS',
                'daily_metrics': 'New Daily Metric',
                'daily_spend': 'New Daily Spend',
                'model_rate': 'Rates',
                'rate_unit': 'Rate Unit',
                'on_air_days': 'New On-air Days', 
                'historical_on_air_days': 'Hist on-air days',
                'threshold_point': 'Threshold',
                'inflection_point': 'Inflection',
                'saturation_point': 'Saturation',
                'pct_simulation_days_less_than_threshold': 'Pct Simulation Days Less than Threshold',
                'pct_simulation_days_between_threshold_saturation': 'Pct Simulation Days Btw Threshold and Saturation',
                'pct_simulation_days_beyond_saturation': 'Pct Simulation Days Beyond Saturation',
                'pct_historical_days_less_than_threshold': 'Pct Hist Days Less than Threshold', 
                'pct_historical_days_between_threshold_saturation': 'Pct Hist Days Btw Threshold and Saturation',
                'pct_historical_days_beyond_saturation': 'Pct Hist Days Beyond Saturation',
            }
        
        # display the dataframe including the historical attributes for each variable for reference
        self.display_historical_reference_dataframe()

        # create the folder to save simulation result
        self.result_folder = self.create_results_folder()
        
        # create and save the simulaiton log
        self.create_simulation_log()
        
    # parse the var_str to get variable attributes
    @staticmethod
    def parse_var_str(var_str):
        model_var_obj = ModelVariable()
        model_var_obj.model_var = var_str
        pattern = re.match(r'(.*?)_[0-9.]*_[0-9.]*_[0-9.]*_[0-9.]*_[0-9.]', var_str)
        if pattern:
            model_var_obj.model_var = pattern.group(1)
            model_var_obj.spend_var = Simulator.get_spend_var(model_var_obj.model_var)
            model_var_obj.lag = int(var_str.split('_')[-5])
            model_var_obj.halflife = int(var_str.split('_')[-4])
            model_var_obj.inflection = float(var_str.split('_')[-3])
            model_var_obj.scale = float(var_str.split('_')[-2])
            model_var_obj.log = int(var_str.split('_')[-1])   
        return model_var_obj 

    # get the spend variable for the media driver if not spend
    @staticmethod
    def get_spend_var(var):
        spend_var = ''
        if var.startswith('M_') and (var.rsplit('_', 1)[-1].upper() != 'SPEND'):
            spend_var = var.rsplit('_', 1)[0] + '_SPEND'
        return spend_var
    
    @staticmethod
    def get_rate_var(var):
        rate_var = ''
        if var.startswith('M_'):
            if var.rsplit('_', 1)[-1].upper() == 'IMP':
                rate_var = 'RATE_' + '_'.join(var.split('_')[1:-1])
            elif var.rsplit('_', 1)[-1].upper() == 'CLK':
                rate_var = 'RATE_' + '_'.join(var.split('_')[1:])
        return rate_var

    @staticmethod
    def adstock_transformation(var, peak = 1.0, halflife = 1.0):
        return adstock_transformation(var, peak = float(peak), halflife = float(halflife))
    
    @staticmethod
    def lag_transformation(var, lag = 1):
        lag_variable = var.shift(lag)
        lag_variable = lag_variable.fillna(0)
        return lag_variable
    
    @staticmethod
    def halflife_transformation(var, halflife = 1):
        retention = np.exp(math.log(0.5)/halflife)    
        transformed_var = var * (1 - retention)
        transformed_var = statsmodels.tsa.filters.filtertools.recursive_filter(transformed_var, retention)
        return transformed_var
    
    @staticmethod
    def c_curve_transformation(var_mean, k_scalar, var):
        transformed_var =  np.log(var/(k_scalar * var_mean) + 1)
        return transformed_var
    
    # for c_curve
    def get_k_scalar(self, var_mean, var):
        # get the k_scalar required for the c_curve transformation
        # TODO: must be the same as the modeling, read k from modeling result
        k_scalar = (max(var) * self.DEFAULT_K_CONSTANT)/var_mean
        return k_scalar
    
    # create the folder to save the simulaiton results    
    def create_results_folder(self):
        result_folder = os.path.abspath(os.path.join(self.final_model_path.rsplit('/', 2)[0], 'simulation_results'))
        if not os.path.isdir(result_folder ):
            os.mkdir(result_folder )
        return result_folder 
    
    def create_simulation_log(self):
        # create the dataframe for the simulation duration, start date, end_date
        simulation_log_df = pd.DataFrame({'simulation_start_date':[self.simulation_start_date_str], 
                                         'simulation_end_date':[self.simulation_end_date_str],
                                         'transformation_start_date': [self.modeling_start_date_str],
                                         'transformation_end_date': [self.modeling_end_date_str],
                                         'apply_adstock': [self.apply_adstock]}, index = [0])
        result_folder = self.result_folder
        if not os.path.isdir(result_folder):
            os.mkdir(result_folder)
        excel_obj = SaveExcelTemplated(os.path.join(result_folder, 'Simulation_Log.xlsx'))   
        excel_obj.add_worksheet(simulation_log_df, 'Simulation Log', decimal_5_col_names= simulation_log_df.columns)
        excel_obj.save_worksheet()
        
    # check if the variable is search
    def is_search_variable(self, var):
        result = any([search_variable_substring in var for search_variable_substring in self.search_variable_substrings])
        return result and var.endswith('_CLK')
      
    def get_variable_rate_unit(self, var):
        if var in self.CPD_variables:
            rate_unit = 'CPD'
        elif self.is_search_variable(var):
            rate_unit = 'CPC'
        else:
            rate_unit = 'CPM'
        return rate_unit
    
    def is_CPD_variable(self, rate_unit):
        return rate_unit == 'CPD'
    
    # get the dict of all variables from the model_result_output
    def get_model_result_variables(self):
        model_result_variable_dict = {}
        try:    
            model_results_df = pd.read_excel(self.final_model_path)[['Variable Actual', 'Coefficient']]
        except:
            model_results_df = pd.read_excel("\\\\?\\" + os.path.abspath(self.final_model_path))[['Variable Actual', 'Coefficient']]

        #model_variable_ls = list(model_results_df['Variable Actual'].values)
        model_variable_ls = model_results_df['Variable Actual']
        for var_str in model_variable_ls:
            model_var_obj = Simulator.parse_var_str(var_str)
            model_var = model_var_obj.model_var
            var_coef = model_results_df[model_results_df['Variable Actual'] == var_str]['Coefficient'].values[0]
            model_var_obj.var_coef = var_coef
            model_var_obj.rate_var = Simulator.get_rate_var(model_var)
            model_var_obj.rate_unit = self.get_variable_rate_unit(model_var)
            model_var_obj.var_source = 'model'
            model_var_obj.model_var_full = var_str
            model_result_variable_dict[model_var_obj.model_var] =  model_var_obj 
        return model_result_variable_dict
    
    # get the dict of all variables from the media_spend_dict
    def get_media_spend_variables(self):
        
        media_spend_variable_dict = {}
        for key, value in self.media_spends_dict.items():
            model_var = key.replace('SPEND', value[1])
            model_var_obj = ModelVariable()
            model_var_obj.model_var = model_var
            model_var_obj.spend_var = key
            model_var_obj.rate_var = Simulator.get_rate_var(model_var)
            model_var_obj.rate_unit = self.get_variable_rate_unit(model_var)
            model_var_obj.total_spend = value[0]
            model_var_obj.simulation_start_date = value[2]
            model_var_obj.var_source = 'spend_dict'
            media_spend_variable_dict[model_var_obj.model_var] = model_var_obj
        
        return media_spend_variable_dict
    
    # get the dict of all variables from the granular_media_dict
    def get_granular_media_variables(self):
        
        granular_media_variable_dict = {}
        for key, comps in self.granular_media_dict.items():
            model_var_obj = ModelVariable()
            model_var_obj.model_var = key
            model_var_obj.spend_var = Simulator.get_spend_var(key)
            model_var_obj.rate_var = Simulator.get_rate_var(key)
            model_var_obj.rate_unit = self.get_variable_rate_unit(key) 
            model_var_obj.var_source = 'granular_dict_combined'
            granular_media_variable_dict[model_var_obj.model_var] = model_var_obj
            for comp in comps:
                model_var_obj = ModelVariable()
                model_var_obj.model_var = comp
                model_var_obj.spend_var = Simulator.get_spend_var(comp)
                model_var_obj.rate_var = Simulator.get_rate_var(comp)
                model_var_obj.rate_unit =  self.get_variable_rate_unit(comp)
                model_var_obj.var_source = 'granular_dict_single'
                granular_media_variable_dict[model_var_obj.model_var] = model_var_obj

        return granular_media_variable_dict
    
    # combine the dict created from the three resources to get a list of all variables
    def combine_model_variables(self, dict_1, dict_2, dict_3):
    
        combined_dict = dict_1
        for key in dict_2:
            if key not in combined_dict:
                combined_dict[key] = dict_2[key]

        for key in dict_3:
            if key not in combined_dict:
                combined_dict[key] = dict_3[key]
        return combined_dict
    
    def get_s_curve_points_dict(self):
        
        trans_data = pd.read_excel(open(self.trans_path, 'rb'), sheet_name = 'Points')
        orig_vars = trans_data['Variable'].apply(lambda x: x.rsplit('_', 5)[0])
        inflection = trans_data['Inflection Point']
        threshold = trans_data['Threshold Point']
        saturation = trans_data['Saturation Point']
        inflection_dict = dict(zip(orig_vars, inflection))
        threshold_dict = dict(zip(orig_vars, threshold))
        saturation_dict = dict(zip(orig_vars, saturation))
        s_curve_points = {'inflection': inflection_dict, 'threshold': threshold_dict, 'saturation': saturation_dict}
        return s_curve_points

    # update the threshold, inflection, saturation values for each variable
    def update_threshold_inflection_saturation_values(self):
        
        for var in self.s_curve_points['inflection']:
            if var not in self.model_variable_dict:
                raise ValueError('Variable {} not exist in the model output!'.format(var))
            self.model_variable_dict[var].threshold_point = self.s_curve_points['threshold'][var]
            self.model_variable_dict[var].inflection_point = self.s_curve_points['inflection'][var]
            self.model_variable_dict[var].saturation_point = self.s_curve_points['saturation'][var]
            
            
    # initialize the datafames which will be used for the simulation
    def initialize_dataframes(self):
        
        model_vars = [self.model_variable_dict[model_obj].model_var for model_obj in self.model_variable_dict]
        spend_vars = [self.model_variable_dict[model_obj].spend_var for model_obj in self.model_variable_dict if self.model_variable_dict[model_obj].spend_var]

        all_df = self.df.copy()
        prev_start = self.simulation_start_date - pd.DateOffset(years = 1)
        prev_end = self.simulation_end_date - pd.DateOffset(years = 1)
        
        # update all_df if the dates in interested year missing, read the dates from previous year
        df_max_date = pd.to_datetime(str(all_df.index.max()).split(' ')[0])
        if df_max_date >= prev_end:
            updated_stack_all_cols_df = all_df
            
        else:
            df_1 = all_df
            extra_start = df_max_date - pd.DateOffset(years = 1, days = -1)
            extra_end = prev_end - pd.DateOffset(years = 1)
            df_2 = all_df.loc[((all_df.index >= extra_start) & (all_df.index <= extra_end))]
            
            df_2.index = df_2.index - pd.DateOffset(years = -1)
            updated_stack_all_cols_df = pd.concat([df_1, df_2])
            
        # clean the duplicated rows
        updated_stack_all_cols_df = updated_stack_all_cols_df[~updated_stack_all_cols_df.index.duplicated(keep='first')]
    
        # get the list of all variables used in the simulation
        all_model_vars = set(model_vars + spend_vars)
        updated_stack_df = updated_stack_all_cols_df[all_model_vars]
        
        # get the prev_df
        prev_df = updated_stack_df.loc[((updated_stack_df.index >= prev_start) & (updated_stack_df.index <= prev_end))]
            
        # get the simulation_df
        simulation_days = pd.date_range(self.simulation_start_date, self.simulation_end_date, freq = 'd')  
        simulator_df = pd.DataFrame()
        simulator_df['index'] = simulation_days
        for col in updated_stack_df.columns:
            if col == 'index':
                continue
            simulator_df[col] = updated_stack_df.loc[simulator_df['index'].apply(lambda x: x - pd.DateOffset(years=1)).values][col].values[: len(simulation_days)]
                
        simulator_df.set_index('index', inplace = True, drop = True)  
        return updated_stack_df, prev_df, simulator_df, updated_stack_all_cols_df
       
    # update all media_spend_dict variable details to the MODEL_VARIABLE_DICT
    def update_variable_rates(self, var):
        # Step 1. read rate (cost_average) from simulation_df
        spend_var = self.model_variable_dict[var].spend_var
        model_var = self.model_variable_dict[var].model_var
        
        cost_average = self.simulator_df[spend_var].sum()/(self.simulator_df[model_var].sum())
        metric_rate, model_rate = cost_average, cost_average
        rate_unit = self.model_variable_dict[model_var].rate_unit
        # update the total_spend, simulation_start_date, model_unit
        if spend_var in self.media_spends_dict:
            self.model_variable_dict[model_var].total_spend = self.media_spends_dict[spend_var][0]
            self.model_variable_dict[model_var].simulation_start_date = self.media_spends_dict[spend_var][2]
            
        # update the model_unit
        if spend_var in self.media_cpm_cpi_dict:
            cost_average = self.media_cpm_cpi_dict[spend_var][0]
            # update the metric_rate, model_rate accordingly
            metric_rate, model_rate = cost_average, cost_average
            rate_unit = self.media_cpm_cpi_dict[spend_var][1].strip().upper()

            if rate_unit == 'CPM':
                metric_rate = metric_rate / 1000     

            elif rate_unit == 'CPI':
                model_rate  = model_rate * 1000
                rate_unit = 'CPM'

            elif rate_unit == 'CPC' and model_var.endswith('_IMP'):
                clk_var = model_var.replace('_IMP', '_CLK')                            
                historical_CTR = self.simulator_df[clk_var].sum()/self.simulator_df[model_var].sum()
                metric_rate = metric_rate * historical_CTR
                rate_unit = 'CPC'
            self.model_variable_dict[model_var].rate_unit = rate_unit
                        
        # update the rate unit if it were CPD, or CPM variables
        else:
            # 1. update rate if the rate_unit == 'CPD'
            if rate_unit == 'CPD':
                on_air_days = sum(self.simulator_df[model_var] > 0)
                if on_air_days > 0:
                    metric_rate = self.simulator_df[spend_var].sum()/on_air_days
                    model_rate = metric_rate
            if rate_unit == 'CPM':
                model_rate = model_rate * 1000
                
        self.model_variable_dict[var].metric_rate = [round(metric_rate, 8)]
        self.model_variable_dict[var].model_rate = [round(model_rate, 8)]
        
    # priviate function to display historical reference dataframe
    def display_historical_reference_dataframe(self):
        historical_attribute_ls = ['model_var',
                                    'var_coef', 
                                    'total_spend',
                                    'historical_spend',
                                    'historical_impact',
                                    'historical_iroas',
                                    'model_rate',
                                    'rate_unit',
                                    'historical_on_air_days',
                                    'threshold_point',
                                    'inflection_point',
                                    'saturation_point',
                                    'pct_historical_days_less_than_threshold', 
                                    'pct_historical_days_between_threshold_saturation',
                                    'pct_historical_days_beyond_saturation']
        historical_attributes = {key: self.var_result_cols[key] for key in historical_attribute_ls}
        
        var_result_ls = [] 
        for var in self.model_variable_dict:  
            source_ls = ['model', 'granular_dict_single', 'spend_dict']
            if self.model_variable_dict[var].var_source in source_ls and var.startswith('M_'): 
                # re-initiate the dataframes
                self.simulator_df = self.simulator_df_base.copy()
                self.prev_df = self.prev_df_base.copy()
                self.all_df = self.all_df_base.copy()
                # update the attributes for each variable
                self.update_variable_rates(var)
                self.transform_df, self.combined_df = self.get_transform_and_combined_dataframe()
                self.update_per_var_prev_and_simulation_dataframes(var)
                self.update_per_var_dict(var, only_calculate_hist_attributes = True)
                var_result_ls.append(self.model_variable_dict[var].__dict__.copy())
        
        for var in self.model_variable_dict:
            if var in self.granular_media_dict: 
                comps = self.granular_media_dict[var]
                cost_average_ls = [round(self.model_variable_dict[comp].metric_rate[0], 8) for comp in comps]
                model_rate_ls = [round(self.model_variable_dict[comp].model_rate[0], 8) for comp in comps]
                total_spend = sum([self.model_variable_dict[comp].total_spend for comp in comps])
                simulation_start_date = min([self.model_variable_dict[comp].simulation_start_date for comp in comps])
                
                # update the ModelVariable Obj
                self.model_variable_dict[var].metric_rate = cost_average_ls
                self.model_variable_dict[var].model_rate = model_rate_ls
                self.model_variable_dict[var].total_spend = total_spend
                self.model_variable_dict[var].simulation_start_date = simulation_start_date

                for i, var_dic in enumerate(var_result_ls):
                    if var_dic['model_var'] == var:
                        del var_result_ls[i]
                        break
                var_result_ls.append(self.model_variable_dict[var].__dict__.copy())

        var_result_df = pd.DataFrame(var_result_ls) 
        var_result_df = var_result_df[[col for col in historical_attributes]]
        var_result_df.rename(columns = historical_attributes, inplace = True)
        display(var_result_df)
        
    # update all media_spend_dict variable details to the MODEL_VARIABLE_DICT
    def update_media_spend_variable_attributes(self):

        for var, value in self.media_spends_dict.items():
            model_var = var.replace('SPEND', value[1])
            if model_var not in self.model_variable_dict:
                raise ValueError('Variable {} not exist in model variable dict!'.format(var))
            spend_var = var
            total_spend = value[0]
            simulation_start_date = value[2]

            # Step 1. read rate from simulation_df
            cost_average = self.simulator_df[spend_var].sum()/(self.simulator_df[model_var].sum())
            metric_rate, model_rate = cost_average, cost_average
            rate_unit =  self.model_variable_dict[model_var].rate_unit 

            # update rate if rate_unit = CPD, home lockout variables and other CPD variables
            if self.model_variable_dict[model_var].rate_unit == 'CPD':
                on_air_days = sum(self.simulator_df[model_var] > 0)
                if on_air_days > 0:
                    metric_rate = self.simulator_df[spend_var].sum()/on_air_days
                    model_rate = metric_rate
                    hist_imp_per_on_air_day = self.simulator_df[model_var].sum()/on_air_days
                    self.model_variable_dict[model_var].hist_imp_per_on_air_day = hist_imp_per_on_air_day
            # update rate if the rate_unit == 'CPM'
            if self.model_variable_dict[model_var].rate_unit == 'CPM':
                model_rate = model_rate * 1000

            # Step 2. read the rate from media_cpm_cpi_dict, and update the dict
            if spend_var in self.media_cpm_cpi_dict:
                cost_average = self.media_cpm_cpi_dict[spend_var][0]
                # update the metric_rate, model_rate accordingly
                metric_rate, model_rate = cost_average, cost_average
                rate_unit = self.media_cpm_cpi_dict[spend_var][1].strip().upper()

                if rate_unit == 'CPM':
                    metric_rate = metric_rate / 1000     
                elif rate_unit == 'CPI':
                    model_rate  = model_rate * 1000
                    rate_unit = 'CPM'
                elif rate_unit == 'CPC' and model_var.endswith('_IMP'):

                    clk_var = model_var.replace('_IMP', '_CLK')                            
                    historical_CTR = self.simulator_df[clk_var].sum()/self.simulator_df[model_var].sum()
                    metric_rate = metric_rate * historical_CTR
                    rate_unit = 'CPC'
                self.model_variable_dict[model_var].rate_unit = rate_unit

            # Step 3. if cost_average is still 0, try to read from all historical dataset. 
            if np.abs(metric_rate) <1e-6:
                # if cost_average = 0, read the whole historical time period to get the cost_average
                metric_rate = self.df[spend_var].sum()/self.df[model_var].sum() 
                model_rate = metric_rate
                # need to update based on different rate_units
                if rate_unit == 'CPD':
                    on_air_days = sum(self.df[model_var] > 0)
                    if on_air_days <= 0:
                        raise ValueError('Enter CPD rate for variable: {}!'.format(var))
                    metric_rate = self.df[spend_var].sum()/on_air_days
                    model_rate = metric_rate
                    hist_imp_per_on_air_day = self.df[model_var].sum()/on_air_days
                    self.model_variable_dict[model_var].hist_imp_per_on_air_day = hist_imp_per_on_air_day
                
                if rate_unit == 'CPM':
                    model_rate = metric_rate * 1000
                
            # if cost_average = 0 again, a box will be prompted so that the users can enter the cpi
            if np.abs(metric_rate) <1e-6:
                print('Enter the {} rate for variable: {}'.format(rate_unit, model_var))
                metric_rate = float(input())  
                model_rate = metric_rate
                if rate_unit == 'CPM':
                    metric_rate = metric_rate / 1000
                    
            total_metrics = total_spend/metric_rate
            self.model_variable_dict[model_var].spend_var = spend_var
            self.model_variable_dict[model_var].total_spend = total_spend
            self.model_variable_dict[model_var].simulation_start_date = simulation_start_date
            self.model_variable_dict[model_var].metric_rate = [round(metric_rate, 8)]
            self.model_variable_dict[model_var].model_rate = [round(model_rate, 8)]
            self.model_variable_dict[model_var].total_metrics  = total_metrics
                    
    # update all granular_media variable details to the MODEL_VARIABLE_DICT
    def update_granular_media_variable_attributes(self):
        
        for agg, comps in self.granular_media_dict.items():
            model_var = agg
            if model_var in self.model_variable_dict:
                cost_average_ls = [round(self.model_variable_dict[comp].metric_rate[0], 8) for comp in comps]
                model_rate_ls = [round(self.model_variable_dict[comp].model_rate[0], 8) for comp in comps]
                total_spend = sum([self.model_variable_dict[comp].total_spend for comp in comps])
                total_metrics = sum([self.model_variable_dict[comp].total_metrics for comp in comps])
                simulation_start_date = min([self.model_variable_dict[comp].simulation_start_date for comp in comps])
                
                # update the ModelVariable Obj
                self.model_variable_dict[model_var].metric_rate = cost_average_ls
                self.model_variable_dict[model_var].model_rate = model_rate_ls
                self.model_variable_dict[model_var].total_spend = total_spend
                self.model_variable_dict[model_var].total_metrics = total_metrics
                self.model_variable_dict[model_var].simulation_start_date = simulation_start_date
                
    def update_per_var_on_air_days_and_daily_metrics(self, point_dict, var):
        
        if var in self.model_variable_dict:

            spend_var = self.model_variable_dict[var].spend_var
            total_metrics = self.model_variable_dict[var].total_metrics
            total_spend = self.model_variable_dict[var].total_spend
            daily_metrics = point_dict[var]
            
            if self.model_variable_dict[var].rate_unit == 'CPD':
                on_air_days = math.floor(total_spend/self.model_variable_dict[var].model_rate[0])
                if on_air_days > self.simulation_days:
                    print('The total simulation days for HPLO variable is cut to the the maximum of simulation days! ')
                    on_air_days = self.simulation_days
                
                daily_metrics = self.model_variable_dict[var].hist_imp_per_on_air_day
                self.model_variable_dict[var].total_metrics = daily_metrics * on_air_days
                daily_spend = self.model_variable_dict[var].model_rate[0]
                self.simulator_df[var] = 0
                self.simulator_df.loc[:on_air_days, var] = daily_metrics
                self.model_variable_dict[var].daily_metrics = daily_metrics
                self.model_variable_dict[var].on_air_days = on_air_days
                self.model_variable_dict[var].daily_spend = daily_spend
                
            else:
                on_air_days = math.floor(total_metrics/daily_metrics) 
                if (self.model_variable_dict[var].rate_unit != 'CPD') and (on_air_days > self.simulation_days):
                    on_air_days = self.simulation_days     
                    daily_metrics =  total_metrics/on_air_days

                self.simulator_df[var] = 0
                self.simulator_df.loc[:on_air_days, var] = self.model_variable_dict[var].total_metrics/on_air_days
                self.model_variable_dict[var].daily_metrics = daily_metrics
                self.model_variable_dict[var].on_air_days = on_air_days
                self.model_variable_dict[var].daily_spend = self.model_variable_dict[var].total_spend/on_air_days
   
    # get the transform_df and combine_df to calculate the trans logs
    def get_transform_and_combined_dataframe(self):
        transform_df = self.all_df[(self.all_df.index >= self.modeling_start_date) & (self.all_df.index <= self.modeling_end_date)].copy()
        
        # get the combined_df
        temp_df = self.all_df[self.all_df.index < self.simulation_start_date]
        combined_temp = pd.concat([temp_df[self.simulator_df.columns], self.simulator_df], axis= 0)
        
        combined_df = pd.DataFrame()
        for col in combined_temp.columns:
            series = combined_temp[col].asfreq('D')
            combined_df[col] = series
            combined_df['index'] = series.index.values
            combined_df.index = series.index.values
        combined_df = combined_df.fillna(0)
        return transform_df, combined_df
    
    # update the prev_df and simulator_df for one var
    def update_per_var_prev_and_simulation_dataframes(self, var):

        if self.model_variable_dict[var].var_source == 'model' and var.startswith('M_'):
            # Step 1. calculate the var_mean, and S_curve_var_mean from the transform_df
            transformed_var_orig = self.transform_df[var].copy()
            # lag transformation
            lag = self.model_variable_dict[var].lag
            halflife = self.model_variable_dict[var].halflife
            scale = self.model_variable_dict[var].scale
            inflection = self.model_variable_dict[var].inflection

            var_mean = transformed_var_orig.mean()
            self.model_variable_dict[var].var_mean = var_mean
            if self.apply_adstock:
                transformed_var_orig = Simulator.adstock_transformation(transformed_var_orig,
                                                                        peak = float(lag),
                                                                        halflife = float(halflife))

            else:
                if lag != 0:
                    transformed_var_orig = Simulator.lag_transformation(transformed_var_orig,
                                                                        int(lag))
                    var_mean = transformed_var_orig.mean()
                    self.model_variable_dict[var].var_mean = var_mean
            
                if halflife != 0:
                    transformed_var_orig = Simulator.halflife_transformation(transformed_var_orig, 
                                                                             halflife)
            
            if self.transformation_method.upper() == 'S_CURVE':
                if (scale != 0) and (inflection != 0):
                    transformed_var_orig_scaled = transformed_var_orig/var_mean
                    saturation_term_orig = scale * (inflection - transformed_var_orig_scaled)
                    scurve_var_orig = 1/(1 + np.exp(saturation_term_orig)) - 1/(1 + np.exp(scale * inflection))
                    scurve_var_orig_mean = scurve_var_orig.mean()
                    self.model_variable_dict[var].s_curve_var_mean = scurve_var_orig_mean
            
            elif self.transformation_method.upper() == 'C_CURVE':
                k_scalar = self.get_k_scalar(var_mean, transformed_var_orig)
                self.model_variable_dict[var].k_scalar = k_scalar
                
           # Step 2. calculate the var_mean, and S_curve_var_mean from the combined_df
            transformed_var = self.combined_df[var].copy()
            
            if self.apply_adstock:
                transformed_var = Simulator.adstock_transformation(transformed_var, 
                                                                   float(lag),
                                                                   float(halflife))
            else:
                if lag != 0:
                    transformed_var = Simulator.lag_transformation(transformed_var, int(lag))
                if halflife != 0:
                    transformed_var = Simulator.halflife_transformation(transformed_var, halflife)
            
            if self.transformation_method.upper() == 'S_CURVE':
                if (scale != 0) and (inflection != 0):
                    transformed_var_scaled = transformed_var / var_mean 
                    saturation_term = scale * (inflection - transformed_var_scaled)
                    scurve_var = 1/(1 + np.exp(saturation_term)) - 1/(1 + np.exp(scale * inflection))
                    transformed_var = scurve_var * var_mean / scurve_var_orig_mean
            
            elif self.transformation_method.upper() == 'C_CURVE':
                
                transformed_var = Simulator.c_curve_transformation(var_mean, k_scalar, transformed_var)
                
            self.simulator_df[self.model_variable_dict[var].model_var_full] = transformed_var.loc[self.simulator_df.index].values
            
            self.prev_df[self.model_variable_dict[var].model_var_full] = transformed_var.loc[self.prev_df.index].values       
    
    # update model_var_dict for final_results for one variable
    def update_per_var_dict(self, var, only_calculate_hist_attributes = False):
        
        if self.model_variable_dict[var].var_source == 'model' and var.startswith('M_'):
            model_var_full = self.model_variable_dict[var].model_var_full
            prev_var_sum = self.prev_df.sum()[model_var_full]
            var_coef = self.model_variable_dict[var].var_coef
            
            # calculate historical attributes 
            prev_total_spend = self.prev_df.sum()[self.model_variable_dict[var].spend_var]
            historical_iroas = float(var_coef * prev_var_sum)/prev_total_spend
            
            # update historical impact, spend, iroas, on_air_days
            self.model_variable_dict[var].historical_impact = var_coef * prev_var_sum
            self.model_variable_dict[var].historical_spend = prev_total_spend
            self.model_variable_dict[var].historical_iroas = historical_iroas
            self.model_variable_dict[var].historical_on_air_days = sum(self.prev_df[var]>0)
        
            # update other historical on_air_days
            hist_less_thresh = (sum(self.prev_df[var] <= self.model_variable_dict[var].threshold_point)/self.prev_days)*100
            hist_more_sat = (sum(self.prev_df[var] >= self.model_variable_dict[var].saturation_point)/self.prev_days)*100
            hist_between = 100 - hist_less_thresh - hist_more_sat 
            self.model_variable_dict[var].pct_historical_days_less_than_threshold = hist_less_thresh
            self.model_variable_dict[var].pct_historical_days_beyond_saturation = hist_more_sat
            self.model_variable_dict[var].pct_historical_days_between_threshold_saturation = hist_between
            
            if not only_calculate_hist_attributes:
                var_sum = self.simulator_df.sum()[model_var_full]
                # calculate current attributes 
                impact_lift = float((var_coef * var_sum)/(var_coef * prev_var_sum) - 1)
                total_spend = self.model_variable_dict[var].total_spend
                iroas = float(var_coef * var_sum)/total_spend
                
                # update current impact, spend, iroas related attributes
                self.model_variable_dict[var].impact = var_coef * var_sum
                self.model_variable_dict[var].impact_lift = impact_lift
                self.model_variable_dict[var].impact_ratio = impact_lift + 1
                self.model_variable_dict[var].spend_ratio =  total_spend / prev_total_spend
                self.model_variable_dict[var].iroas = iroas
                self.model_variable_dict[var].iroas_lift = float(iroas/historical_iroas - 1)
                # update other simulation on_air_days
                less_thresh = (sum(self.simulator_df[var] <= self.model_variable_dict[var].threshold_point)/self.simulation_days)*100
                more_sat = (sum(self.simulator_df[var] >= self.model_variable_dict[var].saturation_point)/self.simulation_days)*100
                in_between = 100 - less_thresh - more_sat
                self.model_variable_dict[var].pct_simulation_days_less_than_threshold = less_thresh
                self.model_variable_dict[var].pct_simulation_days_beyond_saturation = more_sat
                self.model_variable_dict[var].pct_simulation_days_between_threshold_saturation = in_between
      
    # private function: calculate the simulation results for all variables from the model
    def calculate_model_results(self, point_dict):
        file_path = os.path.join(self.result_folder, 'Simulation_Model_Result.xlsx')
        writer = pd.ExcelWriter(file_path, engine = 'xlsxwriter')
        var_result_ls = []
        for var in point_dict: 
            if var not in self.model_variable_dict:
                raise ValueError('{} is not a model variable!'.format(var))
                
            spend_var = self.model_variable_dict[var].spend_var
            if (spend_var not in self.media_spends_dict) and (var not in self.granular_media_dict):
                raise ValueError('{} is not available from media_spends_dict or granular_media_dict!'.format(var))
            
            # re-initiate the dataframes
            self.simulator_df = self.simulator_df_base.copy()
            self.prev_df = self.prev_df_base.copy()
            self.all_df = self.all_df_base.copy()
                
            # update the values from the media_spends_dict to the MODEL_VARIABLE_DICT
            self.update_media_spend_variable_attributes()
            
            # update the values from the granular_media_mapping to the MODEL_VARIABLE_DICT
            self.update_granular_media_variable_attributes()

            # update the on_air_days, daily_metrics for all variables
            self.update_per_var_on_air_days_and_daily_metrics(point_dict, var)

            # get the transform and combined dataframes 
            self.transform_df, self.combined_df = self.get_transform_and_combined_dataframe()

            # update simulator_df, prev_df for all variables
            self.update_per_var_prev_and_simulation_dataframes(var)

            # update the ModelVariable Obj for each variable
            self.update_per_var_dict(var, only_calculate_hist_attributes = False)
            var_result_ls.append(self.model_variable_dict[var].__dict__.copy())
        var_result_df = pd.DataFrame(var_result_ls) 
        var_result_df = var_result_df[[col for col in self.var_result_cols]]
        cols_sum = ['impact', 'historical_impact', 'total_spend',  'historical_spend', 'iroas', 'iroas_lift', 'historical_iroas','daily_spend']
        var_result_overal = var_result_df[cols_sum].sum()
        
        var_result_df = var_result_df.append(var_result_overal, ignore_index = True).fillna(np.nan)
        var_result_df['model_var'].fillna(value = 'Total', inplace = True)
        var_result_df.rename(columns = self.var_result_cols, inplace = True)        
        var_result_df.to_excel(writer, sheet_name = 'Simulation Result', index = False)
        writer.save()
        print('Simulation results save to: {}\n'.format(file_path))
        display(var_result_df)
        return var_result_df
    
    # private function: populate_simulation_dataframe
    def populate_simulation_dataframe(self, point_dict):
        ls = pd.date_range(self.simulation_start_date, self.simulation_end_date, freq = 'd')
        final_simulation_df = pd.DataFrame()
        final_simulation_df['index'] = ls
        final_simulation_df.set_index('index', inplace = True)
        for var in point_dict:
            if var not in self.model_variable_dict:
                raise ValueError('Variable {} not exist in model variable dict!'.format(var))
            if var in self.granular_media_dict:
                comps = self.granular_media_dict[var]
                on_air_days = self.model_variable_dict[var].on_air_days 
                # update the values for the combined variables
                spend_var = self.model_variable_dict[var].spend_var
                rate_var = self.model_variable_dict[var].rate_var
                daily_spend = self.model_variable_dict[var].daily_spend
                daily_metrics = self.model_variable_dict[var].daily_metrics    
                rate = daily_spend/daily_metrics

                # update simulation dataframe
                final_simulation_df.loc[:on_air_days, spend_var] = daily_spend
                final_simulation_df.loc[:on_air_days, var] = daily_metrics
                final_simulation_df[rate_var] = rate
                
                for i in range(len(comps)):
                    comp = comps[i]
                    if comp in self.model_variable_dict:
                        spend_var = self.model_variable_dict[comp].spend_var
                        rate_var = self.model_variable_dict[comp].rate_var
                        total_spend = self.model_variable_dict[comp].total_spend
                        rate = self.model_variable_dict[var].metric_rate[i]
                        rate_unit = self.model_variable_dict[var].rate_unit
                        daily_spend = total_spend/on_air_days
                        daily_metrics = daily_spend/self.model_variable_dict[var].metric_rate[i]
                        if self.is_CPD_variable(rate_unit):
                            rate = daily_spend/daily_metrics
                        # update simulation dataframe
                        final_simulation_df.loc[:on_air_days, spend_var] = daily_spend
                        final_simulation_df.loc[:on_air_days, comp] = daily_metrics
                        final_simulation_df[rate_var] = rate
            else:
                spend_var = self.model_variable_dict[var].spend_var
                daily_spend = self.model_variable_dict[var].daily_spend
                daily_metrics = self.model_variable_dict[var].daily_metrics
                on_air_days = self.model_variable_dict[var].on_air_days
                rate = self.model_variable_dict[var].metric_rate[0]
                rate_var = self.model_variable_dict[var].rate_var
                rate_unit = self.model_variable_dict[var].rate_unit
                if self.is_CPD_variable(rate_unit):
                    rate = daily_spend/daily_metrics
                # update simulation dataframe
                final_simulation_df.loc[:on_air_days, spend_var] = daily_spend
                final_simulation_df.loc[:on_air_days, var] = daily_metrics
                final_simulation_df[rate_var] = rate
        
        final_simulation_df.fillna(0, inplace = True)
        file_path = os.path.join(self.result_folder, 'Simulation_df.csv')
        final_simulation_df.to_csv(file_path)
        print('Populated simulation dataframe save to: {}\n'.format(file_path))
        display(final_simulation_df)
        return final_simulation_df

    # private function: populate_final_updated_stack_dataframe
    def populate_final_updated_stack_dataframe(self, final_simulation_df):

        self.updated_stack_all_cols_df.drop(columns = ['index'], inplace = True)
        final_updated_stack_df = pd.concat([self.updated_stack_all_cols_df[self.updated_stack_all_cols_df.index < self.simulation_start_date_str], final_simulation_df])
        final_updated_stack_df.fillna(0, inplace = True)
        final_updated_stack_df['INTERCEPT_TERM'] = 1.0
        file_path = os.path.join(self.result_folder, 'Updated_Stack_df.csv')
        final_updated_stack_df.to_csv(file_path)
        print('Populated updated stack dataframe save to: {}\n'.format(file_path))
        display(final_updated_stack_df)
        return final_updated_stack_df 
    
    # public function 1: sample the daily metrics between threshold and saturation points
    def sample_daily_metrics(self, num_points):
        recording_start = datetime.now()
        print('start at: {}'.format(recording_start.strftime("%H:%M:%S")))
        file_path = os.path.join(self.result_folder, 'Simulation_Sampling_Result.xlsx')
        writer = pd.ExcelWriter(file_path, engine = 'xlsxwriter')
        for var in self.model_variable_dict: 
            var_result_ls = [] 
            spend_var = self.model_variable_dict[var].spend_var
            if (self.model_variable_dict[var].var_source == 'model') and (spend_var in self.media_spends_dict) or (spend_var in self.granular_media_dict): 
#             self.model_variable_dict[var].var_source == 'model' and var.startswith('M_'):
                print('processing Var: {} ...'.format(var))
                lb = self.s_curve_points['threshold'][var]
                ub = self.s_curve_points['saturation'][var]
                point_dict = {}
                for daily_metric in np.linspace(lb + 1, ub, num_points):
                    point_dict[var] = daily_metric
                    # re-initiate the dataframes
                    self.simulator_df = self.simulator_df_base.copy()
                    self.prev_df = self.prev_df_base.copy()
                    self.all_df = self.all_df_base.copy()
                    
                    # update the values from the media_spends_dict to the MODEL_VARIABLE_DICT
                    self.update_media_spend_variable_attributes()
                    
                    # update the values from the granular_media_mapping to the MODEL_VARIABLE_DICT
                    self.update_granular_media_variable_attributes()            

                    # update the on_air_days, daily_metrics for all variables
                    self.update_per_var_on_air_days_and_daily_metrics(point_dict, var)
                    
                    # get the transform and combined dataframes 
                    self.transform_df, self.combined_df = self.get_transform_and_combined_dataframe()

                    # update simulator_df, prev_df for all variables
                    self.update_per_var_prev_and_simulation_dataframes(var)

                    # update the ModelVariable Obj for each variable
                    self.update_per_var_dict(var, only_calculate_hist_attributes = False)
                    var_result_ls.append(self.model_variable_dict[var].__dict__.copy())
                
                var_result_df = pd.DataFrame(var_result_ls) 
                var_result_df = var_result_df[[col for col in self.var_result_cols]]
                var_result_df.rename(columns = self.var_result_cols, inplace = True)
                var_result_df.to_excel(writer, sheet_name = '{}'.format(var), index = False)
                print('completed!\n')
    
        writer.save()
        recording_time = (datetime.now() - recording_start)
        print('Total processing time: {recording_time} seconds\n'.format(recording_time = recording_time))
        print('Simulation sampling results save to: {}'.format(file_path))
        
    # public function 2: display and save model resutls
    def display_and_save_simulation_results(self, point_dict):
        
        recording_start = datetime.now()
        print('start at: {}'.format(recording_start.strftime("%H:%M:%S")))
        
        # 1. calculate and display model_results
        var_result_df = self.calculate_model_results(point_dict)
        
        # 2. display and export simulaiton dataframe
        final_simulation_df = self.populate_simulation_dataframe(point_dict)
        
        # 3. display and export final updated_stack dataframe 
        self.populate_final_updated_stack_dataframe(final_simulation_df)
        
        recording_time = (datetime.now() - recording_start)
        print('Total processing time: {recording_time} seconds'.format(recording_time = recording_time))
        return var_result_df
        
             
