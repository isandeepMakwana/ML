# -*- coding: utf-8 -*-
"""
Created on Wed Apr 29 14:14:09 2020

@author: rajat.bansal
"""

# -*- coding: utf-8 -*-
"""
Created on Wed Apr 22 17:33:43 2020

@author: rajat.bansal
"""


from custom_variable_transformation import VariableTransformation
from custom_transformation_functions import ccurve_transformation
from custom_mmm_modelling import MMM_Modelling
import pandas as pd
from sklearn.preprocessing import StandardScaler, MinMaxScaler
import statsmodels.api as sm
from scipy.stats.mstats import zscore
from statsmodels.stats.outliers_influence import variance_inflation_factor
from save_excel import SaveExcelTemplated
import numpy as np
from sklearn.metrics import r2_score
from IPython.display import display
import plotly.graph_objects as go
from custom_variable_transformation import VariableTransformation
from custom_transformation_functions import ccurve_transformation
from custom_modelling_plots import ModellingPlots
from custom_waterfall_chart import plot_waterfall
import os
import seaborn as sns
import matplotlib.pyplot as plt
from datetime import datetime
import re
import time


import warnings
warnings.filterwarnings('ignore')

class MMM_Log_Modelling(MMM_Modelling):
    
    def __init__(self, df, target_var, output_path, data_dict, media_hier,
                 modelling_start, modelling_end,
                 validation_start, validiation_end,
                 apply_adstock = False,
                 comment= None):
        
        
        self.modelling_start = modelling_start
        self.modelling_end = modelling_end
        self.validation_start = validation_start
        self.validiation_end = validiation_end
        self.apply_adstock = apply_adstock
        
        super().__init__(df= df, target_var= target_var, 
                               output_path= output_path, data_dict= data_dict, 
                               media_hier= media_hier, apply_adstock = apply_adstock,
                               comment= comment)
        
        self.df_train = self.df[(self.df.index >= self.modelling_start) & (self.df.index <= self.modelling_end)]
        self.df_test = self.df[(self.df.index >= self.validation_start) & (self.df.index <= self.validiation_end)]
        
        self.log_transformed_vars = []
        self.scaled_vars = {}
        
        # Creating log transformation for target variable
        self.create_log_transformations([self.target_var])
        self.target_var = self.target_var + '_LOG'
        
    def get_orig_var(self, var):
        ''' Return the name of original variables and the corresponding transformations applied'''
        
        transf = {}
        pattern = re.match(r"(.*?)_[0-9.]*_[0-9.]*_[0-9.]*_[0-9.]*_[0-9.]", var)
        if pattern:
            transf['Original Variable'] = pattern.group(1)
            transf['Lag'] = int(var.split("_")[-5])
            transf['Halflife'] = int(var.split("_")[-4])
            transf['Inflection'] = float(var.split("_")[-3])
            transf['Scale'] = float(var.split("_")[-2])
            transf['Log'] = int(var.split("_")[-1])
            non_log_pattern = re.match(r"(.*?)_[0-9.]*_[0-9.]*_[0-9.]*_[0-9.]*", var)
            transf['Non-Log Pattern'] = non_log_pattern.group(0) + "_0"
            return transf
        
        else:
            transf['Original Variable'] = var
            transf['Lag'] = 0
            transf['Halflife'] = 0
            transf['Inflection'] = 0
            transf['Scale'] = 0
            transf['Log'] = 0
            transf['Non-Log Pattern'] = var
            return transf
        
        
    
    def create_media_transformations(self, variables, scaling_factor= None):
        
        ''' Function to create missing variable transformations
        Params:
            variables (list) : list of variables with the naming convention for transformations
            variables to be scaled : list of variables to be scaled'''
        
        for var in variables:
            transf = self.get_orig_var(var)
            orig_media_var = transf['Original Variable']
            non_log_var = transf['Non-Log Pattern']
            lag = transf['Lag']
            halflife = transf['Halflife']
            sscurve_inflection = transf['Inflection']
            sscurve_scale = transf['Scale']
            ccurve = transf['Log']
            
            var_trans_obj = VariableTransformation(self.df, None, apply_adstock = self.apply_adstock)
            self.df[non_log_var] = var_trans_obj.apply_media_transformations(var= self.df[orig_media_var],
                                                                          lag= lag, halflife= halflife, 
                                                                          inflection= sscurve_inflection,
                                                                          scale= sscurve_scale, 
                                                                          ccurve_toggle= 0).values
                                                                          
            if scaling_factor:
                self.scaling_factor = scaling_factor
                non_zero_mean = scaling_factor * (self.df[non_log_var][self.df[non_log_var] != 0]).mean()
                self.df[non_log_var + "_Scaled"] = self.df[non_log_var]/non_zero_mean
                self.scaled_vars[var] = (self.df[non_log_var][self.df[non_log_var] != 0]).mean()
            
            if ccurve == 1:
                if scaling_factor:
                    self.df[var] = ccurve_transformation(self.df[non_log_var + "_Scaled"])
                else:
                    self.df[var] = ccurve_transformation(self.df[non_log_var])
                self.log_transformed_vars.append(var)
                
                
                
        self.df_train = self.df[(self.df.index >= self.modelling_start) & (self.df.index <= self.modelling_end)]
        self.df_test = self.df[(self.df.index >= self.validation_start) & (self.df.index <= self.validiation_end)]
        
        
    def create_log_transformations(self, variables):
        ''' List of variables to be transformed. Would create a new variable with _LOG appended to the original name'''
        
        for var in variables:
            self.df[var + '_LOG'] = ccurve_transformation(self.df[var])
            self.log_transformed_vars.append(var + "_LOG")
            
        self.df_train = self.df[(self.df.index >= self.modelling_start) & (self.df.index <= self.modelling_end)]
        self.df_test = self.df[(self.df.index >= self.validation_start) & (self.df.index <= self.validiation_end)]
     
        
    def create_coeff_table(self, dep, indep, model_summary, model):
        
        m_sumry = model_summary
        
        #Calculation of Elasticity
        s1 = pd.DataFrame(indep.sum(),columns=['x_sum'])
        s1['Variables'] = s1.index
        beta = pd.DataFrame(m_sumry['coef'])
        beta['Variables'] = beta.index
        
        s=pd.merge(s1,beta,on = ['Variables'],how='left')
        s['y_sum'] = dep.sum()[0]
        s['Elasticity'] = (s.coef*s.x_sum)/s.y_sum
        
        #Calculation of Coefficient and Signficance 
        m = m_sumry
        m = m.iloc[:,[0,3]]
        m1 = pd.DataFrame(m,columns=['coef','P>|t|']).rename(columns={'P>|t|':'p-value'})
        m1['Significance'] = m1['p-value'].apply(lambda x: (1-x)*100)
        m1['Variables'] = m1.index
        
        m2 = pd.merge(m1,s,on='Variables',how='left')
        m2 = m2.drop(['x_sum','y_sum','coef_y'],axis=1)
        m2 = m2.rename(columns={'coef_x' : 'Coefficient' })
        
        
        for coef, variable in zip(model.params, model.params.index):
            m2.loc[m2.Variables == variable, 'Coefficient'] = coef
        
        #Calculation of Stand Co-efficients and Rel Importance
        z_ip = pd.DataFrame(zscore(indep),columns=indep.columns).fillna(0)
        z_dp = pd.DataFrame(zscore(dep)).fillna(0)
    
        std_coeff_df = self.fit_linear_model(z_dp,z_ip,"Yes").summary()
        std_coeff_df_html = std_coeff_df.tables[1].as_html()
        std_coeff = pd.read_html(std_coeff_df_html,header=0,index_col=0)[0]
        std_coeff = std_coeff.rename(columns={'coef': 'Standardized Coefficient'})
        std_coeff = std_coeff[["Standardized Coefficient"]]
        std_coeff["Variables"] = std_coeff.index
        std_coeff['Standardized Coefficient'] = np.where(std_coeff['Variables']=='const', 0,
                                                         std_coeff['Standardized Coefficient'])
        std_coeff['Sqr_Std_coeff'] = std_coeff['Standardized Coefficient']**2
        std_coeff['Relative Importance'] = std_coeff['Sqr_Std_coeff']/std_coeff['Sqr_Std_coeff'].sum()
        
        m2 = pd.merge(m2,std_coeff,on='Variables',how='left')
        
        #Calculation of VIF
        if (m2.shape[0]!=indep.shape[1]):
            xip = sm.add_constant(indep)
            vif = pd.DataFrame([variance_inflation_factor(xip.values, i) for i in range(xip.shape[1])],index = xip.columns,columns=["VIF"])
            vif["Variables"]=vif.index
        else:
            vif = pd.DataFrame([variance_inflation_factor(indep.values, i) for i in range(indep.shape[1])],index = indep.columns,columns=["VIF"])
            vif["Variables"]=vif.index
        
        #Getting the final Co-efficient table
        Coeff_table_final = pd.merge(m2,vif,on='Variables',how='left')
        Coeff_table_final.index = Coeff_table_final['Variables']
        
        Coeff_table_final['VIF'] = np.where(Coeff_table_final['Variables']=='const', 0, Coeff_table_final['VIF'])
        
        Coeff_table_final=Coeff_table_final.drop(['Variables','Sqr_Std_coeff'],axis=1)
        
        # Updating elasticity for log-log models
        elasticity = []
        for var in Coeff_table_final.index.values:
            coeff = model.params[var]
            if var in self.scaled_vars.keys():
                non_zero_average = self.scaled_vars[var]
                e = coeff * (non_zero_average/(non_zero_average + self.scaling_factor * non_zero_average))
                elasticity.append(e)
            else:
                elasticity.append(coeff)
        Coeff_table_final['Elasticity'] = elasticity
    
        return(Coeff_table_final)
    
    
    def calculate_individual_contribution(self, coef_summ, log_transformed_vars, model,
                                          media_variables,
                                          scaled_vars, df, scaling_factor):
        ''' Function to calculate the contribution of media variables'''
        
        analysis_dict = {'Variable': [], 'y_hat_term': [], 'Coefficient': []}

        # Looping through all the variables associated in the model
        for var in coef_summ.Variables.values:
            var = var.replace('INTERCEPT_TERM', 'const')
            var_coef = model.params[var]
            
            # Variables for which we did log transformation
            if var in log_transformed_vars:
    
                # If scaling was done for the variable
                if var in  scaled_vars.keys():
                    average = scaled_vars[var] # non-zero average
                    k = scaling_factor * average
                    y_hat_term = (1 + (average/k)) ** var_coef
                    
                # For no scaling
                else:
                    orig_var = np.exp(self.df[var])
                    average = orig_var.mean()
                    y_hat_term = (1 + average) ** var_coef
            
            # variables without the log transformation
            else:
                if var == 'const':
                    average = 1 
                else:
                    average = df[var].mean()
                    
                y_hat_term = average * var_coef
                y_hat_term = np.exp(y_hat_term)
                 
            analysis_dict['Variable'].append(var)
            analysis_dict['y_hat_term'].append(y_hat_term)
            analysis_dict['Coefficient'].append(var_coef)
        
        analysis_df = pd.DataFrame(analysis_dict)
        y_hat = analysis_df.y_hat_term.product()
        
        y_hat_base = analysis_df[~ analysis_df.Variable.isin(media_variables)].y_hat_term.product()
        decomp_all = y_hat - y_hat_base
        
        raw_marginal_decompose = []
        for var in analysis_df.Variable:
            other_var_marginal = analysis_df[analysis_df.Variable != var].y_hat_term.product()                                  
            raw_marginal_decompose.append(y_hat - other_var_marginal)
            
        analysis_df['Raw Marginal Decompose'] = raw_marginal_decompose
        
        total_raw_marginal_decompose = analysis_df[analysis_df.Variable.isin(media_variables)]['Raw Marginal Decompose'].sum()
        
        factor = decomp_all/total_raw_marginal_decompose
        
        analysis_df = analysis_df
        analysis_df['Total Contribution'] = factor * analysis_df['Raw Marginal Decompose']
        return analysis_df
       
        
    def calculate_ROAS_stats(self, X_vars, start_date= None, end_date= None, model_type= None):
        ''' Function to calculate ROAS Stats of a model '''
            
        media_variables = [col for col in X_vars if col.startswith('M_')]
        media_spend_mapping, spend_vars = self.get_spend_vars(media_vars= media_variables)
        average_price = self.calculate_price_average(self.df)
                
        if start_date is None:
            df_calc = self.df_train.copy()
        else:
            df_calc = self.df[(self.df.index >= start_date) & (self.df.index <= end_date)].copy()
        
        coef_summ = self.model_dump[model_type]['Coefficient Summary']
        model = self.model_dump[model_type]['Model']
        
        total_contribution = self.calculate_individual_contribution(coef_summ= coef_summ, 
                                                                    log_transformed_vars= self.log_transformed_vars,
                                                                    scaled_vars= self.scaled_vars,
                                                                    df= df_calc,
                                                                    model= model,
                                                                    media_variables= media_variables,
                                                                    scaling_factor= self.scaling_factor)
        total_contribution = total_contribution[['Variable', 'Total Contribution']]
        
        # Spends calculation
        spends_df = df_calc[spend_vars]
        spends_df = pd.DataFrame(spends_df.transpose().sum(axis=1),columns=['Total Spend ($)'])
        spends_df['Variable'] = spends_df.index.map(media_spend_mapping)
        spends_df = spends_df[['Variable', 'Total Spend ($)']]
        
        # ROAS calculation
        df_ROAS_final = pd.merge(spends_df, total_contribution, how='left')
        
        df_ROAS_final[self.ROAS_label] = 100 * df_ROAS_final['Total Contribution']/df_ROAS_final['Total Spend ($)']
        df_ROAS_final[self.ROAS_value_label] = average_price * df_ROAS_final[self.ROAS_label]
        df_ROAS_final = df_ROAS_final.sort_values([self.ROAS_label], ascending = (False)).reset_index(drop= True)
        
        if start_date is None:
            self.model_dump[model_type]['ROAS'] = df_ROAS_final
        
        return df_ROAS_final  

        
    def overall_model_stats(self, model, X_vars, intercept= True, model_type= None):
        '''
        Function to get all the stats relevant to the overall model (i.e. MAPE, R-Square etc)
        '''
        
        if intercept: 
            X_train = sm.add_constant(self.df_train[X_vars], has_constant='add')
            X_test = sm.add_constant(self.df_test[X_vars], has_constant='add')
        else:
            X_train = self.df_train[X_vars].copy()
            X_test = self.df_test[X_vars].copy()
            
        model_act_pred = np.exp(pd.DataFrame(model.predict(X_train), columns=['Predicted']))
        model_act_pred['Actuals'] = self.df_train[self.target_var.replace('_LOG', '')]
        
        self.model_dump[model_type]['Modelling Comparison'] = model_act_pred
    
        ####### MAPE Calculation (Modelling) #######
        perc_error = abs((model_act_pred.Predicted/model_act_pred.Actuals)-1)
        mape = perc_error.mean() * 100
    
        ###### Model fit Calculation (Modelling) ########
        model_stats =  [mape,model.rsquared * 100, model.rsquared_adj * 100,
                        model.aic, model.bic, model.llf]
        model_stats = pd.DataFrame(model_stats,
                                     index=['MAPE','R Square','Adjusted R Sqaure','AIC','BIC', 'Log Likelihood'], 
                                     columns=['Model Fit'])
        
        self.model_dump[model_type]['Modelling Metrics'] = model_stats
        
        model_act_pred = np.exp(pd.DataFrame(model.predict(X_test), columns=['Predicted']))
        model_act_pred['Actuals'] = self.df_test[self.target_var.replace('_LOG', '')]
        
        self.model_dump[model_type]['Validation Comparison'] = model_act_pred
        
        perc_error = abs((model_act_pred.Predicted/model_act_pred.Actuals)-1)
        mape = perc_error.mean() * 100
        r_sq = r2_score(model_act_pred.Actuals, model_act_pred.Predicted) * 100
        
        model_stats['Validation Metrics'] = [mape, r_sq, '', '', '', ''] 
        
        self.model_dump[model_type]['Modelling Stats'] = model_stats
        
        return model_stats
    
    
    def visualize_ROAS(self, model_type, start_date= None, end_date= None, media_level= None, 
                       roas_100_multiplication= True,
                       save_path= None, show_yaxis= True, save_roas_stats= False):
        ''' Function to visualize ROAS
        Params:
            model_type: label for model
            start_date: period for filtering data (default is entire period)
            end_date: period for filtering data (default is entire period)
            media_level: granularity of media to be visualized
            save_path: path to save the model
        '''
        # To display numbers in decimal separated format
        pd.options.display.float_format = '{:20,.1f}'.format
        
        if start_date:
            df = self.df[(self.df.index >= start_date) & (self.df.index <= end_date)].copy()
        else:
            df = self.df.copy()
            
        average_price = self.calculate_price_average(df)
                
        X_vars = self.model_dump[model_type]['Coefficient Summary'].Variables.values
        
        ROAS_output = self.calculate_ROAS_stats(X_vars= X_vars, start_date= start_date, 
                                                end_date= end_date, model_type= model_type)
        
        ROAS_output['Display Level'] = ROAS_output['Variable'].apply(self.get_var_description, 
                                                                args= (media_level,))
        
        ROAS_output = ROAS_output.groupby(['Display Level'])[['Total Contribution', 'Total Spend ($)']].sum().reset_index()
       
        ROAS_output[self.ROAS_label] = 100 * ROAS_output['Total Contribution']/ROAS_output['Total Spend ($)']
        ROAS_output = ROAS_output.sort_values([self.ROAS_label], ascending = False).reset_index()
        ROAS_output[self.ROAS_value_label] = average_price * ROAS_output[self.ROAS_label] 
        
        
        ROAS_output_display = ROAS_output.copy()
        
        ROAS_output_display = ROAS_output_display.drop(columns = 'index')
        
        total_contribution = ROAS_output_display['Total Contribution'].sum()
        total_spend = ROAS_output_display['Total Spend ($)'].sum()
        total_overall = df[self.target_var].sum()
        total_base = df[self.target_var].sum() - total_contribution
        
        ROAS_output_display['Dive (%)'] = 100 * ROAS_output_display['Total Contribution']/total_contribution
        ROAS_output_display = ROAS_output_display[['Display Level', 'Dive (%)', 'Total Contribution', 'Total Spend ($)', self.ROAS_label,
                                                 self.ROAS_value_label]]
  
        ROAS_output_display.loc[ROAS_output_display.shape[0]] = ['Total Incremental', 
                                                                 100 * total_contribution/total_overall,
                                                                 total_contribution, total_spend,
                                                                 100 * total_contribution / total_spend,
                                                                 100 * average_price * total_contribution / total_spend] 
        
        ROAS_output_display.loc[ROAS_output_display.shape[0]] = ['Base', 
                                                                 100 * total_base/total_overall,
                                                                 total_base, 
                                                                 0, 0, 0] 
        
        ROAS_output_display.loc[ROAS_output_display.shape[0]] = ['Total', 
                                                                 100,
                                                                 df[self.target_var].sum(), 
                                                                 total_spend, 
                                                                 0, 0] 
  
        ROAS_output_display['Total Sales ($)'] = ROAS_output_display['Total Contribution'] * average_price
        
        
        ROAS_output_display = ROAS_output_display[['Display Level', 'Dive (%)', 'Total Contribution', 
                                                   'Total Sales ($)', 'Total Spend ($)', 
                                                   self.ROAS_label, self.ROAS_value_label]]
        
        if not roas_100_multiplication:
            ROAS_output_display[self.ROAS_label] = ROAS_output_display[self.ROAS_label]/100
            ROAS_output_display[self.ROAS_value_label] = ROAS_output_display[self.ROAS_value_label]/100
            
            ROAS_output[self.ROAS_label] = ROAS_output[self.ROAS_label]/100
            ROAS_output[self.ROAS_value_label] = ROAS_output[self.ROAS_value_label]/100
            
            
        if save_path == None:
            if roas_100_multiplication:
                display(ROAS_output_display)
            else:
                pd.options.display.float_format = '{:20,.3f}'.format
                display_df = ROAS_output_display.copy()
                display(display_df)
            
        if save_roas_stats:
            return ROAS_output_display
            
        pd.options.display.float_format = '{:20,.5f}'.format
      
        
        bar1 = go.Bar(x= ROAS_output['Display Level'].str.replace(" ", "<br>"), 
                      y= ROAS_output[self.ROAS_value_label], 
                      text = round(ROAS_output[self.ROAS_value_label], 1) if roas_100_multiplication else round(ROAS_output[self.ROAS_value_label], 3),
                      textposition='outside',
                      marker_color= '#0071CE',yaxis='y1',name = self.ROAS_value_label)
                              
        line1 = go.Scatter(x= ROAS_output['Display Level'].str.replace(" ", "<br>"), y= ROAS_output['Total Contribution'],
                           line= dict(color='#041E41'),name='Volume Contribution', yaxis='y2')
                                      
        line2 = go.Scatter(x= ROAS_output['Display Level'].str.replace(" ", "<br>"), y= ROAS_output['Total Spend ($)'],
                           line= dict(color='#FFC220'), name= 'Spend ($)', yaxis='y2')
        data = [line1,line2,bar1]
        
        fig = go.Figure(data)
        
        height= 900
        width= 1000
        
        if ROAS_output.shape[0] <= 4:
            height= 600
            width= 800
        
        fig = self.update_layout(fig, title= self.ROAS_value_label + " by Media Driver",
                                 legend_orientation= 'h', height= height, width= width,
                                 title_x= 0.5, title_y= 0.95, legend_x= 0.25, legend_y= -0.25, 
                                 show_yaxis= show_yaxis, tickangle= 0)
  
        
        if save_path == None:
            fig.show()
        else:
            fig.write_image(save_path + "ROAS Analysis " + "Granularity " + str(media_level) + ".png",
                      width= width, height= height, scale= 5)
        
        self.visualize_incremental_charts(model_type, ROAS_output, df, media_level, save_path= save_path)
