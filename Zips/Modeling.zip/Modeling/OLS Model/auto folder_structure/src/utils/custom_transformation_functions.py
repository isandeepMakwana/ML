# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""
import math
import statsmodels.tsa.filters.filtertools
import numpy as np
import pandas as pd
import statsmodels.api as sm # For linear regression
from scipy.stats import pearsonr
import matplotlib.pyplot as plt


def get_best_lag(df, var, target_var, lag_lower= 0, lag_upper= 14, plot= True):
    lag_corr_df = pd.DataFrame(columns=['Lag','Correlation'])
    
    lag_analysis = pd.DataFrame(columns=['Lag','Coefficient', 'Significance', 'Correlation'])
    
    for lag in range(lag_lower, lag_upper + 1):
            tranf_var = df[var].shift(lag).fillna(0)
            correlation = pearsonr(tranf_var, df[target_var])[0]
            lag_corr_df = lag_corr_df.append({'Lag':lag, 
                                              'Correlation': correlation}, ignore_index=True)
    
            # Calculation of lag visulazation table
            x = sm.add_constant(tranf_var)
            model = sm.OLS(df[target_var], x)
            model = model.fit()
            print(model.pvalues)
            p_val = model.pvalues[1]
            coef = model.params[1]
            lag_analysis = lag_analysis.append({'Lag': lag,
                                                'Coefficient': coef,
                                                'Significance': (1-p_val)*100,
                                                'Correlation': correlation}, ignore_index= True)
            
            
    if plot:
        plt.figure(clear=True)
        plt.plot(lag_corr_df['Lag'], lag_corr_df['Correlation'],'bo-')
        plt.title('Correlation: ' + target_var + ' vs ' + var + ' Lagged Impression')
        plt.xlabel('Lag')
        plt.ylabel('Correlation')
        plt.show()
     
    lag_corr_df_sorted = lag_corr_df.sort_values(by= 'Correlation', ascending= False).reset_index(drop= True)
    lag_analysis = lag_analysis.sort_values(by= 'Correlation', ascending= False).reset_index(drop= True)
    
    return lag_corr_df, lag_corr_df_sorted.head(3)['Lag'].values, lag_analysis


def create_lag_lead(df, variable_name, lag= 0, lead= 0): 
    if lag > 0:
        df[variable_name + "_LAG_"+str(lag)]= df[variable_name].shift(lag).fillna(0)
    elif lead > 0:
        df[variable_name + "_LEAD_"+str(lead)]= df[variable_name].shift(-lead).fillna(0)
    return df


def lag_transformation(var, lag= 1):
    lag_variable = var.shift(lag)
    lag_variable = lag_variable.fillna(0)
    return lag_variable


def halflife_transformation(var, halflife= 1):
    
    retention = np.exp(math.log(0.5)/halflife)        
    transformed_var = var * (1 - retention)
    transformed_var = transformed_var.fillna(0)
    
    transformed_var = statsmodels.tsa.filters.filtertools.recursive_filter(transformed_var, retention)
    return transformed_var


def scurve_transformation(non_transformed_var, transformed_var, scale= 1, inflection= 1):
    var_mean = float(non_transformed_var.mean())
    transformed_var_scaled = transformed_var/var_mean

    saturation_term = scale * (inflection - transformed_var_scaled)

    scurve_var = 1/(1+np.exp(saturation_term))-1/(1+np.exp(scale * inflection))
    scurve_var = scurve_var * var_mean / scurve_var.mean()
    return scurve_var


def ccurve_transformation(var,ccurve = 1.0):
    return var.apply(lambda x : math.log(x/ccurve + 1.0))

# In the time dimension, create a delayed-decayed response
def adstock(t, pk, hf):
    '''t -- time in days
       parameters:
       peak: the function will peak after "peak" days
       halflife: the function decays with half life of "halflife" days
       
       return: the adstock function peaking at "peak" and decaying with "halflife"
    '''
    
    # pk >= 0; hf>=0; t>=0
    #  f(t)  = ((t/hf)**(pk/hf)) * exp(- t/hf)
    
    if hf <= 0.1: 
        # the shifted response
        y = 1.0 * ((t>= pk) & (t < (pk + 1.0)))
    else:
        ln2 = np.log(2.0)
        t1 = t/hf
        if (pk <= 0.1):
            # a decaying response
            y = np.exp(- t1 * ln2)
        else:
            # an adstocking and decaying response
            pk0 = 10.0 * pk/hf
            t2 = t1 * (t1 <= pk0) + pk0 * (t1 > pk0)
            y = (t2 ** (pk * ln2/hf)) * np.exp(- t1 * ln2)
        
    return y/sum(y)


def adstock_transformation(x, peak = 1.0, halflife = 1.0, n_step = 10):
    '''adstrock transformation convolved with a response window size limit of 350 days'''
    global n_adstock
    
    max_window = 350
    n0 = x.shape[0]
    if n_step <= 5:
        n_step = 5
    ndim = np.min([n0, max_window])
    time_val = pd.Series(range(ndim * n_step))*1.0/n_step
    p = adstock(time_val, peak, halflife)
    p = np.reshape(list(p), (ndim, -1))
    p = np.sum(p, axis = 1)
    var = np.convolve(x, p, mode='full')
    var_out = pd.Series(data = var[:n0], index = x.index)
        
    return var_out


def find_best_var_transformation(target_var_series, var_transformations, seasonality_var_series= None, intercept= True,
                                 mape= True, pval= True, corr= True, aic= True, r_sq= True, r_sq_adj= True, bic= True,
                                 positive_coef_only= False):
    
    transf_metric_dict = {'Variable Transformation':[], 'MAPE': [],
                          'P-Val': [], 'Correlation': [], 'AIC': [],
                          'R-Squared': [], 'R-Squared Adjusted': [],
                          'BIC': []}
    
    if positive_coef_only:
        transf_metric_dict = {'Variable Transformation':[], 'MAPE': [],
                              'P-Val': [], 'Correlation': [], 'AIC': [],
                              'R-Squared': [], 'R-Squared Adjusted': [],
                              'BIC': [], 'Coefficient': []}
    
    # Looping through each transformation
    for col in var_transformations.columns:
        
        transf_metric_dict['Variable Transformation'].append(col)
    
        indep_var = var_transformations[col]  # Independent variable
        dep_var = target_var_series.values  # Dependent Variable
        x = indep_var.copy()
        
        # Adding seasoanlity variable to the independent variable
        if seasonality_var_series is not None:
            x = pd.concat([x, seasonality_var_series], axis= 1)
        
        if intercept:
            x = sm.add_constant(x, has_constant='add')
        
        # Fitting the linear regression model
        model = sm.OLS(dep_var, x)
        model = model.fit()
        
        
        # p-value
        if intercept:
            p_val = model.pvalues[1]
            coef = model.params[1]
        else:
            p_val = model.pvalues[0]
            coef = model.params[0]
        
        transf_metric_dict['AIC'].append(model.aic)
        transf_metric_dict['BIC'].append(model.bic)
        transf_metric_dict['Correlation'].append(pearsonr(dep_var, indep_var)[0])
        transf_metric_dict['MAPE'].append(abs((model.predict(x)/dep_var)-1).mean() * 100)
        transf_metric_dict['P-Val'].append(p_val)
        transf_metric_dict['R-Squared'].append(model.rsquared * 100)
        transf_metric_dict['R-Squared Adjusted'].append(model.rsquared_adj * 100)
        
        if positive_coef_only:
            transf_metric_dict['Coefficient'].append(coef)

    transf_metric_df = pd.DataFrame(transf_metric_dict)
    
    if positive_coef_only:
        # There should be atleast one data point with positive coeficient
        if transf_metric_df[transf_metric_df['Coefficient'] > 0].reset_index(drop= True).shape[0] > 1:
            	transf_metric_df = transf_metric_df[transf_metric_df['Coefficient'] > 0].reset_index(drop= True)
    
    all_rank_cols = []
    for col in transf_metric_df.columns:
        if col in ('Variable Transformation', 'Coefficient'):
            continue
        if col in ['MAPE', 'AIC', 'P-Val', 'BIC']:
            transf_metric_df["Rank" + " : " + col] = transf_metric_df[col].rank()
        else:
            transf_metric_df["Rank" + " : " + col] = transf_metric_df[col].rank(ascending=False)
            
        if col == 'MAPE' and mape:
            all_rank_cols.append("Rank" + " : " + col)
        elif col == 'AIC' and aic:
            all_rank_cols.append("Rank" + " : " + col)
        elif col == 'BIC' and bic:
            all_rank_cols.append("Rank" + " : " + col)
        elif col == 'Correlation' and corr:
            all_rank_cols.append("Rank" + " : " + col)
        elif col == 'P-Val' and pval:
            all_rank_cols.append("Rank" + " : " + col)
        elif col == 'R-Squared' and r_sq:
            all_rank_cols.append("Rank" + " : " + col)
        elif col == 'R-Squared Adjusted' and r_sq_adj:
            all_rank_cols.append("Rank" + " : " + col)
        
    transf_metric_df['Sum Ranks'] = transf_metric_df.loc[:, all_rank_cols].sum(axis=1)
    transf_metric_df = transf_metric_df.sort_values(by= 'Sum Ranks').reset_index(drop= True)
    
    transf_metric_df['Final Rank'] = transf_metric_df['Sum Ranks'].rank(method= 'dense')

    return transf_metric_df.head(100)

def find_best_var_transformation_media(target_var_series, var_transformations,
                                       seasonality_var_series= None, intercept= True):
    

    
    transf_metric_dict = {'Variable Transformation':[], 'Coefficient': [],
                          'P-Val': [], 'Correlation': [], 'AIC': [],
                          'R-Squared': [], 'R-Squared Adjusted': [],
                          'BIC': [], 'MAPE': []}
    
    # Looping through each transformation
    for col in var_transformations.keys():

        transf_metric_dict['Variable Transformation'].append(col)
    
        indep_var = var_transformations[col]  # Independent variable
        dep_var = target_var_series  # Dependent Variable
        x = pd.Series(indep_var.copy())
        # Adding seasoanlity variable to the independent variable
        if seasonality_var_series is not None:
            x.index=seasonality_var_series.index
            x = pd.concat([x, seasonality_var_series], axis= 1)
        
        if intercept:
            x = sm.add_constant(x, has_constant='add')
        
        # Fitting the linear regression model
        model = sm.OLS(dep_var, x)
        model = model.fit()
        
        
        # p-value
        if intercept:
            p_val = model.pvalues.iloc[1]
            coef = model.params.iloc[1]
        else:
            p_val = model.pvalues.iloc[0]
            coef = model.params.iloc[0]
        
        transf_metric_dict['AIC'].append(model.aic)
        transf_metric_dict['BIC'].append(model.bic)
        transf_metric_dict['Correlation'].append(pearsonr(dep_var, indep_var)[0])
        transf_metric_dict['MAPE'].append(abs((model.predict(x)/dep_var)-1).mean() * 100)
        transf_metric_dict['P-Val'].append(p_val)
        transf_metric_dict['R-Squared'].append(model.rsquared * 100)
        transf_metric_dict['R-Squared Adjusted'].append(model.rsquared_adj * 100)
        transf_metric_dict['Coefficient'].append(coef)

    transf_metric_df = pd.DataFrame(transf_metric_dict)
    
    
    # Separating out positive and negative coefficients
    transf_metric_df_pos = transf_metric_df[transf_metric_df['Coefficient'] > 0].reset_index(drop= True)
    transf_metric_df_neg = transf_metric_df[transf_metric_df['Coefficient'] <= 0].reset_index(drop= True)
    
    # Ranking of positive coefficients
    transf_metric_df_pos['Rank : P-Val'] = transf_metric_df_pos['P-Val'].rank(method= 'dense')
    
    # Ranking of negative coeffients 
    transf_metric_df_neg['Rank : P-Val'] = transf_metric_df_neg['P-Val'].rank(ascending= False, method= 'dense')
    transf_metric_df_neg['Rank : P-Val'] = transf_metric_df_neg['Rank : P-Val'] + transf_metric_df_pos.shape[0]
    
    df_final = pd.concat([transf_metric_df_pos, transf_metric_df_neg], axis= 0).reset_index(drop= True)
    df_final['Final Rank'] = df_final['Rank : P-Val']
    df_final = df_final.sort_values(by= 'Final Rank').reset_index(drop= True)
    return df_final.head(100)





