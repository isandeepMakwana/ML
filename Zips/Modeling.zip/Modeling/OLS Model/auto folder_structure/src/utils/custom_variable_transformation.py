# -*- coding: utf-8 -*-
"""
Created on Tue Apr 14 15:35:30 2020

@author: rajat.bansal
"""

from custom_transformation_functions import lag_transformation, halflife_transformation, adstock_transformation
from custom_transformation_functions import scurve_transformation, ccurve_transformation
from custom_transformation_functions import find_best_var_transformation_media, get_best_lag
from save_excel import SaveExcelTemplated

import numpy as np
import pandas as pd
import itertools
import plotly.graph_objects as go
import seaborn as sns
import os
import matplotlib.pyplot as plt
import matplotlib as mpl


def generate_var_dict(x, var_type, media_hierarchy, components, metric, product_type, data_dict):
    '''Function to create additional variables for media hierarchy
    Params:
        x: new variable created
        var_type: Variable Type
        media_hierarchy: media hierarchy level of the variable
        components: components that add up to form x
        metric: impressions/viewable impressions/clicks
        product_type: product type'''
        
    df_dict = {}
    for col in data_dict.columns:
        df_dict[col] = []
    
    # variable should not be already present in the data dictionary
    if x in data_dict['Variable Name'].values:
        return None
    
    df_dict['Variable Name'].append(x)
    df_dict['Variable Type'].append(var_type)
    df_dict['Media Hierarchy'].append(media_hierarchy)
    df_dict['Product Type'].append(product_type)
    
    tactic = ''
    for comp in components:
        tactic += data_dict[data_dict['Variable Name'] == comp]['Tactic'].values[0]
        tactic += ", "
    tactic = tactic[:-2]
    df_dict['Tactic'].append(tactic)
    df_dict['Metric'].append(metric)
    
    var_desc = product_type + " " + tactic + " " + metric
    df_dict['Variable Description'].append(var_desc)
    
    for col in data_dict.columns:
        if len(df_dict[col]) == 0:
            df_dict[col] = ['']
            
    return pd.DataFrame(df_dict)
    

def create_media_hierarchy(new_var_dict, df, media_dictionary, data_dict, media_hierarchy,
                           var_type, media_hierarchy_level, product_type):
    
    final_output = {}
    data_dict_final = data_dict.copy()
    
    added_media_vars = []
    for key, value in new_var_dict.items():
        # new variable creation
        df[key] = df[value].sum(axis= 1)
        added_media_vars.append(key)
        
        data_dict_new_row = generate_var_dict(x= key, var_type= var_type, media_hierarchy= media_hierarchy_level, 
                                              components= value, metric= media_dictionary['IMP'], 
                                              product_type= product_type, data_dict= data_dict)
        data_dict_final = pd.concat([data_dict_final, data_dict_new_row], axis= 0)
        
        # corresponding variable creation for spends. original media_hierarchy should be for IMP
        for media_var in media_dictionary.keys():
            if media_var == 'IMP':
                continue
            # new columns for other media metrics
            media_key = key.replace('IMP', media_var)
            media_value = [var.replace('IMP', media_var) for var in value].copy()
            df[media_key] = df[media_value].sum(axis= 1)
            added_media_vars.append(media_key)
            
            data_dict_new_row = generate_var_dict(x= media_key, var_type= var_type, 
                                                  media_hierarchy= media_hierarchy_level, 
                                                  components= media_value, metric= media_dictionary[media_var], 
                                                  product_type= product_type, data_dict= data_dict)
            data_dict_final = pd.concat([data_dict_final, data_dict_new_row], axis= 0)
        
        # contributor variable (can choose any contributor variable)
        # assumption: variable would have media hierarchy similar to its contributor
        cont_var = value[0]
        
        # media hierarchy of the variable
        media_hier_var = {'Variable' : [key]}
        
        if key not in media_hierarchy.Variable.values:  # variable is missing in the original media hierarchy
            for i in range(3, 7):  # hierarchy from 3 to 6
                col = 'Hierarchy ' + str(i)  
                
                # Hierarchy of the contributor variable
                cont_var_col = media_hierarchy[media_hierarchy.Variable == cont_var][col].values[0]
                
                # If the contributor variable itself if present at particular level
                if cont_var_col == cont_var:
                    media_hier_var[col] = [key]
                else:
                    media_hier_var[col] = [cont_var_col]
                
            media_hierarchy = pd.concat([media_hierarchy, pd.DataFrame(media_hier_var)], axis= 0)
         
    
    final_output['Created Variables'] = added_media_vars
    final_output['Dataframe'] = df
    final_output['Updated Media Hierarchy'] = media_hierarchy
    final_output['Updated Data Dictionary'] = data_dict_final
    return final_output
    
            

def get_same_granularity_vars(data_dict, orig_var= None, media_granularity= None):
    if orig_var:
        var_granularity = data_dict[data_dict['Variable Name'] == orig_var]['Media Hierarchy'].values[0]
    
    if media_granularity:
        var_granularity = media_granularity
    
    
    # Filtering the variables on basis of same granualrity
    sponsored_filter = ((data_dict['Media Hierarchy'] == var_granularity) & 
                ((data_dict['Variable Name'].str.startswith('M_SP')) | 
                 (data_dict['Variable Name'].str.startswith('M_TOTAL_MEDIA'))))

    onsite_filter = ((data_dict['Media Hierarchy'] == var_granularity) &
                 ((data_dict['Variable Name'].str.startswith('M_ON')) | (data_dict['Variable Name'].str.startswith('M_TOTAL'))))
    
    offsite_filter = ((data_dict['Media Hierarchy'] == var_granularity) & 
                  ((data_dict['Variable Name'].str.startswith('M_OFF')) | (data_dict['Variable Name'].str.startswith('M_FB')) |
                  (data_dict['Variable Name'].str.startswith('M_PIN')) | (data_dict['Variable Name'].str.startswith('M_TOTAL'))))
    
    
    media_filter = sponsored_filter | onsite_filter | offsite_filter
    input_var_media_df_gran = data_dict[media_filter] 
    
    input_var_media_df_gran = input_var_media_df_gran[~ input_var_media_df_gran['Variable Name'].str.startswith('M_ON_DIS_OTHERS')]
    
    
    # Additional variable addition
    # Handling of Sponsored Products
    if var_granularity in [5, 6]:
        df_add = data_dict[(data_dict['Variable Name'].str.startswith('M_SP_')) & (data_dict['Media Hierarchy'] == 4)]
        input_var_media_df_gran = pd.concat([input_var_media_df_gran, df_add], axis= 0).reset_index(drop= True)
    
    
    # Handling of Onsite Display
    if var_granularity == 6:
        df_add = data_dict[(data_dict['Variable Name'].str.startswith('M_ON_DIS_CT_')) | (data_dict['Variable Name'].str.startswith('M_ON_DIS_HPLO')) |
                (data_dict['Variable Name'].str.startswith('M_ON_DIS_SEA')) | (data_dict['Variable Name'].str.startswith('M_ON_DIS_ROS'))]
        input_var_media_df_gran = pd.concat([input_var_media_df_gran, df_add], axis= 0).reset_index(drop= True)
    
    
    # Handling of Offsite Display
    if var_granularity == 6:
        df_add = data_dict[(data_dict['Variable Name'].str.startswith('M_OFF_')) & (data_dict['Media Hierarchy'] == 5) &
                 (~ data_dict['Variable Name'].str.startswith('M_OFF_DIS_SMEDIA_'))]
        input_var_media_df_gran = pd.concat([input_var_media_df_gran, df_add], axis= 0).reset_index(drop= True)
        
    return list(input_var_media_df_gran['Variable Name'])
    
    
    
    

def final_variable_selection(folder, file_dict, media_path, data_dict, price_var, 
                             new_var_dict= {}, include_new_aggregated_vars= False):
    
    final_df_dict = {}
    
    df_sheet_1 = pd.DataFrame()
    for key, value in file_dict.items():
        df_file = pd.read_excel(os.path.abspath(folder + value[0]), sheet_name= value[1])
        if value[2] == 'all':
            pass
        else:
            df_file = df_file.head(int(value[2]))
        df_file['Variable Type'] = key
        
        df_file = df_file[['Variable Type', 'Variable Transformation']]
        df_file.columns = ['Variable Type', 'Variable']
        df_sheet_1 = pd.concat([df_sheet_1, df_file], axis= 0).reset_index(drop= True)
        
        
        
    df_sheet_1.loc[df_sheet_1.shape[0]] = ['Price', price_var] 
    
    final_df_dict['Non-Media Variables'] = df_sheet_1
    
    # Sheet 2 preparation
    df_sheet_2 = pd.read_excel(os.path.abspath(media_path), sheet_name = 'All Variables')
    
    # Handling of media variables
    df_sheet_2 = df_sheet_2.merge(data_dict[['Variable Name', 'Variable Description', 'Media Hierarchy']], 
                                  left_on = 'Variable', right_on= 'Variable Name', how= 'left').fillna(0)
    
    df_sheet_2['Variable Transformation'] = df_sheet_2['Variable'] + "_" + \
    df_sheet_2['Lag'].astype(int).astype(str) + "_" + df_sheet_2['Halflife'].astype(int).astype(str) + "_" + \
    df_sheet_2['SCurve-Inflection'].astype(str) + "_" + df_sheet_2['SCurve-Scale'].astype(str) + "_" + \
    df_sheet_2['C-Curve'].astype(int).astype(str)
    
    df_sheet_2 = df_sheet_2[['Variable', 'Variable Transformation', 'Variable Description', 
                             'Media Hierarchy', 'Coefficient']]
    
    df_sheet_2 = df_sheet_2[~ df_sheet_2.Variable.str.startswith('M_ON_DIS_OTHERS_')]
    
    if len(new_var_dict) > 0:
        vars_removed = []
        
        if include_new_aggregated_vars:
            for var in new_var_dict.values():
                vars_removed = vars_removed + var
                vars_removed = vars_removed + [col.replace('IMP', 'SPEND') for col in var]
                vars_removed = vars_removed + [col.replace('IMP', 'VIEW_IMP') for col in var]
                vars_removed = vars_removed + [col.replace('IMP', 'CLK') for col in var]
        else:
            for var in new_var_dict.keys():
                vars_removed.append(var)
                vars_removed.append(var.replace('IMP', 'SPEND'))
                vars_removed.append(var.replace('IMP', 'VIEW_IMP'))
                vars_removed.append(var.replace('IMP', 'CLK'))
            
        df_sheet_2 = df_sheet_2[~ df_sheet_2.Variable.isin(vars_removed)]
    
    
    # Selection of media granularity
    
    # Onsite would always be at level 5
    df_sheet_2_onsite = df_sheet_2[(df_sheet_2.Variable.str.startswith('M_ON_')) & 
                                   (df_sheet_2['Media Hierarchy'] == 5)]
    
    if df_sheet_2_onsite.shape[0] == 0:
        df_sheet_2_onsite = df_sheet_2[df_sheet_2.Variable.str.startswith('M_ON_')]
    
    # Sponsored Products
    df_sheet_2_sp_level_4 = df_sheet_2[(df_sheet_2.Variable.str.startswith('M_SP_')) & 
                                      (df_sheet_2['Media Hierarchy'] == 4)]
    
    df_sheet_2_sp_level_3 = df_sheet_2[(df_sheet_2.Variable.str.startswith('M_SP_')) & 
                                      (df_sheet_2['Media Hierarchy'] == 3)]
    
    
    if df_sheet_2_sp_level_4[df_sheet_2_sp_level_4['Coefficient'] < 0].shape[0] > 1: # If level 4 has any negative coefficient
        df_sheet_2_sponsored = df_sheet_2_sp_level_3
    else:
        df_sheet_2_sponsored = df_sheet_2_sp_level_4
    
    if df_sheet_2_sponsored.shape[0] == 0:
        df_sheet_2_sponsored = df_sheet_2_sp_level_3
        
        
    # Offsite Products
    df_sheet_2_offsite_level_6 = df_sheet_2[ (~ df_sheet_2.Variable.str.startswith('M_OFF_DIS_SMEDIA')) & 
                                            (df_sheet_2['Media Hierarchy'] >= 5) &
                                            (~ df_sheet_2.Variable.str.startswith('M_ON')) &
                                            (~ df_sheet_2.Variable.str.startswith('M_SP'))]
    
    df_sheet_2_offsite_level_5 = df_sheet_2[(df_sheet_2.Variable.str.startswith('M_OFF_')) & 
                                   (df_sheet_2['Media Hierarchy'] == 5)]
    
    df_sheet_2_offsite_level_4 = df_sheet_2[(df_sheet_2.Variable.str.startswith('M_OFF_')) & 
                                   (df_sheet_2['Media Hierarchy'] == 4)]
    
    if df_sheet_2_offsite_level_6[df_sheet_2_offsite_level_6['Coefficient'] < 0].shape[0] > 0: # Level 6 has negative coeff
        if df_sheet_2_offsite_level_5[df_sheet_2_offsite_level_5['Coefficient'] < 0].shape[0] > 0: # Level 5 has negative coeff
            df_sheet_2_offsite = df_sheet_2_offsite_level_4
        else:
            df_sheet_2_offsite = df_sheet_2_offsite_level_5
    else:
        df_sheet_2_offsite = df_sheet_2_offsite_level_6
        
    if df_sheet_2_offsite.shape[0] == 0:
        df_sheet_2_offsite = df_sheet_2_offsite_level_6
        if df_sheet_2_offsite.shape[0] == 0:
            df_sheet_2_offsite = df_sheet_2_offsite_level_5
            if df_sheet_2_offsite.shape[0] == 0:
                df_sheet_2_offsite = df_sheet_2_offsite_level_4
    
    df_sheet_2 = pd.concat([df_sheet_2_onsite, df_sheet_2_sponsored, df_sheet_2_offsite], axis= 0)
    df_sheet_2 = df_sheet_2[['Variable', 'Variable Transformation', 'Variable Description', 'Media Hierarchy']]
    
    final_df_dict['Media Transformations - 1'] = df_sheet_2
    
    df_sheet_3_concat = pd.DataFrame(columns= ['Variable', 'Variable Transformation', 'Variable Description', 'Media Hierarchy'])
    # Sheet 3 preparation
    for counter, var in enumerate(df_sheet_2['Variable'].values):
        df_sheet_3 = pd.read_excel(os.path.abspath(media_path), sheet_name = var).iloc[1:2, 0:6]
        
        df_sheet_3 = df_sheet_3.merge(data_dict[['Variable Name', 'Variable Description', 'Media Hierarchy']], 
                              left_on = 'Variable', right_on= 'Variable Name', how= 'left').fillna(0)
        
        df_sheet_3['Variable Transformation'] = df_sheet_3['Variable'] + "_" + \
            df_sheet_3['Lag'].astype(int).astype(str) + "_" + df_sheet_3['Halflife'].astype(int).astype(str) + "_" + \
            df_sheet_3['SCurve-Inflection'].astype(str) + "_" + df_sheet_3['SCurve-Scale'].astype(str) + "_" + \
            df_sheet_3['C-Curve'].astype(int).astype(str)
    
        df_sheet_3 = df_sheet_3[['Variable', 'Variable Transformation', 'Variable Description', 'Media Hierarchy']]
        
        df_sheet_3_concat = pd.concat([df_sheet_3_concat, df_sheet_3], axis= 0)
        
    final_df_dict['Media Transformations - 2'] = df_sheet_3_concat
        
    df_sheet_4_concat = pd.DataFrame(columns= ['Variable', 'Variable Transformation', 'Variable Description', 'Media Hierarchy'])
    # Sheet 4 preparation
    for counter, var in enumerate(df_sheet_2['Variable'].values):
        df_sheet_4 = pd.read_excel(os.path.abspath(media_path), sheet_name = var).iloc[2:3, 0:6]
        
        df_sheet_4 = df_sheet_4.merge(data_dict[['Variable Name', 'Variable Description', 'Media Hierarchy']], 
                              left_on = 'Variable', right_on= 'Variable Name', how= 'left').fillna(0)
        
        df_sheet_4['Variable Transformation'] = df_sheet_4['Variable'] + "_" + \
            df_sheet_4['Lag'].astype(int).astype(str) + "_" + df_sheet_4['Halflife'].astype(int).astype(str) + "_" + \
            df_sheet_4['SCurve-Inflection'].astype(str) + "_" + df_sheet_4['SCurve-Scale'].astype(str) + "_" + \
            df_sheet_4['C-Curve'].astype(int).astype(str)
    
        df_sheet_4 = df_sheet_4[['Variable', 'Variable Transformation', 'Variable Description', 'Media Hierarchy']]
        
        df_sheet_4_concat = pd.concat([df_sheet_4_concat, df_sheet_4], axis= 0)
        
    final_df_dict['Media Transformations - 3'] = df_sheet_4_concat
        
    
    return final_df_dict



class VariableTransformation:
    
    def __init__(self, df, data_dict= None, lag_lower= 0, lag_upper= 14, halflife_lower= 0, halflife_upper= 14, 
                 scale_lower= 0, scale_upper= 12, inflection_lower= 0, inflection_upper= 12,
                 max_sponsored_lag= 4, lag_toggle= True, halflife_toggle= True, 
                 scurve_toggle= True, ccurve_toggle= False, apply_adstock = False):
        
        self.df = df
        self.data_dict = data_dict
        self.transformation_matrix = None
        self.var_transformations = None
        self.variable = None
        self.all_variable_rankings = {}
        self.seasonality_series = None
        
        self.lag_lower = lag_lower
        self.lag_upper = lag_upper
        self.halflife_lower = halflife_lower
        self.halflife_upper = halflife_upper
        self.scale_lower = scale_lower
        self.scale_upper = scale_upper
        self.inflection_lower = inflection_lower
        self.inflection_upper = inflection_upper
        self.max_sponsored_lag = max_sponsored_lag
        self.lag_toggle = lag_toggle
        self.halflife_toggle = halflife_toggle
        self.scurve_toggle = scurve_toggle
        self.ccurve_toggle = ccurve_toggle
        self.apply_adstock = apply_adstock
        
        self.best_lag_dict = {}
        self.final_ranking_df = None
        self.best_lag = None
        
        self.var_lag_analysis = {}
        
    def apply_media_transformations(self, var, lag, halflife, inflection, scale, lag_toggle= True,
                                    halflife_toggle= True, scurve_toggle= True, ccurve_toggle= False):
    
        
        self.current_lag = lag
        self.current_halflife = halflife
        self.current_scale = scale
        self.current_inflection = inflection
        self.current_lag_toggle = lag_toggle
        self.current_halflife_toggle = halflife_toggle
        self.current_scurve_toggle = scurve_toggle
        self.current_ccurve_toggle = ccurve_toggle
        
        transformed_var = var.copy()
        var_for_mean = var.copy()
        
        if(self.apply_adstock == False):
            if (lag != 0) and (lag_toggle) and (lag is not None): 
                transformed_var = lag_transformation(transformed_var, int(lag))
                var_for_mean = transformed_var.copy()

            if (halflife != 0) and (halflife_toggle) and (halflife is not None):
                transformed_var = halflife_transformation(transformed_var, halflife)
        else:
            if ((lag != 0) and (lag_toggle) and (lag is not None)) or ((halflife != 0) and (halflife_toggle) and (halflife is not None)): 
                transformed_var = adstock_transformation(transformed_var, peak = float(lag), halflife = float(halflife))
            

        if (scurve_toggle) and (scale is not None) and (scale != 0) and (inflection != 0):
            transformed_var = scurve_transformation(var_for_mean, transformed_var, scale, inflection)
           
        if (ccurve_toggle != 0) and (ccurve_toggle is not None) and (ccurve_toggle is not False):
            transformed_var = ccurve_transformation(transformed_var)
            
        return transformed_var
    
    def create_media_transformation_matrix(self):
            
        # Creating all possible values from the given range
        # Range of 1-4 would create [1,2,3,4]
        lag_list = self.best_lag
        halflife_list = np.arange(self.halflife_lower, self.halflife_upper + 1)
        scale_list = np.arange(self.scale_lower, self.scale_upper + 0.5, 0.5)
        inflection_list = np.arange(self.inflection_lower, self.inflection_upper + 0.5, 0.5)
        ccurve_list = [0, 1]
            
        # Toggle for Lag and Half-life
        if not self.lag_toggle : lag_list = [None]
        if not self.halflife_toggle : halflife_list = [None]
        
        # If both S-Curce and C-Curve are set to True, then both will run in different iterations
        if self.scurve_toggle & self.ccurve_toggle:
            
            ccurve_list = [None]  # Iteration for S-Curve
        
            all_lists = [lag_list, halflife_list, scale_list, inflection_list, ccurve_list]
            final_df_1 = pd.DataFrame(list(itertools.product(*all_lists)))
            final_df_1.columns = ['Lag', 'Halflife', 'SCurve-Scale', 'SCurve-Inflection', 'C-Curve']
            
            
            scale_list, inflection_list = [0], [None]  # Iteration for C-Curve
            ccurve_list = [1]
            
            all_lists = [lag_list, halflife_list, scale_list, inflection_list, ccurve_list]
            final_df_2 = pd.DataFrame(list(itertools.product(*all_lists)))
            final_df_2.columns = ['Lag', 'Halflife', 'SCurve-Scale', 'SCurve-Inflection', 'C-Curve']
            
            final_df = pd.concat([final_df_1, final_df_2], axis= 0).reset_index(drop= True)
        
        # If only one of S-Curve or C-Curve is True
        else:
            if not self.scurve_toggle : scale_list, inflection_list = [None], [None]
            if not self.ccurve_toggle : ccurve_list = [None]
            
            all_lists = [lag_list, halflife_list, scale_list, inflection_list, ccurve_list]
    
            final_df = pd.DataFrame(list(itertools.product(*all_lists)))
            final_df.columns = ['Lag', 'Halflife', 'SCurve-Scale', 'SCurve-Inflection', 'C-Curve']
        
        final_df = final_df[final_df['Lag'] >= final_df['Halflife']].reset_index(drop= True)
        
        final_df['Identifier'] = final_df.index.values + 1

        
        self.transformation_matrix = final_df
        return final_df
    
    def create_all_transformations(self):
        
        
        variable = self.df[self.variable]
        df_all_transformations_var = pd.DataFrame()
        
        self.create_media_transformation_matrix()
                
        df_all_transformations_var['Variable Original : 0'] = variable
                                                                
        print('Total Transformations', self.transformation_matrix.shape[0])                                        
        for i in range(0, self.transformation_matrix.shape[0]):
            transformed_var = self.apply_media_transformations(variable, lag= self.transformation_matrix.loc[i,'Lag'], 
                                                             halflife= self.transformation_matrix.loc[i,'Halflife'],
                                                             inflection= self.transformation_matrix.loc[i, 'SCurve-Inflection'],
                                                             scale= self.transformation_matrix.loc[i, 'SCurve-Scale'],
                                                             ccurve_toggle= self.transformation_matrix.loc[i, 'C-Curve'])

            df_all_transformations_var['Variable Transformed : ' + str(i+1)] = transformed_var.values
            
        self.var_transformations = df_all_transformations_var
        return df_all_transformations_var
    
    
#    def create_all_transformations_optimized(self, var):
#        
#        self.variable = var
#        variable = self.df[var]
#                
#        df_all_transformations_var = self.transformation_matrix.apply(lambda x : self.apply_media_transformations(variable, 
#                                                                                      lag= x[0], halflife= x[1], 
#                                                                                      inflection= x[3], 
#                                                                                      scale= x[2],
#                                                                                      ccurve_toggle = x[4]), axis =1).T
#                                                                                                                  
#        df_all_transformations_var.columns = ['Variable Transformed : ' + str(col+1) for 
#                                              col in df_all_transformations_var.columns] 
#        df_all_transformations_var['Variable Original : 0'] = variable
#                                                                                                        
#            
#        self.var_transformations = df_all_transformations_var
#        return df_all_transformations_var
    
    
    
    def rank_variable_transformation(self, target_var, seasonality_var= None, intercept= True,
                                     mape= True, pval= True, corr= True, aic= True, r_sq= True, 
                                     r_sq_adj= True, bic= True, positive_coef_only= False):
        

        target_var_series = self.df[target_var]
        if seasonality_var is not None:
            self.seasonality_series = self.df[seasonality_var]
            
        target_df = find_best_var_transformation_media(target_var_series, self.var_transformations, 
                                                 seasonality_var_series= self.seasonality_series,
                                                 intercept= intercept)
        
        target_df['Variable'] = self.variable
        target_df['Identifier'] = target_df['Variable Transformation'].apply(lambda x: int(x.split(" ")[-1]))
        target_df = target_df.merge(self.transformation_matrix, how= 'left')
        
        first_cols = ['Variable'] + list(self.transformation_matrix.columns.values)
        target_df = target_df[first_cols + [col for col in target_df if col not in first_cols]]
        target_df = target_df.drop(columns = ['Variable Transformation', 'Identifier'])
        
        return target_df
    
    def find_best_lag(self, target_var, independent_vars):
        # Separate handling of lag for Sponsored Products
        
        for var in independent_vars:
            print(var)
            if 'M_SP' in var:    
                _, self.best_lag_dict[var], lag_analysis = get_best_lag(self.df, var= var, target_var= target_var, plot= True, 
                                        lag_lower= self.lag_lower, lag_upper= self.max_sponsored_lag)
            else:
                _, self.best_lag_dict[var], lag_analysis = get_best_lag(self.df, var= var, target_var= target_var, plot= True, 
                                        lag_lower= self.lag_lower, lag_upper= self.lag_upper)
                
            self.var_lag_analysis[var] = lag_analysis
            print('Best Lag for ' + var + " : " + str(self.best_lag_dict[var]))
            print("*****************************************************************")
            
    def update_best_lag(self, var, new_lag):
        self.best_lag_dict[var] = new_lag
        
        
    def find_best_trans_all_vars(self, target_var, independent_vars,
                                 additional_indep_vars= None,
                                 intercept= True,
                                 mape= True, pval= True, corr= True, aic= True, 
                                 r_sq= True, r_sq_adj= True, bic= True,
                                 include_other_media= True):
        
        final_df = pd.DataFrame()
        
        if include_other_media:
            additional_indep_vars = additional_indep_vars + independent_vars
            
        
        # Looping through all of the independent variables
        for var in independent_vars:
            
            if self.df[var].sum() == 0:
                print('Skipped variable due to zero sum:', var)
                continue
            
            self.best_lag = self.best_lag_dict[var]
            print("*****************************************************************")
            self.variable = var
            print('Processing for Variable: ' + var)
            self.create_all_transformations()
            
            

            additional_indep_vars_new = [col for col in additional_indep_vars if col != self.variable]
            
            final_df_var = self.rank_variable_transformation(target_var= target_var, 
                                                             seasonality_var= additional_indep_vars_new,
                                                             intercept= intercept,
                                                             mape= mape, pval= pval, corr= corr, aic= aic,
                                                             r_sq= r_sq, r_sq_adj= r_sq_adj, bic= bic, 
                                                             positive_coef_only= True)
            
            self.all_variable_rankings[var] = final_df_var
            final_df = pd.concat([final_df, final_df_var.iloc[0:1, :]], axis = 0).reset_index(drop= True)
            self.final_ranking_df = final_df
    
    
    def save_excel_output(self, file_path, decimal_col_names, scientific_col_names, decimal_5_col_names):
        
        file_path = os.path.abspath(file_path)
        
        try:
            file_path =  file_path
            print(file_path)
            excel_obj = SaveExcelTemplated(file_path)
            
            df_final_model_ranks = self.final_ranking_df.iloc[:, 0:6]
            df_final_model_ranks = df_final_model_ranks.merge(self.data_dict[['Variable Name', 'Media Hierarchy']],
                                                              left_on = 'Variable', right_on= 'Variable Name',
                                                              how= 'left')
            
            df_final_model_ranks = df_final_model_ranks[['Variable', 'Media Hierarchy', 'Lag', 'Halflife',
                                                         'SCurve-Scale', 'SCurve-Inflection', 'C-Curve']]
            
            excel_obj.add_worksheet(df_final_model_ranks, 'Final Transformations', 
                                      decimal_col_names= decimal_col_names,
                                      decimal_5_col_names = decimal_5_col_names,
                                      scientific_col_names= scientific_col_names)
              
            excel_obj.add_worksheet(self.final_ranking_df, 'All Variables', 
                                      decimal_col_names= decimal_col_names,
                                      decimal_5_col_names = decimal_5_col_names,
                                      scientific_col_names= scientific_col_names)
              
            for key, value in self.all_variable_rankings.items():
                excel_obj.add_worksheet(value, key, 
                                        decimal_col_names= decimal_col_names,
                                        decimal_5_col_names = decimal_5_col_names,
                                        scientific_col_names= scientific_col_names)
    
            excel_obj.save_worksheet()
            
        except:
            
            print(file_path)
            excel_obj = SaveExcelTemplated(file_path)
            
            df_final_model_ranks = self.final_ranking_df.iloc[:, 0:6]
            df_final_model_ranks = df_final_model_ranks.merge(self.data_dict[['Variable Name', 'Media Hierarchy']],
                                                              left_on = 'Variable', right_on= 'Variable Name',
                                                              how= 'left')
            
            df_final_model_ranks = df_final_model_ranks[['Variable', 'Media Hierarchy', 'Lag', 'Halflife',
                                                         'SCurve-Scale', 'SCurve-Inflection', 'C-Curve']]
            
            excel_obj.add_worksheet(df_final_model_ranks, 'Final Transformations', 
                                      decimal_col_names= decimal_col_names,
                                      decimal_5_col_names = decimal_5_col_names,
                                      scientific_col_names= scientific_col_names)
              
            excel_obj.add_worksheet(self.final_ranking_df, 'All Variables', 
                                      decimal_col_names= decimal_col_names,
                                      decimal_5_col_names = decimal_5_col_names,
                                      scientific_col_names= scientific_col_names)
              
            for key, value in self.all_variable_rankings.items():
                excel_obj.add_worksheet(value, key, 
                                        decimal_col_names= decimal_col_names,
                                        decimal_5_col_names = decimal_5_col_names,
                                        scientific_col_names= scientific_col_names)
    
            excel_obj.save_worksheet()
        
        
        
    
    def visualize_transformation(self, orig_var, trans_1, trans_2= None):
        
        name = 'Transformation '
        if self.current_lag_toggle:
            name += 'Lag-' + str(self.current_lag) + ", "
        if self.current_halflife_toggle:
            name += 'Halflife-' + str(self.current_halflife) + ", "
        if self.current_scurve_toggle:
            name+= 'SCurve Scale-' + str(self.current_scale)  + ", "
        if self.current_scurve_toggle:
            name+= 'SCurve Inflection-' + str(self.current_inflection)  + ", "
        if self.current_ccurve_toggle:
            name+= 'CCurve-' + str(self.current_ccurve_toggle)  + ", "
        
        name = name[:-2]
        
        plot_data = []
        a= go.Scatter(x= self.df['index'], y= self.df[orig_var],
                          line= dict(color= '#0071CE'), yaxis='y1', name= 'Original Variable')
        b= go.Scatter(x= self.df['index'], y= trans_1,
                          line= dict(color= '#041E42'), yaxis='y2', name= name)
        if trans_2 is not None:
            c= go.Scatter(x= self.df['index'], y= trans_2,
                              line= dict(color= '#FFC220'), yaxis='y2', name= 'Transformation 2')
            plot_data = [a, b, c]
        else:
            plot_data = [a, b]
        
        fig = go.Figure(plot_data)
        
        fig.update_layout(
            dict(xaxis = dict(showgrid=False, ticks='outside', mirror= True, showline= False, linecolor= 'black',
                                      linewidth= 1, tickangle= 30),
                                yaxis = dict(title= 'Original Variable', showgrid=False, mirror= True, ticks= '', showline= False,
                                             linecolor= 'black', linewidth= 1, tickformat= ', g', showticklabels= True,
                                             rangemode= 'tozero'),
                                yaxis2= dict(title= 'Transformed', overlaying= 'y', side= 'right', tickformat= ', g',
                                             showticklabels= True, tickmode= 'auto', rangemode='tozero'),
                                font= dict(size=10), ),
            autosize= True,
            width= 1000,
            height= 450,
            paper_bgcolor= 'rgba(0,0,0,0)',
            plot_bgcolor= 'rgba(0,0,0,0)',
            title={
                'text': 'Media Variable Transformation',
                'y':0.8,
                'x':0.46,
                'xanchor': 'center',
                'yanchor': 'top'},
            legend_orientation = 'h',
            legend=dict(x=0.17,y=-.15)
        )
        
        fig.show()
        
        
        
    def visulaize_adstock(self, orig_var, trans_1):

        name = 'Transformation '
        if self.current_lag_toggle:
            name += 'Lag-' + str(self.current_lag) + ", "
        if self.current_halflife_toggle:
            name += 'Halflife-' + str(self.current_halflife) + ", "
        if self.current_scurve_toggle:
            name+= 'SCurve Scale-' + str(self.current_scale)  + ", "
        if self.current_scurve_toggle:
            name+= 'SCurve Inflection-' + str(self.current_inflection)  + ", "
        if self.current_ccurve_toggle:
            name+= 'CCurve-' + str(self.current_ccurve_toggle)  + ", "
        
        name = name[:-2]
        
        plot_data = []
        a= go.Bar(x= self.df['index'], y= self.df[orig_var],
                           yaxis='y1', name= 'Original Variable')
        
        b= go.Scatter(x= self.df['index'], y= trans_1,
                          line= dict(color= '#041E42'), yaxis='y2', name= name)
        
        plot_data = [a, b]
        
        fig = go.Figure(plot_data)
        
        fig.update_layout(
            dict(xaxis = dict(showgrid=False, ticks='outside', mirror= True, showline= False, linecolor= 'black',
                                      linewidth= 1, tickangle= 30),
                                yaxis = dict(title= 'Original Variable', showgrid=False, mirror= True, ticks= '', showline= False,
                                             linecolor= 'black', linewidth= 1, tickformat= ', g', showticklabels= True,
                                             rangemode= 'tozero'),
                                yaxis2= dict(title= 'Transformed Variable', overlaying= 'y', side= 'right', tickformat= ', g',
                                             showticklabels= True, tickmode= 'auto', rangemode='tozero'),
                                font= dict(size=10), ),
            autosize= True,
            width= 1000,
            height= 450,
            paper_bgcolor= 'rgba(0,0,0,0)',
            plot_bgcolor= 'rgba(0,0,0,0)',
            title={
                'text': 'Media Variable Transformation',
                'y':0.8,
                'x':0.46,
                'xanchor': 'center',
                'yanchor': 'top'},
            legend_orientation = 'h',
            legend=dict(x=0.17,y=-.15)
        )
        
        fig.show()
    
    def visualize_curve_trans(self, orig_var, transf_var, original_scale= True):

        plt.figure(figsize= (10, 8))
        ax = sns.scatterplot(x= orig_var.values, y= transf_var.values)
        plt.ylabel('Transformed Variable')
        plt.xlabel('Original Variable')
        plt.title('Transformation')
        
        if original_scale:
            ax.yaxis.set_major_formatter(mpl.ticker.StrMethodFormatter('{x:,.0f}'))
            ax.xaxis.set_major_formatter(mpl.ticker.StrMethodFormatter('{x:,.0f}'))  
        plt.show()
        
